#!/usr/bin/env python3
"""Find short oriented paths between assembly-graph segment ends."""

from __future__ import annotations

import argparse
import collections
from pathlib import Path


def opposite(orientation: str) -> str:
    return "+" if orientation == "-" else "-"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gfa", type=Path, required=True)
    parser.add_argument("--start", required=True, help="segment followed by + or -")
    parser.add_argument("--end", required=True, help="segment followed by + or -")
    parser.add_argument("--max-edges", type=int, default=12)
    parser.add_argument("--max-paths", type=int, default=20)
    args = parser.parse_args()

    lengths: dict[str, int] = {}
    graph: dict[tuple[str, str], list[tuple[str, str]]] = collections.defaultdict(list)
    with args.gfa.open() as handle:
        for line in handle:
            if line.startswith("S\t"):
                fields = line.rstrip("\n").split("\t")
                lengths[fields[1]] = len(fields[2]) if fields[2] != "*" else 0
            elif line.startswith("L\t"):
                fields = line.rstrip("\n").split("\t")
                left = (fields[1], fields[2])
                right = (fields[3], fields[4])
                graph[left].append(right)
                graph[(right[0], opposite(right[1]))].append(
                    (left[0], opposite(left[1]))
                )

    start = (args.start[:-1], args.start[-1])
    end = (args.end[:-1], args.end[-1])
    queue = collections.deque([[start]])
    results: list[list[tuple[str, str]]] = []
    shortest = None
    while queue and len(results) < args.max_paths:
        path = queue.popleft()
        if shortest is not None and len(path) > shortest:
            continue
        if len(path) > args.max_edges:
            continue
        node = path[-1]
        if node == end:
            results.append(path)
            shortest = len(path)
            continue
        used_segments = {item[0] for item in path}
        for neighbor in graph.get(node, []):
            if neighbor[0] in used_segments:
                continue
            queue.append(path + [neighbor])

    print("path_id\tedge_count\tinternal_segment_bp\toriented_path")
    for index, path in enumerate(results, 1):
        internal = sum(lengths.get(node[0], 0) for node in path[1:-1])
        rendered = ",".join(f"{name}{orientation}" for name, orientation in path)
        print(f"{index}\t{len(path)}\t{internal}\t{rendered}")


if __name__ == "__main__":
    main()
