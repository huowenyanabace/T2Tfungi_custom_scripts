#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 5 ]]; then
    echo "Usage: $0 BAM FAI PAIRS_TSV OUT_TSV WORKDIR" >&2
    exit 2
fi

bam=$1
fai=$2
pairs=$3
out=$4
work=$5
window=${END_WINDOW_BP:-50000}
min_mapq=${MIN_MAPQ:-20}
samtools_bin=${SAMTOOLS_BIN:-samtools}

mkdir -p "$work" "$(dirname "$out")"

declare -A lengths
while IFS=$'\t' read -r name len _; do
    lengths["$name"]=$len
done < "$fai"

extract_end_names() {
    local contig=$1
    local end=$2
    local length=${lengths[$contig]:-}
    local start stop key output
    [[ -n "$length" ]] || { echo "Unknown contig: $contig" >&2; exit 3; }
    key="${contig}.${end}"
    output="$work/${key}.qnames.txt"
    if [[ -s "$output" ]]; then
        return
    fi
    if [[ "$end" == "L" ]]; then
        start=1
        stop=$(( length < window ? length : window ))
    elif [[ "$end" == "R" ]]; then
        start=$(( length > window ? length - window + 1 : 1 ))
        stop=$length
    else
        echo "Invalid end label: $end" >&2
        exit 4
    fi
    "$samtools_bin" view -F 4 -q "$min_mapq" "$bam" "${contig}:${start}-${stop}" \
        | awk '{print $1}' | sort -u > "$output"
}

while IFS=$'\t' read -r junction c1 e1 c2 e2 note; do
    [[ "$junction" == "junction_id" || -z "$junction" ]] && continue
    extract_end_names "$c1" "$e1"
    extract_end_names "$c2" "$e2"
done < "$pairs"

printf 'junction_id\tcontig1\tend1\tcontig2\tend2\twindow_bp\tmin_mapq\tshared_read_names\tnote\n' > "$out"
while IFS=$'\t' read -r junction c1 e1 c2 e2 note; do
    [[ "$junction" == "junction_id" || -z "$junction" ]] && continue
    count=$(comm -12 "$work/${c1}.${e1}.qnames.txt" "$work/${c2}.${e2}.qnames.txt" | wc -l)
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$junction" "$c1" "$e1" "$c2" "$e2" "$window" "$min_mapq" "$count" "$note" >> "$out"
done < "$pairs"

