#!/usr/bin/env python3
"""Build a normalized reviewed assembly and 500-N scaffold FASTA from a layout."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    current = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                current = line[1:].split()[0]
                if current in records:
                    raise ValueError(f"Duplicate FASTA ID: {current}")
                records[current] = []
            elif current is None:
                raise ValueError("Sequence before FASTA header")
            else:
                records[current].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans("ACGTRYMKBDHVN", "TGCAYRKMVHDBN"))[::-1]


def write_fasta(records: list[tuple[str, str]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for name, sequence in records:
            handle.write(f">{name}\n")
            for start in range(0, len(sequence), 80):
                handle.write(sequence[start:start + 80] + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-fasta", type=Path, required=True)
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--layout", type=Path, required=True)
    parser.add_argument("--out-prefix", type=Path, required=True)
    parser.add_argument("--gap-size", type=int, default=500)
    args = parser.parse_args()

    source = read_fasta(args.source_fasta)
    selected: list[tuple[str, str]] = []
    provenance = []
    with args.selection.open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            src = row["source_id"]
            out = row["output_id"]
            start = int(row["source_start_1based"])
            end = int(row["source_end_1based"])
            if src not in source or start < 1 or end > len(source[src]) or start > end:
                raise ValueError(f"Invalid selection: {row}")
            sequence = source[src][start - 1:end]
            selected.append((out, sequence))
            provenance.append((out, src, start, end, len(sequence), row.get("decision", "")))

    selected_dict = dict(selected)
    if len(selected_dict) != len(selected):
        raise ValueError("Duplicate output component ID")

    groups = []
    with args.layout.open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            tokens = row["oriented_components"].split()
            for token in tokens:
                name = token[1:] if token.startswith("-") else token
                if name not in selected_dict:
                    raise ValueError(f"Layout component absent from selection: {name}")
            groups.append((row["chromosome_id"], tokens, row.get("decision", "")))

    used = [token[1:] if token.startswith("-") else token for _, tokens, _ in groups for token in tokens]
    if len(used) != len(set(used)) or set(used) != set(selected_dict):
        raise ValueError("Every selected component must occur exactly once in the layout")

    args.out_prefix.parent.mkdir(parents=True, exist_ok=True)
    def output_path(suffix: str) -> Path:
        return Path(str(args.out_prefix) + suffix)

    write_fasta(selected, output_path(".components.fasta"))

    numeric_id = {name: index for index, (name, _) in enumerate(selected, 1)}
    with output_path(".reviewed.assembly").open("w") as handle:
        for name, sequence in selected:
            handle.write(f">{name} {numeric_id[name]} {len(sequence)}\n")
        for _, tokens, _ in groups:
            rendered = []
            for token in tokens:
                reverse = token.startswith("-")
                name = token[1:] if reverse else token
                value = numeric_id[name]
                rendered.append(str(-value if reverse else value))
            handle.write(" ".join(rendered) + "\n")

    chromosome_records = []
    agp_rows = []
    for chromosome, tokens, _ in groups:
        parts = []
        position = 1
        part_number = 1
        for index, token in enumerate(tokens):
            reverse = token.startswith("-")
            name = token[1:] if reverse else token
            sequence = selected_dict[name]
            oriented = reverse_complement(sequence) if reverse else sequence
            parts.append(oriented)
            end = position + len(oriented) - 1
            agp_rows.append([chromosome, position, end, part_number, "W", name, 1, len(sequence), "-" if reverse else "+"])
            position = end + 1
            part_number += 1
            if index + 1 < len(tokens):
                parts.append("N" * args.gap_size)
                end = position + args.gap_size - 1
                agp_rows.append([chromosome, position, end, part_number, "N", args.gap_size, "scaffold", "yes", "proximity_ligation"])
                position = end + 1
                part_number += 1
        chromosome_records.append((chromosome, "".join(parts)))
    write_fasta(chromosome_records, output_path(".chromosomes.500N.fasta"))

    with output_path(".chromosomes.500N.agp").open("w") as handle:
        handle.write("##agp-version 2.1\n")
        for row in agp_rows:
            handle.write("\t".join(map(str, row)) + "\n")

    with output_path(".selection_provenance.tsv").open("w") as handle:
        handle.write("output_id\tsource_id\tsource_start_1based\tsource_end_1based\tretained_bp\tdecision\n")
        for row in provenance:
            handle.write("\t".join(map(str, row)) + "\n")


if __name__ == "__main__":
    main()
