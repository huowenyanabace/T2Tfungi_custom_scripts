#!/usr/bin/env python3
"""Build a small oriented scaffold from named FASTA components."""

from __future__ import annotations

import argparse
from pathlib import Path


def reverse_complement(sequence: str) -> str:
    return sequence.translate(str.maketrans("ACGTRYMKBDHVN", "TGCAYRKMVHDBN"))[::-1]


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    current = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                current = line[1:].split()[0]
                records[current] = []
            elif current is None:
                raise ValueError("Sequence before FASTA header")
            else:
                records[current].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fasta", type=Path, required=True)
    parser.add_argument("--components", nargs="+", required=True,
                        help="Ordered component IDs, prefix reverse components with '-'")
    parser.add_argument("--gap", type=int, default=500)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    records = read_fasta(args.fasta)
    sequences = []
    for token in args.components:
        reverse = token.startswith("-")
        name = token[1:] if reverse else token
        sequence = records[name]
        sequences.append(reverse_complement(sequence) if reverse else sequence)
    scaffold = ("N" * args.gap).join(sequences)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w") as handle:
        handle.write(f">{args.name}\n")
        for start in range(0, len(scaffold), 80):
            handle.write(scaffold[start:start + 80] + "\n")


if __name__ == "__main__":
    main()
