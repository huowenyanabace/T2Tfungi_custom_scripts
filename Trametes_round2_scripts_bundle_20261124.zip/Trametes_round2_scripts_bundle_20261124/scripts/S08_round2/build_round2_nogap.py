#!/usr/bin/env python3
"""Build the gap-free T. elegans round-2 chromosome candidate.

The round-2 Juicebox assembly uses 500-N placeholders between components.  This
script replaces only the five junctions that have independent ONT support.  It
reuses the four previously audited S10 edits and imports the newly polished
Te_ctg005--Te_ctg002 junction from the dedicated TGS-GapCloser run.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name: str | None = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                if name in records:
                    raise ValueError(f"duplicate FASTA identifier in {path}: {name}")
                records[name] = []
            elif name is None:
                raise ValueError(f"sequence precedes header in {path}")
            else:
                records[name].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def write_fasta(records: dict[str, str], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for name, seq in records.items():
            handle.write(f">{name}\n")
            for start in range(0, len(seq), 80):
                handle.write(seq[start : start + 80] + "\n")


def slice_1based(records: dict[str, str], name: str, start: int, end: int) -> str:
    if name not in records:
        raise ValueError(f"missing candidate record: {name}")
    seq = records[name]
    if start < 1 or end < start or end > len(seq):
        raise ValueError(f"invalid interval {name}:{start}-{end} (length {len(seq)})")
    return seq[start - 1 : end]


def read_filled_interval(detail_path: Path) -> tuple[str, int, int]:
    record: str | None = None
    filled: list[tuple[str, int, int]] = []
    with detail_path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                record = line[1:].split()[0]
                continue
            fields = line.split("\t")
            if len(fields) >= 3 and fields[2] == "F":
                if record is None:
                    raise ValueError(f"filled interval precedes header in {detail_path}")
                filled.append((record, int(fields[0]), int(fields[1])))
    if len(filled) != 1:
        raise ValueError(f"expected one filled interval in {detail_path}, found {len(filled)}")
    return filled[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--round2-500n", type=Path, required=True)
    parser.add_argument("--old-candidate", type=Path, required=True)
    parser.add_argument("--new-candidate", type=Path, required=True)
    parser.add_argument("--new-detail", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--edits-output", type=Path, required=True)
    parser.add_argument("--intervals-output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    original = read_fasta(args.round2_500n)
    old_candidate = read_fasta(args.old_candidate)
    new_candidate = read_fasta(args.new_candidate)
    if len(original) != 14:
        raise ValueError(f"round-2 assembly must contain 14 chromosomes, found {len(original)}")

    new_record, new_start, new_end = read_filled_interval(args.new_detail)
    new_insert = slice_1based(new_candidate, new_record, new_start, new_end)
    if not new_insert or "N" in new_insert:
        raise ValueError("new Te_ctg005--Te_ctg002 filler is empty or contains N")

    edits = [
        {
            "junction_id": "Te_round2_junction01",
            "chromosome": "Chr02",
            "start": 2715575,
            "end": 2716074,
            "replacement": slice_1based(old_candidate, "Chr04", 2715575, 2739336),
            "action": "candidate_sequence",
            "source": "S10_Te_gap07",
            "evidence": "122 strict pass.ul spanning reads",
        },
        {
            "junction_id": "Te_round2_junction02",
            "chromosome": "Chr05",
            "start": 1085220,
            "end": 1085737,
            "replacement": "",
            "action": "overlap_merge",
            "source": "S10_Te_gap08",
            "evidence": "18-bp overlap; 219 strict pass.ul spanning reads",
        },
        {
            "junction_id": "Te_round2_junction03",
            "chromosome": "Chr09",
            "start": 18304,
            "end": 18803,
            "replacement": slice_1based(old_candidate, "Chr02", 18304, 18311),
            "action": "candidate_sequence",
            "source": "S10_Te_gap03",
            "evidence": "303 strict pass.ul spanning reads",
        },
        {
            "junction_id": "Te_round2_junction04",
            "chromosome": "Chr10",
            "start": 1906162,
            "end": 1906661,
            "replacement": slice_1based(old_candidate, "Chr03", 1906162, 1906162),
            "action": "candidate_sequence",
            "source": "S10_Te_gap05",
            "evidence": "251 strict pass.ul spanning reads",
        },
        {
            "junction_id": "Te_round2_junction05",
            "chromosome": "Chr14",
            "start": 630288,
            "end": 630787,
            "replacement": new_insert,
            "action": "candidate_sequence",
            "source": f"{args.new_candidate}:{new_record}:{new_start}-{new_end}",
            "evidence": "218 strict pass.ul spanning reads and 1110 Hi-C end contacts before filling",
        },
    ]

    output = dict(original)
    audit_rows: list[dict[str, object]] = []
    for chromosome in original:
        chromosome_edits = [e for e in edits if e["chromosome"] == chromosome]
        seq = original[chromosome]
        for edit in sorted(chromosome_edits, key=lambda x: int(x["start"]), reverse=True):
            start = int(edit["start"])
            end = int(edit["end"])
            replaced = seq[start - 1 : end]
            n_count = replaced.count("N")
            if edit["action"] == "candidate_sequence" and replaced != "N" * 500:
                raise ValueError(
                    f"{edit['junction_id']} expected an exact 500-N placeholder, "
                    f"observed length={len(replaced)}, N={n_count}"
                )
            if edit["action"] == "overlap_merge" and (len(replaced), n_count) != (518, 500):
                raise ValueError(
                    f"{edit['junction_id']} expected 18-bp overlap plus 500 N; "
                    f"observed length={len(replaced)}, N={n_count}"
                )
            replacement = str(edit["replacement"])
            seq = seq[: start - 1] + replacement + seq[end:]
            audit_rows.append(
                {
                    **{k: v for k, v in edit.items() if k != "replacement"},
                    "removed_bp": len(replaced),
                    "inserted_bp": len(replacement),
                    "net_change_bp": len(replacement) - len(replaced),
                }
            )
        output[chromosome] = seq

    n_runs = [(name, m.start() + 1, m.end()) for name, seq in output.items() for m in re.finditer(r"N+", seq)]
    if n_runs:
        raise ValueError(f"gap-free output still contains N runs: {n_runs[:5]}")

    write_fasta(output, args.output)

    args.edits_output.parent.mkdir(parents=True, exist_ok=True)
    edit_fields = [
        "junction_id",
        "chromosome",
        "start",
        "end",
        "action",
        "source",
        "evidence",
        "removed_bp",
        "inserted_bp",
        "net_change_bp",
    ]
    with args.edits_output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=edit_fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(audit_rows)

    # Recalculate the final junction intervals after coordinate shifts.  The
    # interval covers the inserted sequence; overlap merges use the single
    # boundary base so the standard spanning-read auditor can still be used.
    interval_rows: list[dict[str, object]] = []
    cumulative_shift: dict[str, int] = {}
    for edit in sorted(audit_rows, key=lambda x: (str(x["chromosome"]), int(x["start"]))):
        chrom = str(edit["chromosome"])
        shift = cumulative_shift.get(chrom, 0)
        boundary = int(edit["start"]) + shift
        inserted = int(edit["inserted_bp"])
        interval_rows.append(
            {
                "gap_id": edit["junction_id"],
                "chromosome": chrom,
                "start_1based": boundary,
                "end_1based": boundary + max(inserted, 1) - 1,
            }
        )
        cumulative_shift[chrom] = shift + int(edit["net_change_bp"])
    args.intervals_output.parent.mkdir(parents=True, exist_ok=True)
    with args.intervals_output.open("w") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["gap_id", "chromosome", "start_1based", "end_1based"],
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(interval_rows)

    summary = {
        "chromosomes": len(output),
        "assembly_bp": sum(len(seq) for seq in output.values()),
        "junctions_resolved": len(edits),
        "remaining_N_runs": 0,
        "remaining_N_bp": 0,
        "new_junction_filler_bp": len(new_insert),
        "round2_structure": str(args.round2_500n),
        "output": str(args.output),
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
