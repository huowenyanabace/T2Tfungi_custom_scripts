#!/usr/bin/env python3
"""Rebuild a reviewed chromosome assembly after conservative interval removal.

Coordinates in the removal BED are 0-based, half-open.  The component table is
the reviewed S09 chromosome layout.  Removed sequence is retained in a separate
FASTA, and every output chromosome must remain non-empty.
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name: str | None = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                if name in records:
                    raise ValueError(f"Duplicate FASTA ID: {name}")
                records[name] = []
            elif name is None:
                raise ValueError("Sequence found before first FASTA header")
            else:
                records[name].append(line)
    return {key: "".join(value).upper() for key, value in records.items()}


def write_fasta(records: list[tuple[str, str]], path: Path, width: int = 80) -> None:
    with path.open("w") as handle:
        for name, seq in records:
            handle.write(f">{name}\n")
            for start in range(0, len(seq), width):
                handle.write(seq[start : start + width] + "\n")


def reverse_complement(seq: str) -> str:
    table = str.maketrans("ACGTRYMKBDHVN", "TGCAYRKMVHDBN")
    return seq.translate(table)[::-1]


def merge_intervals(intervals: list[tuple[int, int, str, str]], length: int):
    clipped = []
    for start, end, kind, replacement in sorted(intervals):
        if start < 0 or end > length or start >= end:
            raise ValueError(f"Invalid removal interval {start}-{end} for length {length}")
        if clipped and start < clipped[-1][1]:
            raise ValueError(f"Overlapping removal intervals: {clipped[-1]} and {(start, end)}")
        clipped.append((start, end, kind, replacement))
    return clipped


def retained_intervals(length: int, removed: list[tuple[int, int, str, str]]):
    retained = []
    cursor = 0
    for start, end, _, _ in removed:
        if cursor < start:
            retained.append((cursor, start))
        cursor = end
    if cursor < length:
        retained.append((cursor, length))
    return retained


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--components-fasta", type=Path, required=True)
    parser.add_argument("--layout", type=Path, required=True)
    parser.add_argument("--remove-bed", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--gap-size", type=int, default=500)
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    sequences = read_fasta(args.components_fasta)

    layout: dict[str, list[dict[str, str]]] = defaultdict(list)
    with args.layout.open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            layout[row["chromosome_id"]].append(row)
    for chromosome in layout:
        layout[chromosome].sort(key=lambda row: int(row["part_number"]))

    remove_by_component: dict[str, list[tuple[int, int, str, str]]] = defaultdict(list)
    with args.remove_bed.open() as handle:
        for line in handle:
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 5:
                raise ValueError(f"Expected five BED columns: {line.rstrip()}")
            component, start, end, kind, replacement = fields[:5]
            remove_by_component[component].append(
                (int(start), int(end), kind, replacement)
            )

    for component, intervals in list(remove_by_component.items()):
        if component not in sequences:
            raise ValueError(f"Removal component absent from FASTA: {component}")
        remove_by_component[component] = merge_intervals(
            intervals, len(sequences[component])
        )

    chromosome_records: list[tuple[str, str]] = []
    removed_records: list[tuple[str, str]] = []
    agp_rows: list[list[str]] = []
    component_rows: list[list[str]] = []
    removed_rows: list[list[str]] = []
    total_removed = 0
    retained_source_bp = 0
    new_gap_count = 0

    for chromosome in sorted(layout, key=lambda item: int(item.removeprefix("Chr"))):
        pieces: list[dict[str, object]] = []
        for row in layout[chromosome]:
            component = row["component_id"]
            orientation = row["orientation"]
            source = sequences[component]
            removed = remove_by_component.get(component, [])
            retained = retained_intervals(len(source), removed)
            for start, end, kind, replacement in removed:
                removed_seq = source[start:end]
                removed_records.append(
                    (f"{component}:{start + 1}-{end}|{kind}|replacement={replacement}", removed_seq)
                )
                removed_rows.append(
                    [chromosome, component, str(start), str(end), str(end - start), kind, replacement]
                )
                total_removed += end - start
            ordered = retained if orientation == "+" else list(reversed(retained))
            for start, end in ordered:
                seq = source[start:end]
                if orientation == "-":
                    seq = reverse_complement(seq)
                pieces.append(
                    {
                        "component": component,
                        "source_start": start,
                        "source_end": end,
                        "orientation": orientation,
                        "seq": seq,
                    }
                )

        if not pieces:
            raise ValueError(f"All sequence removed from reviewed chromosome {chromosome}")

        assembled: list[str] = []
        object_pos = 1
        part_number = 1
        for index, piece in enumerate(pieces):
            seq = str(piece["seq"])
            object_end = object_pos + len(seq) - 1
            agp_rows.append(
                [
                    chromosome,
                    str(object_pos),
                    str(object_end),
                    str(part_number),
                    "W",
                    str(piece["component"]),
                    str(int(piece["source_start"]) + 1),
                    str(piece["source_end"]),
                    str(piece["orientation"]),
                ]
            )
            component_rows.append(
                [
                    chromosome,
                    str(part_number),
                    str(piece["component"]),
                    str(len(seq)),
                    str(piece["orientation"]),
                    str(int(piece["source_start"]) + 1),
                    str(piece["source_end"]),
                    str(object_pos),
                    str(object_end),
                ]
            )
            assembled.append(seq)
            retained_source_bp += len(seq)
            object_pos = object_end + 1
            part_number += 1
            if index < len(pieces) - 1:
                gap_end = object_pos + args.gap_size - 1
                agp_rows.append(
                    [
                        chromosome,
                        str(object_pos),
                        str(gap_end),
                        str(part_number),
                        "N",
                        str(args.gap_size),
                        "scaffold",
                        "yes",
                        "proximity_ligation",
                    ]
                )
                assembled.append("N" * args.gap_size)
                object_pos = gap_end + 1
                part_number += 1
                new_gap_count += 1
        chromosome_records.append((chromosome, "".join(assembled)))

    if len(chromosome_records) != 14:
        raise ValueError(f"Expected 14 chromosomes, found {len(chromosome_records)}")

    prefix = args.outdir / args.prefix
    write_fasta(chromosome_records, Path(str(prefix) + ".chromosomes.fasta"))
    write_fasta(removed_records, Path(str(prefix) + ".removed.fasta"))
    with Path(str(prefix) + ".chromosomes.agp").open("w") as handle:
        handle.write("##agp-version 2.1\n")
        for row in agp_rows:
            handle.write("\t".join(row) + "\n")
    with Path(str(prefix) + ".components.tsv").open("w") as handle:
        handle.write(
            "chromosome_id\tpart_number\tcomponent_id\tretained_length_bp\t"
            "orientation\tsource_start_1based\tsource_end_1based\t"
            "chromosome_start_1based\tchromosome_end_1based\n"
        )
        for row in component_rows:
            handle.write("\t".join(row) + "\n")
    with Path(str(prefix) + ".removed.tsv").open("w") as handle:
        handle.write(
            "chromosome_id\tcomponent_id\tstart_0based\tend_0based\t"
            "removed_length_bp\tclass\treplacement_component\n"
        )
        for row in removed_rows:
            handle.write("\t".join(row) + "\n")

    summary = {
        "chromosomes": len(chromosome_records),
        "retained_component_pieces": len(component_rows),
        "retained_source_bp": retained_source_bp,
        "removed_intervals": len(removed_rows),
        "removed_bp": total_removed,
        "new_gap_count": new_gap_count,
        "gap_size_bp": args.gap_size,
        "new_gap_bp": new_gap_count * args.gap_size,
        "assembly_bp_including_gaps": sum(len(seq) for _, seq in chromosome_records),
    }
    with Path(str(prefix) + ".summary.json").open("w") as handle:
        json.dump(summary, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
