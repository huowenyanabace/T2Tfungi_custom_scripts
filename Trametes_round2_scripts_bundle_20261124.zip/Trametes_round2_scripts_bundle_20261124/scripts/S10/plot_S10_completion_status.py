#!/usr/bin/env python3
"""Plot S10 gap and telomere completion status."""

from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def read_tsv(path: Path):
    with path.open() as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gap-results", type=Path, required=True)
    parser.add_argument("--warnieri-telomeres", type=Path, required=True)
    parser.add_argument("--elegans-telomeres", type=Path, required=True)
    parser.add_argument("--warnieri-decisions", type=Path, required=True)
    parser.add_argument("--elegans-decisions", type=Path, required=True)
    parser.add_argument("--output-prefix", type=Path, required=True)
    args = parser.parse_args()

    plt.rcParams.update({"font.size": 9, "pdf.fonttype": 42, "ps.fonttype": 42})
    fig = plt.figure(figsize=(12.2, 5.3), constrained_layout=True)
    grid = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.35, 1.0])

    ax1 = fig.add_subplot(grid[0, 0])
    gap_counts = Counter(row["final_status"] for row in read_tsv(args.gap_results))
    labels = ["Sequence filled", "Overlap merged", "Unresolved"]
    values = [gap_counts["filled_sequence"], gap_counts["overlap_merged"], gap_counts["unfilled_500N"]]
    colors = ["#2A9D8F", "#457B9D", "#E76F51"]
    bars = ax1.bar(labels, values, color=colors, edgecolor="black", linewidth=0.6)
    ax1.bar_label(bars, padding=3)
    ax1.set_ylim(0, max(values) + 1.2)
    ax1.set_ylabel("Number of original gaps")
    ax1.set_title(r"A  $\it{T.\ elegans}$ gap resolution")
    ax1.tick_params(axis="x", rotation=25)
    ax1.spines[["top", "right"]].set_visible(False)

    sub = grid[0, 1].subgridspec(1, 2, wspace=0.12)
    species_data = [
        (r"$\it{T.\ warnieri}$", read_tsv(args.warnieri_telomeres)),
        (r"$\it{T.\ elegans}$", read_tsv(args.elegans_telomeres)),
    ]
    for index, (title, rows) in enumerate(species_data):
        ax = fig.add_subplot(sub[0, index])
        rows.sort(key=lambda row: int(row["Chromosome"].replace("Chr", "", 1)))
        matrix = np.array(
            [[row["Has_5prime"] == "True", row["Has_3prime"] == "True"] for row in rows],
            dtype=int,
        )
        ax.imshow(matrix, aspect="auto", vmin=0, vmax=1, cmap=plt.matplotlib.colors.ListedColormap(["#E76F51", "#2A9D8F"]))
        ax.set_xticks([0, 1], ["5′", "3′"])
        ax.set_yticks(range(len(rows)), [row["Chromosome"] for row in rows] if index == 0 else [])
        ax.set_title(("B  " if index == 0 else "") + title)
        for row_index in range(matrix.shape[0]):
            for column_index in range(2):
                ax.text(column_index, row_index, "✓" if matrix[row_index, column_index] else "×", ha="center", va="center", color="white", fontsize=8, fontweight="bold")
        ax.set_xticks(np.arange(-0.5, 2, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, 14, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=0.7)
        ax.tick_params(which="minor", bottom=False, left=False)
    ax3 = fig.add_subplot(grid[0, 2])
    decision_sets = [read_tsv(args.warnieri_decisions), read_tsv(args.elegans_decisions)]
    accepted = [sum(row["decision"] == "accepted" for row in rows) for rows in decision_sets]
    rejected = [sum(row["decision"] == "rejected" for row in rows) for rows in decision_sets]
    x = np.arange(2)
    ax3.bar(x, accepted, color="#2A9D8F", label="Accepted")
    ax3.bar(x, rejected, bottom=accepted, color="#E76F51", label="Rejected")
    ax3.set_xticks(x, [r"$\it{T.\ warnieri}$", r"$\it{T.\ elegans}$"], rotation=15)
    ax3.set_ylabel("FungalTeloExtender candidates")
    ax3.set_ylim(0, 30)
    ax3.set_title("C  Extension audit")
    ax3.legend(frameon=False, loc="upper right")
    ax3.spines[["top", "right"]].set_visible(False)
    for i, (a, r) in enumerate(zip(accepted, rejected)):
        ax3.text(i, a / 2, str(a), ha="center", va="center", color="white", fontweight="bold")
        ax3.text(i, a + r / 2, str(r), ha="center", va="center", color="white", fontweight="bold")

    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(args.output_prefix) + ".png", dpi=600, bbox_inches="tight")
    fig.savefig(str(args.output_prefix) + ".pdf", bbox_inches="tight")
    fig.savefig(str(args.output_prefix) + ".svg", bbox_inches="tight")


if __name__ == "__main__":
    main()
