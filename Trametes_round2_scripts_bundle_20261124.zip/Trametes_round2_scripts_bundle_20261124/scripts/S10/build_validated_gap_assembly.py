#!/usr/bin/env python3
"""Apply only independently validated gap edits to a chromosome assembly."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    for raw in path.open():
        line = raw.strip()
        if not line:
            continue
        if line.startswith(">"):
            name = line[1:].split()[0]
            if name in records:
                raise ValueError(f"Duplicate FASTA ID: {name}")
            records[name] = []
        else:
            if name is None:
                raise ValueError("Sequence before FASTA header")
            records[name].append(line)
    return {name: "".join(parts).upper() for name, parts in records.items()}


def write_fasta(records: dict[str, str], path: Path) -> None:
    with path.open("w") as handle:
        for name, seq in records.items():
            handle.write(f">{name}\n")
            for start in range(0, len(seq), 80):
                handle.write(seq[start : start + 80] + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--edits", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()

    original = read_fasta(args.original)
    candidate = read_fasta(args.candidate)
    by_chromosome: dict[str, list[dict[str, str]]] = defaultdict(list)
    with args.edits.open() as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    for row in rows:
        by_chromosome[row["chromosome"]].append(row)

    output = dict(original)
    accepted = []
    retained = []
    for chromosome, edits in by_chromosome.items():
        seq = original[chromosome]
        for row in sorted(
            edits,
            key=lambda item: int(item["original_replace_start_1based"]),
            reverse=True,
        ):
            action = row["action"]
            if action == "retain_N":
                retained.append(row["gap_id"])
                continue
            start0 = int(row["original_replace_start_1based"]) - 1
            end0 = int(row["original_replace_end_1based"])
            if action == "candidate_sequence":
                candidate_start0 = int(row["candidate_start_1based"]) - 1
                candidate_end0 = int(row["candidate_end_1based"])
                replacement = candidate[chromosome][candidate_start0:candidate_end0]
                if not replacement or "N" in replacement:
                    raise ValueError(f"Invalid candidate replacement for {row['gap_id']}")
            elif action == "overlap_merge":
                replacement = ""
            else:
                raise ValueError(f"Unknown action: {action}")
            seq = seq[:start0] + replacement + seq[end0:]
            accepted.append(
                {
                    "gap_id": row["gap_id"],
                    "action": action,
                    "removed_bp": end0 - start0,
                    "inserted_bp": len(replacement),
                    "net_change_bp": len(replacement) - (end0 - start0),
                    "evidence": row["evidence"],
                }
            )
        output[chromosome] = seq

    if len(output) != 14:
        raise ValueError(f"Expected 14 chromosomes, found {len(output)}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_fasta(output, args.output)
    n_runs = 0
    n_bp = 0
    import re
    for seq in output.values():
        runs = list(re.finditer(r"N+", seq))
        n_runs += len(runs)
        n_bp += sum(len(match.group()) for match in runs)
    report = {
        "chromosomes": len(output),
        "assembly_bp": sum(map(len, output.values())),
        "accepted_gap_edits": accepted,
        "accepted_count": len(accepted),
        "retained_unresolved_gap_ids": retained,
        "retained_unresolved_count": len(retained),
        "remaining_N_runs": n_runs,
        "remaining_N_bp": n_bp,
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
