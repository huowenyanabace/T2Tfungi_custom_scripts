#!/usr/bin/env python3
"""Count long-read alignments that span each proposed gap-resolution interval."""

from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--paf", type=Path, required=True)
    parser.add_argument("--intervals", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--flank", type=int, default=2000)
    parser.add_argument("--min-identity", type=float, default=0.80)
    parser.add_argument("--min-mapq", type=int, default=20)
    args = parser.parse_args()

    with args.intervals.open() as handle:
        intervals = list(csv.DictReader(handle, delimiter="\t"))
    by_chromosome: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in intervals:
        by_chromosome[row["chromosome"]].append(row)

    support: dict[str, dict[str, tuple[float, int, int, int]]] = defaultdict(dict)
    left_support: dict[str, dict[str, tuple[float, int, int, int]]] = defaultdict(dict)
    right_support: dict[str, dict[str, tuple[float, int, int, int]]] = defaultdict(dict)
    with args.paf.open() as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 12:
                continue
            read_id = fields[0]
            target = fields[5]
            if target not in by_chromosome:
                continue
            target_start = int(fields[7])
            target_end = int(fields[8])
            matches = int(fields[9])
            block = int(fields[10])
            mapq = int(fields[11])
            identity = matches / block if block else 0.0
            if mapq < args.min_mapq or identity < args.min_identity:
                continue
            for row in by_chromosome[target]:
                start0 = int(row["start_1based"]) - 1
                end0 = int(row["end_1based"])
                left = max(0, start0 - args.flank)
                right = end0 + args.flank
                left_right = start0 + args.flank
                right_left = max(0, end0 - args.flank)
                value = (identity, mapq, target_start, target_end)
                if target_start <= left and target_end >= left_right:
                    old = left_support[row["gap_id"]].get(read_id)
                    if old is None or value[:2] > old[:2]:
                        left_support[row["gap_id"]][read_id] = value
                if target_start <= right_left and target_end >= right:
                    old = right_support[row["gap_id"]].get(read_id)
                    if old is None or value[:2] > old[:2]:
                        right_support[row["gap_id"]][read_id] = value
                if target_start <= left and target_end >= right:
                    old = support[row["gap_id"]].get(read_id)
                    if old is None or value[:2] > old[:2]:
                        support[row["gap_id"]][read_id] = value

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(intervals[0]) + [
        "audit_flank_bp",
        "min_identity",
        "min_mapq",
        "left_junction_read_count",
        "right_junction_read_count",
        "spanning_read_count",
        "mean_spanning_identity",
        "min_spanning_identity",
        "max_spanning_identity",
        "spanning_read_ids",
    ]
    with args.output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in intervals:
            values = support[row["gap_id"]]
            identities = [item[0] for item in values.values()]
            out = dict(row)
            out.update(
                {
                    "audit_flank_bp": args.flank,
                    "min_identity": f"{args.min_identity:.3f}",
                    "min_mapq": args.min_mapq,
                    "left_junction_read_count": len(left_support[row["gap_id"]]),
                    "right_junction_read_count": len(right_support[row["gap_id"]]),
                    "spanning_read_count": len(values),
                    "mean_spanning_identity": f"{sum(identities) / len(identities):.5f}" if identities else "NA",
                    "min_spanning_identity": f"{min(identities):.5f}" if identities else "NA",
                    "max_spanning_identity": f"{max(identities):.5f}" if identities else "NA",
                    "spanning_read_ids": ",".join(sorted(values)),
                }
            )
            writer.writerow(out)


if __name__ == "__main__":
    main()
