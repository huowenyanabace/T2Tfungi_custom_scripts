#!/usr/bin/env python3
"""Audit telomere-extension joins and terminal reach using long-read PAF data."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


def fasta_lengths(path: Path) -> dict[str, int]:
    lengths: dict[str, int] = {}
    name = None
    for raw in path.open():
        line = raw.strip()
        if line.startswith(">"):
            name = line[1:].split()[0]
            lengths[name] = 0
        elif line and name is not None:
            lengths[name] += len(line)
    return lengths


def keep_best(store, key, read_id, value):
    old = store[key].get(read_id)
    if old is None or value[:2] > old[:2]:
        store[key][read_id] = value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--after", type=Path, required=True)
    parser.add_argument("--analysis-json", type=Path, required=True)
    parser.add_argument("--tool-reads-tsv", type=Path, required=True)
    parser.add_argument("--paf", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--join-flank", type=int, default=2000)
    parser.add_argument("--terminal-slack", type=int, default=500)
    parser.add_argument("--min-identity", type=float, default=0.80)
    parser.add_argument("--min-mapq", type=int, default=20)
    args = parser.parse_args()

    after_lengths = fasta_lengths(args.after)
    data = json.loads(args.analysis_json.read_text())
    extensions = data["extensions"]
    by_chromosome = defaultdict(list)
    for item in extensions:
        key = f"{item['chromosome']}_{item['end']}"
        item["key"] = key
        by_chromosome[item["chromosome"]].append(item)
    five_prime_extension = {
        chromosome: next(
            (int(item["extension_length"]) for item in items if item["end"] == "5prime"),
            0,
        )
        for chromosome, items in by_chromosome.items()
    }

    tool_read_counts = defaultdict(int)
    with args.tool_reads_tsv.open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            tool_read_counts[row["Chrom_End"]] += 1

    join_support = defaultdict(dict)
    terminal_support = defaultdict(dict)
    with args.paf.open() as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 12:
                continue
            read_id = fields[0]
            chromosome = fields[5]
            if chromosome not in by_chromosome:
                continue
            target_start = int(fields[7])
            target_end = int(fields[8])
            matches = int(fields[9])
            block = int(fields[10])
            mapq = int(fields[11])
            identity = matches / block if block else 0.0
            if identity < args.min_identity or mapq < args.min_mapq:
                continue
            value = (identity, mapq, target_start, target_end)
            chromosome_length = after_lengths[chromosome]
            for item in by_chromosome[chromosome]:
                extension_length = int(item["extension_length"])
                if item["end"] == "5prime":
                    join = extension_length
                    left_required = max(0, join - min(args.join_flank, extension_length))
                    right_required = min(chromosome_length, join + args.join_flank)
                    reaches_terminal = (
                        target_start <= args.terminal_slack
                        and target_end >= right_required
                    )
                else:
                    join = five_prime_extension[chromosome] + int(item["original_length"])
                    left_required = max(0, join - args.join_flank)
                    right_flank = min(args.join_flank, extension_length)
                    right_required = min(chromosome_length, join + right_flank)
                    reaches_terminal = (
                        target_start <= left_required
                        and target_end >= chromosome_length - args.terminal_slack
                    )
                if target_start <= left_required and target_end >= right_required:
                    keep_best(join_support, item["key"], read_id, value)
                if reaches_terminal:
                    keep_best(terminal_support, item["key"], read_id, value)

    fieldnames = [
        "chromosome",
        "end",
        "extension_length_bp",
        "motif",
        "repeat_count",
        "method",
        "tool_candidate_read_count",
        "post_join_spanning_read_count",
        "post_terminal_reaching_read_count",
        "mean_join_identity",
        "min_join_identity",
        "max_join_identity",
        "audit_join_flank_bp",
        "audit_terminal_slack_bp",
        "join_spanning_read_ids",
        "terminal_reaching_read_ids",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for item in sorted(extensions, key=lambda x: (int(x["chromosome"].removeprefix("Chr")), x["end"])):
            key = item["key"]
            identities = [value[0] for value in join_support[key].values()]
            writer.writerow(
                {
                    "chromosome": item["chromosome"],
                    "end": item["end"],
                    "extension_length_bp": item["extension_length"],
                    "motif": item["motif"],
                    "repeat_count": item["repeat_count"],
                    "method": item["method"],
                    "tool_candidate_read_count": tool_read_counts[key],
                    "post_join_spanning_read_count": len(join_support[key]),
                    "post_terminal_reaching_read_count": len(terminal_support[key]),
                    "mean_join_identity": f"{sum(identities) / len(identities):.5f}" if identities else "NA",
                    "min_join_identity": f"{min(identities):.5f}" if identities else "NA",
                    "max_join_identity": f"{max(identities):.5f}" if identities else "NA",
                    "audit_join_flank_bp": args.join_flank,
                    "audit_terminal_slack_bp": args.terminal_slack,
                    "join_spanning_read_ids": ",".join(sorted(join_support[key])),
                    "terminal_reaching_read_ids": ",".join(sorted(terminal_support[key])),
                }
            )


if __name__ == "__main__":
    main()
