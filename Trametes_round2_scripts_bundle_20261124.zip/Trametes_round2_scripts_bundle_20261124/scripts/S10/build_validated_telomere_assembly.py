#!/usr/bin/env python3
"""Promote only short telomeric or independently read-supported extensions."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    for raw in path.open():
        line = raw.strip()
        if not line:
            continue
        if line.startswith(">"):
            name = line[1:].split()[0]
            records[name] = []
        else:
            if name is None:
                raise ValueError("FASTA sequence before header")
            records[name].append(line)
    return {name: "".join(parts).upper() for name, parts in records.items()}


def write_fasta(records: dict[str, str], path: Path) -> None:
    with path.open("w") as handle:
        for name, seq in records.items():
            handle.write(f">{name}\n")
            for start in range(0, len(seq), 80):
                handle.write(seq[start : start + 80] + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--before", type=Path, required=True)
    parser.add_argument("--tool-extended", type=Path, required=True)
    parser.add_argument("--analysis-json", type=Path, required=True)
    parser.add_argument("--read-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--decisions", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--max-short-extension", type=int, default=2000)
    parser.add_argument("--min-long-join-reads", type=int, default=3)
    parser.add_argument("--min-repeat-count", type=int, default=3)
    args = parser.parse_args()

    before = read_fasta(args.before)
    extended = read_fasta(args.tool_extended)
    analysis = json.loads(args.analysis_json.read_text())
    audit = {}
    with args.read_audit.open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            audit[(row["chromosome"], row["end"])] = row
    extension_items = {
        (item["chromosome"], item["end"]): item for item in analysis["extensions"]
    }

    decisions = []
    output = {}
    for chromosome, original in before.items():
        item5 = extension_items[(chromosome, "5prime")]
        item3 = extension_items[(chromosome, "3prime")]
        ext5_len = int(item5["extension_length"])
        ext3_len = int(item3["extension_length"])
        tool_seq = extended[chromosome]
        core_end = len(tool_seq) - ext3_len if ext3_len else len(tool_seq)
        if tool_seq[ext5_len:core_end] != original:
            raise ValueError(f"Tool-extended core does not reproduce input chromosome {chromosome}")
        candidates = {
            "5prime": tool_seq[:ext5_len],
            "3prime": tool_seq[core_end:] if ext3_len else "",
        }
        accepted_sequences = {}
        for end, item in (("5prime", item5), ("3prime", item3)):
            extension_length = int(item["extension_length"])
            repeat_count = int(item["repeat_count"])
            spanning = int(audit[(chromosome, end)]["post_join_spanning_read_count"])
            if extension_length <= args.max_short_extension and repeat_count >= args.min_repeat_count:
                accept = True
                reason = "short_telomeric_extension"
            elif spanning >= args.min_long_join_reads:
                accept = True
                reason = "long_extension_with_independent_spanning_reads"
            else:
                accept = False
                reason = "rejected_long_extension_insufficient_correct_chromosome_support"
            accepted_sequences[end] = candidates[end] if accept else ""
            decisions.append(
                {
                    "chromosome": chromosome,
                    "end": end,
                    "tool_extension_length_bp": extension_length,
                    "repeat_count": repeat_count,
                    "method": item["method"],
                    "post_join_spanning_read_count": spanning,
                    "decision": "accepted" if accept else "rejected",
                    "decision_reason": reason,
                    "accepted_extension_length_bp": extension_length if accept else 0,
                }
            )
        output[chromosome] = accepted_sequences["5prime"] + original + accepted_sequences["3prime"]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    write_fasta(output, args.output)
    fields = list(decisions[0])
    with args.decisions.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(decisions)
    accepted = [row for row in decisions if row["decision"] == "accepted"]
    rejected = [row for row in decisions if row["decision"] == "rejected"]
    summary = {
        "chromosomes": len(output),
        "original_bp": sum(map(len, before.values())),
        "validated_bp": sum(map(len, output.values())),
        "accepted_ends": len(accepted),
        "rejected_ends": len(rejected),
        "accepted_extension_bp": sum(int(row["accepted_extension_length_bp"]) for row in accepted),
        "rejected_tool_extension_bp": sum(int(row["tool_extension_length_bp"]) for row in rejected),
        "thresholds": {
            "max_short_extension_bp": args.max_short_extension,
            "min_long_join_spanning_reads": args.min_long_join_reads,
            "min_telomere_repeat_count": args.min_repeat_count,
        },
    }
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
