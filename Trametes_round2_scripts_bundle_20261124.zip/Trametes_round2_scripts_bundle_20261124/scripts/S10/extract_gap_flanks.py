#!/usr/bin/env python3
"""Extract left/right genomic flanks for unresolved assembly gaps."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    for raw in path.open():
        line = raw.strip()
        if not line:
            continue
        if line.startswith(">"):
            name = line[1:].split()[0]
            records[name] = []
        else:
            if name is None:
                raise ValueError("FASTA sequence before header")
            records[name].append(line)
    return {name: "".join(parts) for name, parts in records.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--genome", type=Path, required=True)
    parser.add_argument("--gaps", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--flank", type=int, default=50000)
    args = parser.parse_args()
    genome = read_fasta(args.genome)
    with args.gaps.open() as handle, args.output.open("w") as out:
        for row in csv.DictReader(handle, delimiter="\t"):
            seq = genome[row["chromosome"]]
            start0 = int(row["start_1based"]) - 1
            end0 = int(row["end_1based"])
            left_start = max(0, start0 - args.flank)
            right_end = min(len(seq), end0 + args.flank)
            records = [
                (f"{row['gap_id']}|L|{row['chromosome']}:{left_start + 1}-{start0}", seq[left_start:start0]),
                (f"{row['gap_id']}|R|{row['chromosome']}:{end0 + 1}-{right_end}", seq[end0:right_end]),
            ]
            for name, value in records:
                out.write(f">{name}\n")
                for pos in range(0, len(value), 80):
                    out.write(value[pos : pos + 80] + "\n")


if __name__ == "__main__":
    main()
