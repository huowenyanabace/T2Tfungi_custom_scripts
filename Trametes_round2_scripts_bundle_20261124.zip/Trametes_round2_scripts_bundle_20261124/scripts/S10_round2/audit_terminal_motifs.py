#!/usr/bin/env python3
"""Audit terminal telomere motif chains and evidence tiers."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def rc(seq: str) -> str:
    return seq.translate(COMP)[::-1]


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                records[name] = []
            elif name is None:
                raise ValueError("sequence before FASTA header")
            else:
                records[name].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def terminal_chain(seq: str, end: str, motif: str, window: int) -> tuple[int, int | None]:
    region = seq[:window] if end == "5prime" else seq[-window:]
    motifs = (motif, rc(motif))
    hits: list[tuple[int, int]] = []
    i = 0
    while i <= len(region) - len(motif):
        word = region[i : i + len(motif)]
        if min(sum(a != b for a, b in zip(word, query)) for query in motifs) <= 1:
            hits.append((i, i + len(motif)))
            i += len(motif)
        else:
            i += 1
    if not hits:
        return 0, None
    chains: list[list[tuple[int, int]]] = []
    for hit in hits:
        if chains and hit[0] - chains[-1][-1][0] <= 12:
            chains[-1].append(hit)
        else:
            chains.append([hit])
    if end == "5prime":
        best = max(chains, key=lambda c: (len(c), -c[0][0]))
        distance = best[0][0]
    else:
        best = max(chains, key=lambda c: (len(c), c[-1][1]))
        distance = len(region) - best[-1][1]
    return len(best), distance


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--genome", type=Path, required=True)
    parser.add_argument("--motif", default="AACCCT")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--window", type=int, default=2000)
    parser.add_argument("--strict-repeats", type=int, default=3)
    parser.add_argument("--strict-slack", type=int, default=500)
    parser.add_argument("--relaxed-repeats", type=int, default=2)
    parser.add_argument("--relaxed-slack", type=int, default=1000)
    args = parser.parse_args()

    records = read_fasta(args.genome)
    rows = []
    for chromosome, seq in records.items():
        for end in ("5prime", "3prime"):
            count, distance = terminal_chain(seq, end, args.motif.upper(), args.window)
            if count >= args.strict_repeats and distance is not None and distance <= args.strict_slack:
                tier = "strict"
            elif count >= args.relaxed_repeats and distance is not None and distance <= args.relaxed_slack:
                tier = "relaxed"
            else:
                tier = "fail"
            rows.append(
                {
                    "chromosome": chromosome,
                    "end": end,
                    "motif": args.motif.upper(),
                    "max_consecutive_approximate_repeats": count,
                    "distance_from_physical_end_bp": distance if distance is not None else "NA",
                    "evidence_tier": tier,
                }
            )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    counts = {tier: sum(row["evidence_tier"] == tier for row in rows) for tier in ("strict", "relaxed", "fail")}
    summary = {
        "chromosomes": len(records),
        "total_ends": len(rows),
        "strict_ends": counts["strict"],
        "relaxed_ends": counts["relaxed"],
        "failed_ends": counts["fail"],
        "terminal_criterion_pass": counts["fail"] == 0,
        "motif": args.motif.upper(),
        "strict_rule": f">={args.strict_repeats} consecutive approximate repeats within {args.strict_slack} bp",
        "relaxed_rule": f">={args.relaxed_repeats} consecutive approximate repeats within {args.relaxed_slack} bp",
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
