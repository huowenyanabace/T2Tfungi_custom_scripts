#!/usr/bin/env python3
"""Render reference-project-style Hi-C maps with HiCExplorer hicPlotMatrix."""

from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import tables


ROOT = Path(__file__).resolve().parents[2]


def make_display_matrix(source: Path, prefix: str, strip_chr_prefix: bool) -> Path:
    """Copy the accepted matrix and optionally shorten Chr01 labels to 01."""
    target_dir = ROOT / "work/visualization/hic_reference_style"
    target_dir.mkdir(parents=True, exist_ok=True)
    source_key = hashlib.sha256(str(source.resolve()).encode()).hexdigest()[:12]
    target = target_dir / f"{prefix}.{source_key}.display_labels.h5"
    shutil.copy2(source, target)
    if not strip_chr_prefix:
        return target
    with tables.open_file(target, mode="a") as handle:
        node = handle.root.intervals.chr_list
        original = node[:]
        renamed = []
        for value in original:
            text = value.decode() if isinstance(value, bytes) else str(value)
            if text.startswith("Chr") and text[3:].isdigit():
                text = text[3:]
            renamed.append(text.encode())
        node[:] = np.asarray(renamed, dtype=original.dtype)
        node.flush()
    return target


def plot(matrix: Path, output: Path, per_chromosome: bool) -> None:
    helper = Path(__file__).with_name("hicplotmatrix_reference.py")
    command = [
        sys.executable,
        str(helper),
        "--matrix", str(matrix),
        "--outFileName", str(output),
        "--colorMap", "coolwarm",
        "--clearMaskedBins",
        "--fontsize", "10",
        "--dpi", "600",
    ]
    if per_chromosome:
        command.append("--perChromosome")
    subprocess.run(command, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--matrix", type=Path, required=True, help="Accepted ICE-corrected HiCExplorer .h5 matrix")
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--species-label", required=True, help="Full display name retained in provenance")
    parser.add_argument("--keep-chr-prefix", action="store_true", help="Keep Chr01 labels instead of reference-style 01 labels")
    parser.add_argument("--prepare-only", action="store_true", help="Prepare display matrix and provenance without rerendering")
    args = parser.parse_args()

    if not args.matrix.is_file() or args.matrix.suffix != ".h5":
        raise FileNotFoundError(f"Corrected HiCExplorer H5 matrix is required: {args.matrix}")
    args.outdir.mkdir(parents=True, exist_ok=True)
    display_matrix = make_display_matrix(args.matrix, args.prefix, not args.keep_chr_prefix)

    if not args.prepare_only:
        for suffix in ("pdf", "png", "svg"):
            plot(display_matrix, args.outdir / f"{args.prefix}.genome.{suffix}", per_chromosome=False)
            plot(display_matrix, args.outdir / f"{args.prefix}.per_chromosome.{suffix}", per_chromosome=True)

    provenance = args.outdir / f"{args.prefix}.provenance.tsv"
    provenance.write_text(
        "field\tvalue\n"
        f"species\t{args.species_label}\n"
        f"accepted_corrected_matrix\t{args.matrix}\n"
        f"display_matrix\t{display_matrix}\n"
        "renderer\tHiCExplorer hicPlotMatrix\n"
        "small_chromosome_display\tproject wrapper removes the upstream <5-bin plotting guard only\n"
        "colormap\tcoolwarm\n"
        "clear_masked_bins\ttrue\n"
        "raster_dpi\t600\n"
        f"chromosome_labels\t{'Chr01-Chr14' if args.keep_chr_prefix else '01-14'}\n"
    )


if __name__ == "__main__":
    main()
