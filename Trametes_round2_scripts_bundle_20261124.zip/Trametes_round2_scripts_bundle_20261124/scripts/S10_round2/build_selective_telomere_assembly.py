#!/usr/bin/env python3
"""Promote only needed, terminally validated FungalTeloExtender edits."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


COMPLEMENT = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def reverse_complement(seq: str) -> str:
    return seq.translate(COMPLEMENT)[::-1]


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name: str | None = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                if name in records:
                    raise ValueError(f"duplicate FASTA identifier: {name}")
                records[name] = []
            elif name is None:
                raise ValueError(f"sequence precedes header in {path}")
            else:
                records[name].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def write_fasta(records: dict[str, str], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for name, seq in records.items():
            handle.write(f">{name}\n")
            for start in range(0, len(seq), 80):
                handle.write(seq[start : start + 80] + "\n")


def motif_status(seq: str, end: str, motif: str, window: int) -> tuple[int, int | None]:
    motifs = {motif.upper(), reverse_complement(motif.upper())}
    region = seq[:window] if end == "5prime" else seq[-window:]
    hits: list[tuple[int, int]] = []
    i = 0
    while i <= len(region) - len(motif):
        word = region[i : i + len(motif)]
        if min(sum(a != b for a, b in zip(word, query)) for query in motifs) <= 1:
            hits.append((i, i + len(motif)))
            i += len(motif)
        else:
            i += 1
    if not hits:
        return 0, None
    chains: list[list[tuple[int, int]]] = []
    for hit in hits:
        if chains and hit[0] - chains[-1][-1][0] <= 12:
            chains[-1].append(hit)
        else:
            chains.append([hit])
    if end == "5prime":
        best = max(chains, key=lambda chain: (len(chain), -chain[0][0]))
        distance = best[0][0]
    else:
        best = max(chains, key=lambda chain: (len(chain), chain[-1][1]))
        distance = len(region) - best[-1][1]
    return len(best), distance


def read_audit(path: Path | None) -> dict[tuple[str, str], dict[str, str]]:
    if path is None:
        return {}
    with path.open() as handle:
        return {
            (row["chromosome"], row["end"]): row
            for row in csv.DictReader(handle, delimiter="\t")
        }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--before", type=Path, required=True)
    parser.add_argument("--tool-extended", type=Path, required=True)
    parser.add_argument("--analysis-json", type=Path, required=True)
    parser.add_argument("--pass-ul-audit", type=Path, required=True)
    parser.add_argument("--pass-all-audit", type=Path)
    parser.add_argument("--motif", default="AACCCT")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--decisions", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--terminal-window", type=int, default=2000)
    parser.add_argument("--terminal-slack", type=int, default=500)
    parser.add_argument("--min-existing-repeats", type=int, default=3)
    parser.add_argument("--max-short-extension", type=int, default=2000)
    parser.add_argument("--min-extension-repeats", type=int, default=3)
    parser.add_argument("--min-long-join-reads", type=int, default=1)
    parser.add_argument("--min-long-terminal-reads", type=int, default=1)
    args = parser.parse_args()

    before = read_fasta(args.before)
    extended = read_fasta(args.tool_extended)
    analysis = json.loads(args.analysis_json.read_text())
    items = {(x["chromosome"], x["end"]): x for x in analysis["extensions"]}
    ul_audit = read_audit(args.pass_ul_audit)
    all_audit = read_audit(args.pass_all_audit)

    output: dict[str, str] = {}
    decisions: list[dict[str, object]] = []
    for chromosome, original in before.items():
        item5 = items.get((chromosome, "5prime"))
        item3 = items.get((chromosome, "3prime"))
        ext5_len = int(item5["extension_length"]) if item5 else 0
        ext3_len = int(item3["extension_length"]) if item3 else 0
        tool_seq = extended[chromosome]
        core_end = len(tool_seq) - ext3_len if ext3_len else len(tool_seq)
        if tool_seq[ext5_len:core_end] != original:
            raise ValueError(f"tool-extended core differs from input: {chromosome}")
        candidates = {
            "5prime": tool_seq[:ext5_len],
            "3prime": tool_seq[core_end:] if ext3_len else "",
        }
        accepted: dict[str, str] = {"5prime": "", "3prime": ""}

        for end, item in (("5prime", item5), ("3prime", item3)):
            existing_count, existing_distance = motif_status(
                original, end, args.motif, args.terminal_window
            )
            existing_complete = (
                existing_count >= args.min_existing_repeats
                and existing_distance is not None
                and existing_distance <= args.terminal_slack
            )
            key = (chromosome, end)
            ul = ul_audit.get(key, {})
            aux = all_audit.get(key, {})
            ul_join = int(ul.get("post_join_spanning_read_count", 0))
            ul_terminal = int(ul.get("post_terminal_reaching_read_count", 0))
            all_join = int(aux.get("post_join_spanning_read_count", 0))
            all_terminal = int(aux.get("post_terminal_reaching_read_count", 0))

            if existing_complete:
                decision = "already_telomeric"
                reason = "input_end_has_terminal_motif_array"
                extension_len = int(item["extension_length"]) if item else 0
                repeat_count = int(item["repeat_count"]) if item else 0
            elif item is None:
                decision = "unresolved"
                reason = "no_extension_candidate"
                extension_len = 0
                repeat_count = 0
            else:
                extension_len = int(item["extension_length"])
                repeat_count = int(item["repeat_count"])
                candidate = candidates[end]
                candidate_count, candidate_distance = motif_status(
                    candidate, end, args.motif, args.terminal_window
                )
                candidate_terminal = (
                    candidate_count >= args.min_extension_repeats
                    and candidate_distance is not None
                    and candidate_distance <= args.terminal_slack
                )
                if not candidate_terminal:
                    decision = "rejected"
                    reason = "candidate_lacks_terminal_motif_array"
                elif extension_len <= args.max_short_extension and repeat_count >= args.min_extension_repeats:
                    decision = "accepted"
                    reason = "short_terminal_motif_extension"
                    accepted[end] = candidate
                elif (
                    ul_join >= args.min_long_join_reads
                    and ul_terminal >= args.min_long_terminal_reads
                ):
                    decision = "accepted"
                    reason = "long_extension_with_UL_join_and_terminal_support"
                    accepted[end] = candidate
                else:
                    decision = "rejected"
                    reason = "long_extension_lacks_required_UL_support"

            decisions.append(
                {
                    "chromosome": chromosome,
                    "end": end,
                    "existing_repeat_count": existing_count,
                    "existing_terminal_distance_bp": (
                        existing_distance if existing_distance is not None else "NA"
                    ),
                    "tool_extension_length_bp": extension_len,
                    "tool_repeat_count": repeat_count,
                    "pass_ul_join_reads": ul_join,
                    "pass_ul_terminal_reads": ul_terminal,
                    "pass_all_join_reads": all_join,
                    "pass_all_terminal_reads": all_terminal,
                    "decision": decision,
                    "decision_reason": reason,
                    "accepted_extension_bp": len(accepted[end]),
                }
            )

        output[chromosome] = accepted["5prime"] + original + accepted["3prime"]

    final_complete = 0
    for seq in output.values():
        for end in ("5prime", "3prime"):
            count, distance = motif_status(seq, end, args.motif, args.terminal_window)
            if count >= args.min_existing_repeats and distance is not None and distance <= args.terminal_slack:
                final_complete += 1

    write_fasta(output, args.output)
    args.decisions.parent.mkdir(parents=True, exist_ok=True)
    with args.decisions.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(decisions[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(decisions)

    summary = {
        "chromosomes": len(output),
        "input_bp": sum(len(x) for x in before.values()),
        "output_bp": sum(len(x) for x in output.values()),
        "accepted_extensions": sum(x["decision"] == "accepted" for x in decisions),
        "already_telomeric_ends": sum(x["decision"] == "already_telomeric" for x in decisions),
        "rejected_extensions": sum(x["decision"] == "rejected" for x in decisions),
        "unresolved_ends": sum(x["decision"] == "unresolved" for x in decisions),
        "terminal_motif_ends": final_complete,
        "total_ends": 2 * len(output),
        "t2t_terminal_criterion_pass": final_complete == 2 * len(output),
        "thresholds": {
            "terminal_window_bp": args.terminal_window,
            "terminal_slack_bp": args.terminal_slack,
            "min_existing_repeats": args.min_existing_repeats,
            "max_short_extension_bp": args.max_short_extension,
            "min_extension_repeats": args.min_extension_repeats,
            "min_long_UL_join_reads": args.min_long_join_reads,
            "min_long_UL_terminal_reads": args.min_long_terminal_reads,
        },
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
