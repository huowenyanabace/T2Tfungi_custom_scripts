#!/usr/bin/env bash
set -Eeuo pipefail

usage() {
  printf 'Usage: %s --cool FILE --outdir DIR --prefix NAME [--dry-run]\n' "$0"
}

cool=""
outdir=""
prefix=""
dry_run=false

while (($#)); do
  case "$1" in
    --cool) cool=$2; shift 2 ;;
    --outdir) outdir=$2; shift 2 ;;
    --prefix) prefix=$2; shift 2 ;;
    --dry-run) dry_run=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) printf 'Unknown argument: %s\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ -n "$cool" && -n "$outdir" && -n "$prefix" ]] || { usage >&2; exit 2; }
[[ -s "$cool" ]] || { printf 'Input cooler is missing or empty: %s\n' "$cool" >&2; exit 2; }

env_bin=/home/huowenyan/miniconda3/envs/hicexplorer/bin
convert="$env_bin/hicConvertFormat"
correct="$env_bin/hicCorrectMatrix"
plot="$env_bin/hicPlotMatrix"

for executable in "$convert" "$correct" "$plot"; do
  [[ -x "$executable" ]] || { printf 'Executable missing: %s\n' "$executable" >&2; exit 2; }
done

h5="$outdir/${prefix}_50000.h5"
corrected="$outdir/${prefix}_50000.corrected.h5"
diagnostic="$outdir/${prefix}_50000.diagnostic.png"
genome_pdf="$outdir/${prefix}_50000.genome.pdf"
per_chromosome_pdf="$outdir/${prefix}_50000.per_chromosome.pdf"

if "$dry_run"; then
  printf '%s\n' "$h5" "$corrected" "$diagnostic" "$genome_pdf" "$per_chromosome_pdf"
  exit 0
fi

mkdir -p "$outdir"
export MPLBACKEND=Agg

"$convert" \
  -m "$cool" \
  --outFileName "$h5" \
  --inputFormat cool \
  --outputFormat h5

"$correct" diagnostic_plot \
  -m "$h5" \
  -o "$diagnostic"

"$correct" correct \
  -m "$h5" \
  --filterThreshold -18 18 \
  -o "$corrected"

common_plot=(
  "$plot"
  -m "$corrected"
  --dpi 600
  --colorMap coolwarm
  --fontsize 10
  --clearMaskedBins
)

"${common_plot[@]}" \
  --outFileName "$genome_pdf"

"${common_plot[@]}" \
  --perChromosome \
  --outFileName "$per_chromosome_pdf"

for output in "$h5" "$corrected" "$diagnostic" "$genome_pdf" "$per_chromosome_pdf"; do
  [[ -s "$output" ]] || { printf 'Expected output missing or empty: %s\n' "$output" >&2; exit 3; }
done
