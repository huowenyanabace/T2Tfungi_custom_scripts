#!/usr/bin/env python3
"""Locate selected source-contig segments exactly in final chromosomes."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def rc(seq: str) -> str:
    return seq.translate(COMP)[::-1]


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                records[name] = []
            elif name is None:
                raise ValueError("sequence before FASTA header")
            else:
                records[name].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-fasta", type=Path, required=True)
    parser.add_argument("--final-fasta", type=Path, required=True)
    parser.add_argument("--segments", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    source = read_fasta(args.source_fasta)
    final = read_fasta(args.final_fasta)
    with args.segments.open() as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    output = []
    for row in rows:
        chromosome = row["chromosome"]
        source_id = row["source_id"]
        start = int(row["source_start_1based"])
        end = int(row["source_end_1based"])
        orientation = row["orientation"]
        segment = source[source_id][start - 1 : end]
        if orientation == "-":
            segment = rc(segment)
        position = final[chromosome].find(segment)
        if position < 0:
            raise ValueError(f"segment not found: {chromosome} {source_id}:{start}-{end}{orientation}")
        second = final[chromosome].find(segment, position + 1)
        if second >= 0:
            raise ValueError(f"segment is non-unique: {chromosome} {source_id}:{start}-{end}{orientation}")
        output.append(
            {
                **row,
                "chromosome_start_1based": position + 1,
                "chromosome_end_1based": position + len(segment),
                "retained_bp": len(segment),
            }
        )

    by_chromosome: dict[str, list[dict[str, str | int]]] = {}
    for row in output:
        by_chromosome.setdefault(str(row["chromosome"]), []).append(row)
    for chromosome, items in by_chromosome.items():
        ordered = sorted(items, key=lambda x: int(x["part"]))
        starts = [int(x["chromosome_start_1based"]) for x in ordered]
        if starts != sorted(starts):
            raise ValueError(f"component order mismatch in {chromosome}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fields = list(output[0])
    with args.output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(output)


if __name__ == "__main__":
    main()
