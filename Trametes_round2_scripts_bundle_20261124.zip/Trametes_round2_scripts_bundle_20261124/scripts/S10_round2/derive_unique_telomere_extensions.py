#!/usr/bin/env python3
"""Derive chromosome-end extensions from uniquely placed ONT alignments.

The telomere motif must already have been identified by FungalTeloExtender.
This selector corrects read orientation, requires a full-genome primary mapping
to the intended chromosome end, clusters inferred extension lengths, and emits
an FungalTeloExtender-compatible candidate assembly for independent remapping.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
from collections import defaultdict
from pathlib import Path


COMP = str.maketrans("ACGTNacgtn", "TGCANtgcan")


def rc(seq: str) -> str:
    return seq.translate(COMP)[::-1]


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                records[name] = []
            elif name is None:
                raise ValueError("sequence before FASTA header")
            else:
                records[name].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def write_fasta(records: dict[str, str], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for name, seq in records.items():
            handle.write(f">{name}\n")
            for start in range(0, len(seq), 80):
                handle.write(seq[start : start + 80] + "\n")


def read_fastq(path: Path) -> dict[str, str]:
    opener = gzip.open if path.suffix == ".gz" else open
    records: dict[str, str] = {}
    with opener(path, "rt") as handle:
        while True:
            header = handle.readline()
            if not header:
                break
            seq = handle.readline().strip().upper()
            plus = handle.readline()
            qual = handle.readline()
            if not (header.startswith("@") and plus.startswith("+") and qual):
                raise ValueError(f"malformed FASTQ near {header.strip()}")
            records[header[1:].split()[0]] = seq
    return records


def hamming(a: str, b: str) -> int:
    return sum(x != y for x, y in zip(a, b))


def terminal_motif(seq: str, end: str, motif: str, window: int) -> tuple[int, int | None, int | None]:
    region = seq[:window] if end == "5prime" else seq[-window:]
    motifs = (motif, rc(motif))
    hits: list[tuple[int, int]] = []
    i = 0
    while i <= len(region) - len(motif):
        word = region[i : i + len(motif)]
        if min(hamming(word, query) for query in motifs) <= 1:
            hits.append((i, i + len(motif)))
            i += len(motif)
        else:
            i += 1
    if not hits:
        return 0, None, None
    # A handful of mismatch-tolerant 6-mers can occur randomly in 2 kb.  A
    # telomere call therefore requires a local chain of repeats, allowing at
    # most one missing repeat (successive starts no more than 12 bp apart).
    chains: list[list[tuple[int, int]]] = []
    for hit in hits:
        if chains and hit[0] - chains[-1][-1][0] <= 12:
            chains[-1].append(hit)
        else:
            chains.append([hit])
    if end == "5prime":
        best = max(chains, key=lambda chain: (len(chain), -chain[0][0]))
        distance = best[0][0]
        boundary = best[0][0]
    else:
        best = max(chains, key=lambda chain: (len(chain), chain[-1][1]))
        distance = len(region) - best[-1][1]
        boundary = best[-1][1]
    return len(best), distance, boundary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--genome", type=Path, required=True)
    parser.add_argument("--endpoint-alignments", type=Path, required=True)
    parser.add_argument("--reads", type=Path, required=True)
    parser.add_argument("--motif", default="AACCCT")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--terminal-window", type=int, default=2000)
    parser.add_argument("--terminal-slack", type=int, default=500)
    parser.add_argument("--min-repeats", type=int, default=3)
    parser.add_argument("--max-extension", type=int, default=190000)
    args = parser.parse_args()

    genome = read_fasta(args.genome)
    reads = read_fastq(args.reads)
    candidates: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)

    with args.endpoint_alignments.open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            read_id = row["read_id"]
            if read_id not in reads:
                continue
            seq = reads[read_id]
            qlen = int(row["read_len"])
            qstart = int(row["qstart"])
            qend = int(row["qend"])
            strand = row["strand"]
            end = row["end"]
            target_start = int(row["tstart"])
            target_end = int(row["tend"])
            target_len = int(row["target_len"])
            if len(seq) != qlen:
                continue
            if strand == "-":
                seq = rc(seq)
                qstart, qend = qlen - qend, qlen - qstart

            if end == "5prime":
                novel_len = qstart - target_start
                if novel_len < 20:
                    continue
                extension = seq[:novel_len]
            else:
                target_tail = target_len - target_end
                novel_len = (qlen - qend) - target_tail
                if novel_len < 20:
                    continue
                extension = seq[qlen - novel_len :]

            if len(extension) > args.max_extension:
                continue
            count, distance, terminal_boundary = terminal_motif(
                extension, end, args.motif.upper(), args.terminal_window
            )
            if (
                count < args.min_repeats
                or distance is None
                or distance > args.terminal_slack
                or terminal_boundary is None
            ):
                continue

            # Remove non-genomic sequence outside the terminal repeat array.
            if end == "5prime" and distance:
                extension = extension[distance:]
            elif end == "3prime" and distance:
                extension = extension[: len(extension) - distance]
            candidates[(row["chromosome"], end)].append(
                {
                    "read_id": read_id,
                    "sequence": extension,
                    "length": len(extension),
                    "motif_count": count,
                    "identity": float(row["identity"]),
                    "mapq": int(row["mapq"]),
                    "alignment_bp": target_end - target_start,
                }
            )

    selected: dict[tuple[str, str], dict[str, object]] = {}
    detail_rows: list[dict[str, object]] = []
    for key, items in sorted(candidates.items()):
        bins: dict[int, list[dict[str, object]]] = defaultdict(list)
        for item in items:
            length = int(item["length"])
            width = 200 if length <= 2000 else 1000
            bins[length // width].append(item)
        ranked_bins = sorted(
            bins.values(),
            key=lambda group: (
                len({str(x["read_id"]) for x in group}),
                sum(int(x["motif_count"]) for x in group),
                sum(float(x["identity"]) for x in group),
            ),
            reverse=True,
        )
        cluster = ranked_bins[0]
        best = max(
            cluster,
            key=lambda x: (
                int(x["motif_count"]),
                float(x["identity"]),
                int(x["mapq"]),
                int(x["alignment_bp"]),
            ),
        )
        best = dict(best)
        best["cluster_read_count"] = len({str(x["read_id"]) for x in cluster})
        best["all_candidate_read_count"] = len({str(x["read_id"]) for x in items})
        selected[key] = best
        detail_rows.append(
            {
                "chromosome": key[0],
                "end": key[1],
                "selected_read_id": best["read_id"],
                "extension_length_bp": best["length"],
                "motif_count": best["motif_count"],
                "identity": f"{float(best['identity']):.5f}",
                "mapq": best["mapq"],
                "alignment_bp": best["alignment_bp"],
                "cluster_read_count": best["cluster_read_count"],
                "all_candidate_read_count": best["all_candidate_read_count"],
            }
        )

    extended: dict[str, str] = {}
    extensions: list[dict[str, object]] = []
    for chromosome, original in genome.items():
        left = str(selected.get((chromosome, "5prime"), {}).get("sequence", ""))
        right = str(selected.get((chromosome, "3prime"), {}).get("sequence", ""))
        extended[chromosome] = left + original + right
        for end, extension in (("5prime", left), ("3prime", right)):
            item = selected.get((chromosome, end))
            if not item:
                continue
            extensions.append(
                {
                    "chromosome": chromosome,
                    "end": end,
                    "original_length": len(original),
                    "extension_length": len(extension),
                    "final_length": len(original) + len(extension),
                    "motif": args.motif.upper(),
                    "repeat_count": int(item["motif_count"]),
                    "quality_score": float(item["identity"]),
                    "method": "unique_full_genome_primary_read",
                    "polished": False,
                    "source_read_id": item["read_id"],
                    "cluster_read_count": item["cluster_read_count"],
                }
            )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_fasta(extended, args.output_dir / "extended_genome.fasta")
    with (args.output_dir / "selected_extensions.tsv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(detail_rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(detail_rows)
    with (args.output_dir / "telomere_reads.tsv").open("w") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["Chrom_End", "Read_ID"],
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        for item in extensions:
            writer.writerow(
                {
                    "Chrom_End": f"{item['chromosome']}_{item['end']}",
                    "Read_ID": item["source_read_id"],
                }
            )
    analysis = {
        "version": "unique-primary-selector-1",
        "summary": {
            "chromosomes": len(genome),
            "extended_ends": len(extensions),
            "original_size": sum(len(x) for x in genome.values()),
            "extended_size": sum(len(x) for x in extended.values()),
            "total_extension": sum(int(x["extension_length"]) for x in extensions),
        },
        "motifs": [{"sequence": args.motif.upper(), "source": "FungalTeloExtender_genome_algorithm"}],
        "extensions": extensions,
    }
    (args.output_dir / "analysis_results.json").write_text(json.dumps(analysis, indent=2) + "\n")


if __name__ == "__main__":
    main()
