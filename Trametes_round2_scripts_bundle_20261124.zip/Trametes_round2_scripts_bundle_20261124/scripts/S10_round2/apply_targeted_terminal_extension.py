#!/usr/bin/env python3
"""Apply one reviewed terminal extension to an otherwise accepted assembly."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def read_fasta(path: Path) -> dict[str, str]:
    records: dict[str, list[str]] = {}
    name = None
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                name = line[1:].split()[0]
                records[name] = []
            elif name is None:
                raise ValueError("sequence before FASTA header")
            else:
                records[name].append(line.upper())
    return {name: "".join(parts) for name, parts in records.items()}


def write_fasta(records: dict[str, str], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for name, seq in records.items():
            handle.write(f">{name}\n")
            for start in range(0, len(seq), 80):
                handle.write(seq[start : start + 80] + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--candidate-extended", type=Path, required=True)
    parser.add_argument("--analysis-json", type=Path, required=True)
    parser.add_argument("--chromosome", required=True)
    parser.add_argument("--end", choices=["5prime", "3prime"], required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--evidence", required=True)
    args = parser.parse_args()

    base = read_fasta(args.base)
    candidate = read_fasta(args.candidate_extended)
    data = json.loads(args.analysis_json.read_text())
    item = next(
        (
            row
            for row in data["extensions"]
            if row["chromosome"] == args.chromosome and row["end"] == args.end
        ),
        None,
    )
    if item is None:
        raise ValueError(f"candidate not found: {args.chromosome} {args.end}")
    length = int(item["extension_length"])
    if length <= 0:
        raise ValueError("extension length must be positive")
    if args.end == "5prime":
        extension = candidate[args.chromosome][:length]
        base[args.chromosome] = extension + base[args.chromosome]
    else:
        extension = candidate[args.chromosome][-length:]
        base[args.chromosome] = base[args.chromosome] + extension
    if "N" in extension:
        raise ValueError("terminal extension contains N")

    write_fasta(base, args.output)
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(
        json.dumps(
            {
                "chromosome": args.chromosome,
                "end": args.end,
                "extension_length_bp": length,
                "repeat_count": item.get("repeat_count"),
                "method": item.get("method"),
                "source_read_id": item.get("source_read_id"),
                "cluster_read_count": item.get("cluster_read_count"),
                "evidence": args.evidence,
                "output": str(args.output),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
