#!/usr/bin/env python3
"""Run HiCExplorer hicPlotMatrix while allowing genuine 2--4-bin chromosomes.

HiCExplorer 3.7.2 skips every matrix smaller than five bins even though
Matplotlib can render matrices with two or more bins.  This project-level
wrapper changes only that display guard; all matrices, normalization and
colour scaling remain under HiCExplorer control.
"""

from __future__ import annotations

import numpy as np
from mpl_toolkits.axes_grid1 import make_axes_locatable

from hicexplorer import hicPlotMatrix as hpm


_original_plot_heatmap = hpm.plotHeatmap


def plot_heatmap_allow_small(
    ma,
    chrBinBoundaries,
    fig,
    position,
    args,
    cmap,
    xlabel=None,
    ylabel=None,
    start_pos=None,
    start_pos2=None,
    pNorm=None,
    pAxis=None,
    pBigwig=None,
    pLoops=None,
    pHiCMatrix=None,
    pChromsomeStartEndDict=None,
    pResolution=None,
):
    """Use native HiCExplorer rendering, including for 2--4-bin matrices."""
    if ma.shape[0] >= 5 or ma.shape[0] < 2 or pBigwig is not None or pLoops:
        return _original_plot_heatmap(
            ma,
            chrBinBoundaries,
            fig,
            position,
            args,
            cmap,
            xlabel=xlabel,
            ylabel=ylabel,
            start_pos=start_pos,
            start_pos2=start_pos2,
            pNorm=pNorm,
            pAxis=pAxis,
            pBigwig=pBigwig,
            pLoops=pLoops,
            pHiCMatrix=pHiCMatrix,
            pChromsomeStartEndDict=pChromsomeStartEndDict,
            pResolution=pResolution,
        )

    axis = pAxis if pAxis is not None else fig.add_axes(position)
    if args.title:
        axis.set_title(hpm.toString(args.title))
    if start_pos2 is None:
        start_pos2 = start_pos

    # Coordinates supplied by HiCExplorer are bin starts.  With fewer than
    # five bins, pcolormesh's implicit centering creates a negative first
    # coordinate and discards part of the final bin.  Use true bin edges.
    x_end = max(chrBinBoundaries.values())
    y_end = x_end
    x_edges = np.r_[np.asarray(start_pos), x_end]
    y_edges = np.r_[np.asarray(start_pos2), y_end]
    xmesh, ymesh = np.meshgrid(x_edges, y_edges)
    image = axis.pcolormesh(
        xmesh.T,
        ymesh.T,
        ma,
        vmin=args.vMin,
        vmax=args.vMax,
        cmap=cmap,
        norm=pNorm,
    )
    image.set_rasterized(True)

    axis.set_xlim(float(x_edges[0]), float(x_edges[-1]))
    axis.set_ylim(float(y_edges[0]), float(y_edges[-1]))
    axis.set_xticks(x_edges)
    axis.set_yticks(y_edges)

    xlabels = hpm.relabel_ticks(axis.get_xticks())
    axis.get_xaxis().set_tick_params(which="both", bottom="on", direction="out")
    axis.set_xticklabels(xlabels, size="small", rotation=args.rotationX)
    ylabels = hpm.relabel_ticks(axis.get_yticks())
    axis.get_yaxis().set_tick_params(which="both", bottom="on", direction="out")
    axis.set_yticklabels(ylabels, size="small")

    divider = make_axes_locatable(axis)
    color_axis = divider.append_axes("right", size="2.5%", pad=0.09)
    colorbar = fig.colorbar(image, cax=color_axis)
    colorbar.solids.set_edgecolor("face")
    if args.scoreName:
        colorbar.ax.set_ylabel(args.scoreName, size=8)
    if ylabel is not None:
        axis.set_ylabel(hpm.toString(ylabel), fontsize=args.fontsize)
    if xlabel is not None:
        axis.set_xlabel(hpm.toString(xlabel), fontsize=args.fontsize)
    axis.invert_yaxis()


hpm.plotHeatmap = plot_heatmap_allow_small


if __name__ == "__main__":
    hpm.main()
