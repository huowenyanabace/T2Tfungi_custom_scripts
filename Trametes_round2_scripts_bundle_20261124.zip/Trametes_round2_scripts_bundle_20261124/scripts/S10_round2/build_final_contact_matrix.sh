#!/usr/bin/env bash
set -Eeuo pipefail

if (($# != 6)); then
  echo "usage: $0 LIFTOVER_TSV FINAL_FASTA MERGED_NODUPS BIN_SIZE OUTDIR PREFIX" >&2
  exit 2
fi

liftover=$1
fasta=$2
mnd=$3
bin_size=$4
outdir=$5
prefix=$6

mkdir -p "$outdir"
samtools faidx "$fasta"
cut -f1,2 "${fasta}.fai" > "$outdir/${prefix}.chrom.sizes"

LC_ALL=C gawk -v map_file="$liftover" \
  -v size_file="$outdir/${prefix}.chrom.sizes" \
  -v bin_size="$bin_size" \
  -v stats_file="$outdir/${prefix}.${bin_size}.mapping_stats.tsv" '
BEGIN {
  FS="[ \t]+"; OFS="\t";
  offset=0;
  while ((getline line < size_file) > 0) {
    split(line, a, /[ \t]+/);
    chrom_length[a[1]]=a[2];
    chrom_offset[a[1]]=offset;
    offset += int((a[2] + bin_size - 1) / bin_size);
  }
  close(size_file);
  while ((getline line < map_file) > 0) {
    if (line ~ /^chromosome/) continue;
    split(line, a, /\t/);
    source=a[3];
    source_chrom[source]=a[1];
    source_start[source]=a[4]-1;
    source_end[source]=a[5]-1;
    source_orientation[source]=a[6];
    chromosome_start[source]=a[7]-1;
  }
  close(map_file);
}
function lift(source, pos,    chrom, mapped) {
  if (!(source in source_chrom)) return -1;
  if (pos < source_start[source] || pos > source_end[source]) return -1;
  chrom=source_chrom[source];
  if (source_orientation[source] == "+") {
    mapped=chromosome_start[source] + pos - source_start[source];
  } else {
    mapped=chromosome_start[source] + source_end[source] - pos;
  }
  if (mapped < 0 || mapped >= chrom_length[chrom]) return -1;
  return mapped;
}
{
  total++;
  c1=$2; p1=$3; c2=$6; p2=$7;
  m1=lift(c1,p1); m2=lift(c2,p2);
  if (m1 < 0 || m2 < 0) {dropped++; next}
  chr1=source_chrom[c1]; chr2=source_chrom[c2];
  b1=chrom_offset[chr1] + int(m1/bin_size);
  b2=chrom_offset[chr2] + int(m2/bin_size);
  if (b1>b2) {tmp=b1; b1=b2; b2=tmp}
  counts[b1 SUBSEP b2]++;
  kept++;
}
END {
  for (key in counts) {
    split(key, a, SUBSEP);
    print a[1], a[2], counts[key];
  }
  print "metric\tvalue" > stats_file;
  print "total_pairs\t" total >> stats_file;
  print "kept_pairs\t" kept >> stats_file;
  print "dropped_pairs\t" dropped >> stats_file;
  print "kept_fraction\t" (total ? kept/total : 0) >> stats_file;
}' "$mnd" | LC_ALL=C sort -T "$outdir" -k1,1n -k2,2n > "$outdir/${prefix}.${bin_size}.pixels.tsv"

cooler load -f coo "$outdir/${prefix}.chrom.sizes:${bin_size}" \
  "$outdir/${prefix}.${bin_size}.pixels.tsv" \
  "$outdir/${prefix}.${bin_size}.cool"
