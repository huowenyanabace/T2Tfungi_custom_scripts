Trametes round2 脚本与过程记录包
打包日期：2026-11-24
范围：19个片段选择与提取、14组布局、5处连接处理、读段审计、端粒延伸、坐标转换及最终Hi-C绘图。

目录
scripts/S08_round2/：片段构建、局部测试、端点审计及五处连接编辑。
scripts/S10/：前一轮去冗余、gap/端粒编辑和读段审计；round2沿用其中的候选与验证工具。
scripts/S10_round2/：修正版延伸工具、唯一定位延伸、选择性编辑、末端审计及最终Hi-C。
upstream_preparation/：Pilon后contig统一编号、核输入准备脚本和来源映射。
external_sources/FungalTeloExtender/：本地上游工具源文件快照，包括两个motif鉴定脚本。
external_sources/Telo_Visi/：原R统计绘图脚本及V2版本。
external_sources/TGS-GapCloser/：已安装1.2.1版本的主控shell脚本。
manual_review/：19片段清单、14组排列、AGP、连接编辑和组件坐标表。
logs/：S08_round2、S10及S10_round2实际保留的日志，包括不同尝试，不能把每次尝试均当作最终采用。
reports/：原有round2报告和逐连接/末端审计，历史术语与结论保持原样。
environment/：现有相关conda环境的包名、版本、build及channel快照，不代表每个包都在该步骤调用。
SOURCE_MANIFEST.tsv：每个原始文件的来源路径、包内路径及SHA-256。
SHA256SUMS：包内所有文件的校验和。

核心顺序
1. scripts/S08_round2/build_reviewed_assembly.py
   输入 source-fasta、component_selection.tsv、chromosome_layout.tsv。
   输出 components.fasta、reviewed.assembly、chromosomes.500N.fasta及AGP。
   选择和布局是预先审查的输入；脚本负责精确提取、方向转换及拼接。
2. scripts/S08_round2/build_test_scaffold.py、audit_endpoint_read_pairs.sh
   用于局部候选连接准备和证据审计；find_gfa_paths.py为图路径检查辅助脚本。
3. TGS-GapCloser生成局部填充候选；前4处来自S10候选，Chr14来自alt005_002专门运行。
   Chr14实际参数见 logs/S08_round2/Trametes_elegans.alt005_002.tgs_no_gcheck_v2.log。
4. scripts/S08_round2/build_round2_nogap.py
   输入 --round2-500n、--old-candidate、--new-candidate、--new-detail；输出无N序列、编辑表和最终连接坐标。
5. Minimap2对候选进行原始长读段回贴；scripts/S10/audit_gap_spanning_reads.py统计跨接证据。
6. scripts/S10_round2/FungalTeloExtender_strand_fixed.py及derive_unique_telomere_extensions.py产生端粒候选。
   build_selective_telomere_assembly.py、apply_targeted_terminal_extension.py筛选/应用编辑。
   scripts/S10/audit_telomere_extensions.py和scripts/S10_round2/audit_terminal_motifs.py执行复核。
   这些脚本涉及多轮候选和针对性处理，不应简单对同一FASTA顺序全部运行。
7. scripts/S10_round2/locate_final_components.py定位最终组件。
   build_final_contact_matrix.sh转换Juicer有效互作坐标并建立Cooler矩阵。
   plot_final_hic.py和plot_final_hic_hicexplorer.sh提供绘图入口；hicplotmatrix_reference.py为配套绘图辅助。
8. external_sources/Telo_Visi/telomere_motif_plot_V2.R执行最终末端近似motif统计/绘图。

重用说明
原脚本按原字节保存，未改写路径、阈值或算法。部分文件含服务器绝对路径。
这是脚本与证据归档，不是安装完成的独立运行环境。FASTQ、BAM、源/候选FASTA、完整Hi-C矩阵和数据库未打包；实际输入路径可从来源清单、报告、日志及脚本参数查阅。
TGS-GapCloser主控脚本需要同目录tgsgapcloserbin/下的tgsgapcandidate、tgsgapcloser、tgsseqgen和tgsseqsplit编译程序，及Minimap2/Racon等外部工具；本包不包含这些二进制程序。
首次复用请查看各脚本参数定义，并为输出使用独立目录。未提供虚构的历史一键运行命令。

校验
在包根目录运行：sha256sum -c SHA256SUMS
脚本语法检查结果见 syntax_checks.tsv；语法检查不等同重新执行生物信息学流程。
