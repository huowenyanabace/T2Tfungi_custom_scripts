#!/usr/bin/env python3
"""
TelomereMotifIdentifier_Genome - Telomere Motif Identification Tool (Genome Algorithm)
====================================================================
Author: FungalTeloExtender Team
Version: 1.0.0
License: MIT
"""

import os
import sys
import argparse
import logging
import gzip
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict
from pathlib import Path
import json
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Constants
# ============================================================================

VERSION = "1.0.0"
ALGORITHM = "Genome"

# Known fungal telomere motif database (for reference and validation)
KNOWN_FUNGAL_TELOMERES = {
    "TTAGGG": ["Neurospora crassa", "Magnaporthe oryzae", "Most filamentous fungi"],
    "TTAGGC": ["Aspergillus fumigatus", "Aspergillus niger", "Aspergillus nidulans"],
    "TCTGGGTG": ["Candida albicans"],
    "GGTGTACGGATGTCTAACTTCTT": ["Candida glabrata"],
    "TGTGGG": ["Saccharomyces cerevisiae"],
    "TGTGTGG": ["Saccharomyces cerevisiae variant"],
    "TTAGTCAGGG": ["Yarrowia lipolytica"],
    "GGGTTA": ["Various yeasts"],
    "GGGTAA": ["Some Candida species"],
    "TTTAGGG": ["Plant-type, some fungi"],
    "AACCCT": ["Many fungi (reverse of TTAGGG)"],
}


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class TelomereMotif:
    """Telomere motif data class"""
    sequence: str
    reverse_complement: str
    count: int
    score: float
    source: str
    priority: int = 2
    algorithm: str = "Genome"
    supporting_evidence: Dict = field(default_factory=dict)


@dataclass
class ChromosomeStats:
    """Chromosome statistics data class"""
    name: str
    length: int
    has_5prime_telomere: bool = False
    has_3prime_telomere: bool = False
    telomere_motif_5prime: str = ""
    telomere_motif_3prime: str = ""
    telomere_count_5prime: int = 0
    telomere_count_3prime: int = 0


# ============================================================================
# Utility Functions
# ============================================================================

def reverse_complement(seq: str) -> str:
    """Return the reverse complement of a DNA sequence"""
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G',
                  'a': 't', 't': 'a', 'g': 'c', 'c': 'g',
                  'N': 'N', 'n': 'n'}
    return ''.join(complement.get(base, 'N') for base in reversed(seq))


def normalize_motif(motif: str) -> str:
    """Normalize motif to canonical form (minimum lexicographic rotation)"""
    motif = motif.upper()
    rotations = [motif[i:] + motif[:i] for i in range(len(motif))]
    rc = reverse_complement(motif)
    rc_rotations = [rc[i:] + rc[:i] for i in range(len(rc))]
    return min(rotations + rc_rotations)


def open_file(filepath: str, mode: str = 'r'):
    """Open file with automatic gzip handling"""
    if filepath.endswith('.gz'):
        return gzip.open(filepath, mode + 't', encoding='utf-8')
    return open(filepath, mode, encoding='utf-8')


def is_low_complexity(unit: str) -> bool:
    """Check if sequence is low complexity"""
    if len(unit) < 2:
        return True

    base_counts = Counter(unit.upper())
    max_count = max(base_counts.values())

    # Single base proportion too high
    if max_count / len(unit) > 0.8:
        return True

    # Only one type of base
    if len(base_counts) == 1:
        return True

    # Simple dinucleotide repeat (e.g., ATATAT)
    if len(unit) >= 4:
        dinuc = unit[:2]
        if dinuc * (len(unit) // 2) == unit[:len(unit) // 2 * 2]:
            return True

    return False


# ============================================================================
# File Parsers
# ============================================================================

def parse_fasta(filepath: str) -> Dict[str, str]:
    """Parse FASTA file"""
    logger.info(f"Parsing FASTA file: {filepath}")
    sequences = {}
    current_header = None
    current_seq = []

    with open_file(filepath) as f:
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if current_header:
                    sequences[current_header] = ''.join(current_seq)
                current_header = line[1:].split()[0]
                current_seq = []
            elif line:
                current_seq.append(line.upper())
        if current_header:
            sequences[current_header] = ''.join(current_seq)

    logger.info(f"  Loaded {len(sequences)} sequences")
    return sequences


# ============================================================================
# Genome Motif Identifier
# ============================================================================

class GenomeMotifIdentifier:
    """
    Genome algorithm telomere motif identifier

    Core algorithm identical to tidk explore:
    1. Extract 5' and 3' terminal sequences from each chromosome
    2. For each possible repeat unit length k
    3. Iterate through each position in the sequence, detecting consecutive repeats
    4. Only keep motifs with consecutive repeats >= min_repeat_count
    5. Count total frequency of each motif across all chromosome termini
    """

    def __init__(self,
                 min_period: int = 5,
                 max_period: int = 12,
                 min_repeat_count: int = 10,
                 end_region_size: int = 10000):
        """
        Parameters:
            min_period: Minimum repeat unit length (corresponds to tidk -m)
            max_period: Maximum repeat unit length (corresponds to tidk -x)
            min_repeat_count: Minimum consecutive repeat count (corresponds to tidk -t)
            end_region_size: Chromosome terminal scanning region size
        """
        self.min_period = min_period
        self.max_period = max_period
        self.min_repeat_count = min_repeat_count
        self.end_region_size = end_region_size

    def identify(self, chromosomes: Dict[str, str]) -> Tuple[List[TelomereMotif], List[ChromosomeStats]]:
        """
        Identify telomere motifs

        Parameters:
            chromosomes: Chromosome sequence dictionary {chrom_name: sequence}

        Returns:
            (motif list, chromosome statistics list)
        """
        logger.info("Step 1: Genome Algorithm - Telomere Motif Identification")
        logger.info(f"  Parameters: repeat unit length={self.min_period}-{self.max_period}bp, "
                    f"min repeats={self.min_repeat_count}, "
                    f"terminal region={self.end_region_size}bp")
        logger.info("=" * 60)

        # Scan tandem repeats from genome termini
        motif_stats, chrom_stats = self._explore_genome_termini(chromosomes)

        if not motif_stats:
            logger.warning("  Failed to discover telomere motifs from genome, returning default value")
            return [self._get_default_motif()], chrom_stats

        # Build result list
        result_motifs = self._build_motif_list(motif_stats)

        # Check against known database
        result_motifs = self._check_known_database(result_motifs)

        # Output results
        logger.info("=" * 60)
        logger.info(f"  ✔ Identified {len(result_motifs)} candidate motifs:")
        for i, m in enumerate(result_motifs[:10], 1):
            known_info = ""
            if 'known_species' in m.supporting_evidence:
                known_info = f" [Known: {m.supporting_evidence['known_species'][0]}]"
            logger.info(f"    {i}. {m.sequence} (RC: {m.reverse_complement}) "
                        f"- frequency={m.count}, score={m.score:.2f}{known_info}")

        return result_motifs, chrom_stats

    def _explore_genome_termini(self, chromosomes: Dict[str, str]) -> Tuple[Dict[str, Dict], List[ChromosomeStats]]:
        """
        Scan tandem repeat sequences from genome termini (tidk explore core logic)
        """
        # Store statistics for each motif
        motif_stats = defaultdict(lambda: {
            'terminus_total_count': 0,      # Total repeat count across all termini
            'terminus_chrom_count': 0,      # Number of chromosome termini where motif appears
            'terminus_at_edge': 0,          # Occurrences within the outermost 100bp
            'max_tandem_length': 0,         # Maximum consecutive tandem length
            'chromosomes_5prime': [],       # Chromosomes where motif appears at 5' end
            'chromosomes_3prime': []        # Chromosomes where motif appears at 3' end
        })

        chrom_stats_list = []

        for chrom_name, seq in chromosomes.items():
            seq_upper = seq.upper()
            chrom_len = len(seq_upper)

            chrom_stat = ChromosomeStats(name=chrom_name, length=chrom_len)

            # Scan 5' end
            end_5 = seq_upper[:min(self.end_region_size, chrom_len // 2)]
            motifs_5 = self._scan_tandem_repeats(end_5, motif_stats,
                                                  is_5prime=True, chrom_name=chrom_name)
            if motifs_5:
                best_5 = max(motifs_5.items(), key=lambda x: x[1])
                chrom_stat.has_5prime_telomere = True
                chrom_stat.telomere_motif_5prime = best_5[0]
                chrom_stat.telomere_count_5prime = best_5[1]

            # Scan 3' end
            end_3 = seq_upper[-min(self.end_region_size, chrom_len // 2):]
            motifs_3 = self._scan_tandem_repeats(end_3, motif_stats,
                                                  is_5prime=False, chrom_name=chrom_name)
            if motifs_3:
                best_3 = max(motifs_3.items(), key=lambda x: x[1])
                chrom_stat.has_3prime_telomere = True
                chrom_stat.telomere_motif_3prime = best_3[0]
                chrom_stat.telomere_count_3prime = best_3[1]

            chrom_stats_list.append(chrom_stat)

            logger.debug(f"  {chrom_name}: 5'={chrom_stat.telomere_motif_5prime or 'N/A'}, "
                        f"3'={chrom_stat.telomere_motif_3prime or 'N/A'}")

        # Filter: only keep motifs with total frequency >= min_repeat_count
        result = {}
        for motif, stats in motif_stats.items():
            if stats['terminus_total_count'] >= self.min_repeat_count:
                result[motif] = stats
                logger.debug(f"    Found: {motif}, total frequency={stats['terminus_total_count']}, "
                            f"chromosome count={stats['terminus_chrom_count']}")

        return result, chrom_stats_list

    def _scan_tandem_repeats(self, sequence: str, motif_stats: Dict,
                             is_5prime: bool, chrom_name: str) -> Dict[str, int]:
        """
        Scan tandem repeat sequences in the sequence (tidk explore core logic)

        Algorithm:
        1. For each possible repeat unit length k (min_period ~ max_period)
        2. Iterate through each position i in the sequence
        3. Extract k-mer as candidate repeat unit
        4. Calculate how many times this unit consecutively repeats starting from position i
        5. If repeat count >= min_repeat_count, record this motif
        """
        seq_len = len(sequence)
        found_in_this_region = {}  # {motif: count}

        # For each possible repeat unit length
        for k in range(self.min_period, self.max_period + 1):
            i = 0
            while i <= seq_len - k * self.min_repeat_count:
                unit = sequence[i:i + k]

                # Skip sequences containing N or low complexity
                if 'N' in unit or is_low_complexity(unit):
                    i += 1
                    continue

                # Calculate how many times unit consecutively repeats starting from position i
                repeat_count = 1
                j = i + k
                while j + k <= seq_len and sequence[j:j + k] == unit:
                    repeat_count += 1
                    j += k

                # If repeat count is sufficient (simulating tidk's -t parameter)
                if repeat_count >= self.min_repeat_count:
                    # Normalize motif (handle rotation and reverse complement)
                    norm_unit = normalize_motif(unit)

                    # Update statistics
                    motif_stats[norm_unit]['terminus_total_count'] += repeat_count

                    # Record maximum tandem length
                    tandem_length = repeat_count * k
                    if tandem_length > motif_stats[norm_unit]['max_tandem_length']:
                        motif_stats[norm_unit]['max_tandem_length'] = tandem_length

                    # Record which chromosome terminus this motif appears at
                    if is_5prime:
                        if chrom_name not in motif_stats[norm_unit]['chromosomes_5prime']:
                            motif_stats[norm_unit]['chromosomes_5prime'].append(chrom_name)
                    else:
                        if chrom_name not in motif_stats[norm_unit]['chromosomes_3prime']:
                            motif_stats[norm_unit]['chromosomes_3prime'].append(chrom_name)

                    # Check if within outermost 100bp
                    if is_5prime and i < 100:
                        motif_stats[norm_unit]['terminus_at_edge'] += 1
                    elif not is_5prime and i > seq_len - 100 - k * repeat_count:
                        motif_stats[norm_unit]['terminus_at_edge'] += 1

                    # Record finding in this region
                    if norm_unit not in found_in_this_region:
                        found_in_this_region[norm_unit] = 0
                    found_in_this_region[norm_unit] += repeat_count

                    # Skip the scanned tandem region to avoid double counting
                    i = j
                else:
                    i += 1

        # Update chromosome terminus count
        for motif in found_in_this_region:
            motif_stats[motif]['terminus_chrom_count'] += 1

        return found_in_this_region

    def _build_motif_list(self, motif_stats: Dict[str, Dict]) -> List[TelomereMotif]:
        """Build motif result list"""
        # Sort by frequency
        sorted_motifs = sorted(
            motif_stats.items(),
            key=lambda x: x[1]['terminus_total_count'],
            reverse=True
        )

        if not sorted_motifs:
            return []

        # Calculate maximum frequency for normalization
        max_count = sorted_motifs[0][1]['terminus_total_count']

        result = []
        for motif, stats in sorted_motifs[:20]:  # Return at most 20
            count = stats['terminus_total_count']
            if count == 0:
                continue

            # Calculate composite score
            # Consider: total frequency, chromosome coverage, edge occurrence count
            freq_score = (count / max_count) * 50
            chrom_score = min(stats['terminus_chrom_count'] / 5, 1.0) * 30
            edge_score = min(stats['terminus_at_edge'] / 3, 1.0) * 20
            total_score = freq_score + chrom_score + edge_score

            result.append(TelomereMotif(
                sequence=motif,
                reverse_complement=reverse_complement(motif),
                count=count,
                score=total_score,
                source='genome_explore',
                priority=2,
                algorithm='Genome',
                supporting_evidence={
                    'terminus_chrom_count': stats['terminus_chrom_count'],
                    'terminus_at_edge': stats['terminus_at_edge'],
                    'max_tandem_length': stats['max_tandem_length'],
                    'chromosomes_5prime': stats['chromosomes_5prime'],
                    'chromosomes_3prime': stats['chromosomes_3prime']
                }
            ))

        return result

    def _check_known_database(self, motifs: List[TelomereMotif]) -> List[TelomereMotif]:
        """Check if motif is in the known database"""
        for motif in motifs:
            norm_seq = normalize_motif(motif.sequence)

            for known_motif, species in KNOWN_FUNGAL_TELOMERES.items():
                if normalize_motif(known_motif) == norm_seq:
                    motif.supporting_evidence['known_species'] = species
                    motif.supporting_evidence['known_motif'] = known_motif
                    # Bonus for known motif
                    motif.score += 10
                    break

        # Re-sort
        motifs.sort(key=lambda x: x.score, reverse=True)
        return motifs

    def _get_default_motif(self) -> TelomereMotif:
        """Return default motif"""
        return TelomereMotif(
            sequence="TTAGGG",
            reverse_complement="CCCTAA",
            count=0,
            score=0.5,
            source='default',
            priority=4,
            algorithm='Genome',
            supporting_evidence={'default': True}
        )


# ============================================================================
# Output Functions
# ============================================================================

def save_results(motifs: List[TelomereMotif], chrom_stats: List[ChromosomeStats],
                 output_dir: Path, chromosomes: Dict[str, str]):
    """Save analysis results"""
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save motif list (TSV)
    tsv_file = output_dir / "identified_motifs.tsv"
    with open(tsv_file, 'w') as f:
        f.write("Rank\tMotif\tReverse_Complement\tScore\tTotal_Count\tChrom_Count\tEdge_Count\tKnown_Species\tAlgorithm\n")
        for i, m in enumerate(motifs, 1):
            known = m.supporting_evidence.get('known_species', [''])[0] if 'known_species' in m.supporting_evidence else ''
            chrom_count = m.supporting_evidence.get('terminus_chrom_count', 0)
            edge_count = m.supporting_evidence.get('terminus_at_edge', 0)
            f.write(f"{i}\t{m.sequence}\t{m.reverse_complement}\t"
                    f"{m.score:.4f}\t{m.count}\t{chrom_count}\t{edge_count}\t{known}\t{m.algorithm}\n")

    # Save chromosome statistics (TSV)
    chrom_tsv = output_dir / "chromosome_telomere_stats.tsv"
    with open(chrom_tsv, 'w') as f:
        f.write("Chromosome\tLength\tHas_5prime\tMotif_5prime\tCount_5prime\tHas_3prime\tMotif_3prime\tCount_3prime\n")
        for cs in chrom_stats:
            f.write(f"{cs.name}\t{cs.length}\t"
                    f"{cs.has_5prime_telomere}\t{cs.telomere_motif_5prime}\t{cs.telomere_count_5prime}\t"
                    f"{cs.has_3prime_telomere}\t{cs.telomere_motif_3prime}\t{cs.telomere_count_3prime}\n")

    # Save JSON format results
    json_file = output_dir / "identified_motifs.json"
    json_data = {
        'version': VERSION,
        'algorithm': ALGORITHM,
        'timestamp': datetime.now().isoformat(),
        'genome_stats': {
            'total_chromosomes': len(chromosomes),
            'total_length': sum(len(s) for s in chromosomes.values()),
            'chromosomes_with_5prime_telomere': sum(1 for cs in chrom_stats if cs.has_5prime_telomere),
            'chromosomes_with_3prime_telomere': sum(1 for cs in chrom_stats if cs.has_3prime_telomere),
        },
        'motifs': [
            {
                'rank': i,
                'sequence': m.sequence,
                'reverse_complement': m.reverse_complement,
                'score': m.score,
                'count': m.count,
                'source': m.source,
                'algorithm': m.algorithm,
                'supporting_evidence': m.supporting_evidence
            }
            for i, m in enumerate(motifs, 1)
        ],
        'chromosome_stats': [
            {
                'name': cs.name,
                'length': cs.length,
                'has_5prime_telomere': cs.has_5prime_telomere,
                'telomere_motif_5prime': cs.telomere_motif_5prime,
                'telomere_count_5prime': cs.telomere_count_5prime,
                'has_3prime_telomere': cs.has_3prime_telomere,
                'telomere_motif_3prime': cs.telomere_motif_3prime,
                'telomere_count_3prime': cs.telomere_count_3prime
            }
            for cs in chrom_stats
        ]
    }
    with open(json_file, 'w') as f:
        json.dump(json_data, f, indent=2)

    logger.info(f"  Results saved to: {output_dir}")
    logger.info(f"    - {tsv_file.name}")
    logger.info(f"    - {chrom_tsv.name}")
    logger.info(f"    - {json_file.name}")


def print_summary(motifs: List[TelomereMotif], chrom_stats: List[ChromosomeStats],
                  chromosomes: Dict[str, str]):
    """Print result summary"""
    best = motifs[0] if motifs else None

    total_chroms = len(chromosomes)
    chroms_with_5 = sum(1 for cs in chrom_stats if cs.has_5prime_telomere)
    chroms_with_3 = sum(1 for cs in chrom_stats if cs.has_3prime_telomere)
    chroms_both = sum(1 for cs in chrom_stats if cs.has_5prime_telomere and cs.has_3prime_telomere)

    known_info = ""
    if best and 'known_species' in best.supporting_evidence:
        known_info = f"[{best.supporting_evidence['known_species'][0]}]"

    print(f"""
╔═══════════════════════════════════════════════════════════════════╗
║     TelomereMotifIdentifier_Genome v{VERSION} Analysis Complete                ║
╠═══════════════════════════════════════════════════════════════════╣
║  Algorithm:              Genome (tidk explore style)                      ║
║  Chromosome Count:        {total_chroms:>6}                                      ║
║  Motifs Discovered:       {len(motifs):>6}                                      ║
╠═══════════════════════════════════════════════════════════════════╣
║  5' End with Telomere:        {chroms_with_5:>6} / {total_chroms:<6}                             ║
║  3' End with Telomere:        {chroms_with_3:>6} / {total_chroms:<6}                             ║
║  Both Ends:          {chroms_both:>6} / {total_chroms:<6}                             ║
╠═══════════════════════════════════════════════════════════════════╣
║  Best Motif:         {best.sequence if best else 'N/A':<12} {known_info:<20}     ║
║  Reverse Complement:          {best.reverse_complement if best else 'N/A':<12}                              ║
║  Total Frequency:            {best.count if best else 0:>8}                                ║
║  Confidence Score:        {best.score if best else 0:>8.2f}                                ║
╚═══════════════════════════════════════════════════════════════════╝
""")


# ============================================================================
# Main
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description=f"TelomereMotifIdentifier_Genome v{VERSION} - Telomere Motif Identification Tool (Genome Algorithm)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  python TelomereMotifIdentifier_Genome.py -g genome.fasta -o output/

  # Specify parameters (corresponding to tidk explore parameters)
  python TelomereMotifIdentifier_Genome.py -g genome.fasta -o output/ \\
      --min-period 5 --max-period 12 --min-repeat 8 --end-region 20000

Algorithm Description:
  Genome algorithm core logic is identical to tidk explore:
  1. Extract 5' and 3' terminal sequences from each chromosome
  2. Scan and detect tandem repeat sequences
  3. Count frequency of each motif across all chromosome termini
  4. Return candidate motif list sorted by frequency

Parameter Correspondence (with tidk explore):
  --min-period    corresponds to tidk -m
  --max-period    corresponds to tidk -x  
  --min-repeat    corresponds to tidk -t
  --end-region    scanning region size
        """
    )

    required = parser.add_argument_group('Required Arguments')
    required.add_argument('-g', '--genome', required=True,
                          help='Genome file (FASTA format, supports .gz)')
    required.add_argument('-o', '--output', required=True,
                          help='Output directory')

    optional = parser.add_argument_group('Optional Arguments')
    optional.add_argument('--min-period', type=int, default=5,
                          help='Minimum repeat unit length (default: 5, corresponds to tidk -m)')
    optional.add_argument('--max-period', type=int, default=12,
                          help='Maximum repeat unit length (default: 12, corresponds to tidk -x)')
    optional.add_argument('--min-repeat', type=int, default=10,
                          help='Minimum consecutive repeat count (default: 10, corresponds to tidk -t)')
    optional.add_argument('--end-region', type=int, default=10000,
                          help='Chromosome terminal scanning region size (default: 10000)')
    optional.add_argument('-v', '--verbose', action='store_true',
                          help='Show detailed debug information')

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Check input file
    if not os.path.exists(args.genome):
        logger.error(f"Genome file does not exist: {args.genome}")
        sys.exit(1)

    # Parameter validation
    if args.min_period > args.max_period:
        logger.error("--min-period cannot be greater than --max-period")
        sys.exit(1)

    output_dir = Path(args.output)

    logger.info(f"""
╔═══════════════════════════════════════════════════════════════════╗
║     TelomereMotifIdentifier_Genome v{VERSION}                        ║
║     Telomere Motif Identification Tool - Genome Algorithm (tidk explore style)               ║
╚═══════════════════════════════════════════════════════════════════╝
""")
    logger.info(f"Genome file: {args.genome}")
    logger.info(f"Output directory: {args.output}")
    logger.info(f"Parameters: period={args.min_period}-{args.max_period}, "
                f"min_repeat={args.min_repeat}, end_region={args.end_region}")

    # Load genome
    chromosomes = parse_fasta(args.genome)
    total_len = sum(len(s) for s in chromosomes.values())
    logger.info(f"  {len(chromosomes)} chromosomes, total length {total_len:,} bp")

    # Motif identification
    identifier = GenomeMotifIdentifier(
        min_period=args.min_period,
        max_period=args.max_period,
        min_repeat_count=args.min_repeat,
        end_region_size=args.end_region
    )
    motifs, chrom_stats = identifier.identify(chromosomes)

    # Save results
    logger.info("\nSaving results...")
    save_results(motifs, chrom_stats, output_dir, chromosomes)

    # Print summary
    print_summary(motifs, chrom_stats, chromosomes)


if __name__ == "__main__":
    main()