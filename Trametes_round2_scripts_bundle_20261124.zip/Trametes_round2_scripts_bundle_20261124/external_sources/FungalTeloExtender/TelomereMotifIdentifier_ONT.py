#!/usr/bin/env python3
"""
TelomereMotifIdentifier_ONT - Telomere Motif Identification Tool (ONT Reads Algorithm)
==================================================
Author: FungalTeloExtender Team
Version: 1.0.0
License: MIT
"""

import os
import sys
import argparse
import logging
import gzip
import subprocess
import shutil
import re
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Set, Generator
from pathlib import Path
import json
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Constants
# ============================================================================

VERSION = "1.0.2"

# TRF default parameters
TRF_DEFAULTS = {
    'match': 2,
    'mismatch': 7,
    'delta': 7,
    'pm': 80,
    'pi': 10,
    'minscore': 50,
    'maxperiod': 10,
}

# Known fungal telomere motif database
KNOWN_FUNGAL_TELOMERES = {
    "TTAGGG": ["Neurospora crassa", "Magnaporthe oryzae", "Most filamentous fungi"],
    "TTAGGC": ["Aspergillus fumigatus", "Aspergillus niger", "Aspergillus nidulans"],
    "TCTGGGTG": ["Candida albicans"],
    "GGTGTACGGATGTCTAACTTCTT": ["Candida glabrata"],
    "TGTGGG": ["Saccharomyces cerevisiae"],
    "TGTGTGG": ["Saccharomyces cerevisiae variant"],
    "TTAGTCAGGG": ["Yarrowia lipolytica"],
    "GGGTTA": ["Various yeasts"],
    "GGGTAA": ["Some Candida species"],
    "TTTAGGG": ["Plant-type, some fungi"],
    "AACCCT": ["Many fungi (reverse of TTAGGG)"],
}


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class TRFResult:
    """Tandem repeat result detected by TRF"""
    read_id: str
    start: int
    end: int
    period: int
    copy_number: float
    consensus_size: int
    percent_matches: float
    percent_indels: float
    score: int
    repeat_unit: str
    repeat_sequence: str


@dataclass
class TandemRepeatRead:
    """Read containing tandem repeats"""
    read_id: str
    sequence: str
    quality: Optional[str]
    trf_results: List[TRFResult]
    best_repeat_unit: str
    best_copy_number: float
    repeat_position: str

    @property
    def read_length(self) -> int:
        return len(self.sequence)


@dataclass
class TelomereMotif:
    """Telomere motif data class"""
    sequence: str
    reverse_complement: str
    count: int
    score: float
    source: str
    priority: int = 4  # Priority (1=highest)
    algorithm: str = ""  # Algorithm used
    supporting_evidence: Dict = field(default_factory=dict)


# ============================================================================
# Utility Functions
# ============================================================================

def reverse_complement(seq: str) -> str:
    """Return the reverse complement of a DNA sequence"""
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G',
                  'a': 't', 't': 'a', 'g': 'c', 'c': 'g',
                  'N': 'N', 'n': 'n'}
    return ''.join(complement.get(base, 'N') for base in reversed(seq))


def normalize_motif(motif: str) -> str:
    """Normalize motif to canonical form"""
    motif = motif.upper()
    rotations = [motif[i:] + motif[:i] for i in range(len(motif))]
    rc = reverse_complement(motif)
    rc_rotations = [rc[i:] + rc[:i] for i in range(len(rc))]
    return min(rotations + rc_rotations)


def hamming_distance(s1: str, s2: str) -> int:
    """Calculate Hamming distance between two equal-length strings"""
    return sum(c1.upper() != c2.upper() for c1, c2 in zip(s1, s2))


def open_file(filepath: str, mode: str = 'r'):
    """Open file with automatic gzip handling"""
    if filepath.endswith('.gz'):
        return gzip.open(filepath, mode + 't', encoding='utf-8')
    return open(filepath, mode, encoding='utf-8')


def run_command(cmd: List[str], check: bool = True,
                capture_output: bool = True,
                timeout: int = None,
                cwd: str = None) -> subprocess.CompletedProcess:
    """Run shell command"""
    logger.debug(f"Running: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, check=check, capture_output=capture_output,
                                text=True, timeout=timeout, cwd=cwd)
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {' '.join(cmd)}")
        logger.error(f"Error: {e.stderr}")
        raise
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out: {' '.join(cmd)}")
        raise


def check_dependencies() -> bool:
    """Check TRF dependency software"""
    available = shutil.which('trf') is not None
    if available:
        logger.info("TRF: Available ✔")
    else:
        logger.warning("TRF: Not available, will skip TRF screening step")
    return available


def count_motif_occurrences(sequence: str, motif: str, max_mismatch: int = 1) -> Tuple[int, int, int]:
    """
    Count motif occurrences and positions in sequence
    Returns: (count, start_pos, end_pos)
    """
    seq = sequence.upper()
    motif_upper = motif.upper()
    rc_motif = reverse_complement(motif_upper)
    motif_len = len(motif)

    best_count = 0
    best_start = 0
    best_end = 0

    for search_motif in [motif_upper, rc_motif]:
        for start in range(min(len(seq) - motif_len * 3, 2000)):
            count = 0
            pos = start

            while pos + motif_len <= len(seq):
                window = seq[pos:pos + motif_len]
                if hamming_distance(search_motif, window) <= max_mismatch:
                    count += 1
                    pos += motif_len
                else:
                    if count >= 2:
                        next_pos = pos + motif_len
                        if next_pos + motif_len <= len(seq):
                            next_window = seq[next_pos:next_pos + motif_len]
                            if hamming_distance(search_motif, next_window) <= max_mismatch:
                                pos = next_pos
                                continue
                    break

            if count > best_count:
                best_count = count
                best_start = start
                best_end = pos

    return best_count, best_start, best_end


def count_motif_simple(sequence: str, motif: str) -> int:
    """Simple count of motif occurrences"""
    seq = sequence.upper()
    motif_upper = motif.upper()
    rc_motif = reverse_complement(motif_upper)
    return seq.count(motif_upper) + seq.count(rc_motif)


def is_low_complexity(kmer: str) -> bool:
    """Check if kmer is a low complexity sequence"""
    base_counts = Counter(kmer.upper())
    max_freq = max(base_counts.values()) / len(kmer)

    if max_freq > 0.6:
        return True

    for period in [2, 3, 4, 5, 6]:
        if len(kmer) >= period * 2:
            unit = kmer[:period]
            repeated = unit * (len(kmer) // period + 1)
            if repeated[:len(kmer)] == kmer:
                return True

    return False


# ============================================================================
# File Parsers
# ============================================================================

def parse_fastq_streaming(filepath: str) -> Generator[Tuple[str, str, str], None, None]:
    """Stream parse FASTQ file"""
    with open_file(filepath) as f:
        while True:
            header = f.readline().strip()
            if not header:
                break
            if not header.startswith('@'):
                continue
            seq = f.readline().strip().upper()
            f.readline()
            qual = f.readline().strip()
            read_id = header[1:].split()[0]
            yield read_id, seq, qual


def write_fasta(sequences: Dict[str, str], filepath: str, line_width: int = 80):
    """Write FASTA file"""
    with open(filepath, 'w') as f:
        for name, seq in sequences.items():
            f.write(f">{name}\n")
            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")


# ============================================================================
# TRF Screener (Step 1)
# ============================================================================

class TRFScreener:
    """Screen reads containing tandem repeats using TRF"""

    def __init__(self,
                 min_period: int = 6,
                 max_period: int = 12,
                 min_copy_number: int = 10,
                 threads: int = 4,
                 work_dir: Path = None):
        self.min_period = min_period
        self.max_period = max_period
        self.min_copy_number = min_copy_number
        self.threads = threads
        self.work_dir = work_dir or Path(tempfile.mkdtemp())
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.has_trf = shutil.which('trf') is not None

    def screen_reads(self, reads_file: str,
                     batch_size: int = 1000) -> List[TandemRepeatRead]:
        """Screen reads containing tandem repeats"""
        if not self.has_trf:
            logger.info("TRF not available, skipping tandem repeat screening")
            return []

        logger.info(f"Screening tandem repeat reads using TRF")
        logger.info(f"  Parameters: repeat unit {self.min_period}-{self.max_period}bp, "
                    f"minimum repeats {self.min_copy_number} times")

        tandem_reads = []
        batch_reads = []
        batch_num = 0
        total_processed = 0

        for read_id, seq, qual in parse_fastq_streaming(reads_file):
            batch_reads.append((read_id, seq, qual))
            total_processed += 1

            if len(batch_reads) >= batch_size:
                batch_num += 1
                results = self._process_batch(batch_reads, batch_num)
                tandem_reads.extend(results)
                batch_reads = []

                if batch_num % 10 == 0:
                    logger.info(f"  Processed {total_processed:,} reads, "
                                f"found {len(tandem_reads):,} tandem repeat reads")

        if batch_reads:
            batch_num += 1
            results = self._process_batch(batch_reads, batch_num)
            tandem_reads.extend(results)

        logger.info(f"  ✔ Complete: {total_processed:,} total reads, "
                    f"screened {len(tandem_reads):,} reads with tandem repeats")

        return tandem_reads

    def _process_batch(self, reads: List[Tuple[str, str, str]],
                       batch_num: int) -> List[TandemRepeatRead]:
        """Process a batch of reads"""
        batch_fasta = self.work_dir / f"batch_{batch_num}.fasta"

        read_dict = {}
        with open(batch_fasta, 'w') as f:
            for read_id, seq, qual in reads:
                f.write(f">{read_id}\n{seq}\n")
                read_dict[read_id] = (seq, qual)

        trf_results = self._run_trf(str(batch_fasta), batch_num)

        tandem_reads = []
        for read_id, results in trf_results.items():
            valid_results = [
                r for r in results
                if self.min_period <= r.period <= self.max_period
                   and r.copy_number >= self.min_copy_number
            ]

            if valid_results:
                seq, qual = read_dict[read_id]
                best = max(valid_results, key=lambda x: x.copy_number)
                position = self._determine_position(best, len(seq))

                tandem_reads.append(TandemRepeatRead(
                    read_id=read_id,
                    sequence=seq,
                    quality=qual,
                    trf_results=valid_results,
                    best_repeat_unit=best.repeat_unit,
                    best_copy_number=best.copy_number,
                    repeat_position=position
                ))

        self._cleanup_batch_files(batch_fasta)
        return tandem_reads

    def _run_trf(self, fasta_file: str, batch_num: int) -> Dict[str, List[TRFResult]]:
        """Run TRF and parse results"""
        trf_cmd = [
            'trf', fasta_file,
            str(TRF_DEFAULTS['match']),
            str(TRF_DEFAULTS['mismatch']),
            str(TRF_DEFAULTS['delta']),
            str(TRF_DEFAULTS['pm']),
            str(TRF_DEFAULTS['pi']),
            str(TRF_DEFAULTS['minscore']),
            str(self.max_period),
            '-d', '-h'
        ]

        try:
            subprocess.run(trf_cmd, capture_output=True, text=True,
                           timeout=300, cwd=str(self.work_dir))
        except subprocess.TimeoutExpired:
            logger.warning(f"TRF run timed out (batch {batch_num})")
            return {}
        except Exception as e:
            logger.warning(f"TRF run failed (batch {batch_num}): {e}")
            return {}

        dat_file = self._find_trf_output(fasta_file)
        if dat_file:
            return self._parse_trf_dat(dat_file)
        return {}

    def _find_trf_output(self, fasta_file: str) -> Optional[Path]:
        """Find TRF output dat file"""
        fasta_basename = Path(fasta_file).name
        expected_dat_name = (f"{fasta_basename}.{TRF_DEFAULTS['match']}."
                             f"{TRF_DEFAULTS['mismatch']}.{TRF_DEFAULTS['delta']}."
                             f"{TRF_DEFAULTS['pm']}.{TRF_DEFAULTS['pi']}."
                             f"{TRF_DEFAULTS['minscore']}.{self.max_period}.dat")

        possible_locations = [
            self.work_dir / expected_dat_name,
            Path(fasta_file).parent / expected_dat_name,
            Path.cwd() / expected_dat_name,
        ]

        for loc in possible_locations:
            if loc.exists():
                return loc

        search_dirs = [self.work_dir, Path(fasta_file).parent, Path.cwd()]
        for search_dir in search_dirs:
            dat_files = list(search_dir.glob(f"{fasta_basename}.*.dat"))
            if dat_files:
                return max(dat_files, key=lambda x: x.stat().st_mtime)

        all_dat_files = list(self.work_dir.glob("*.dat"))
        if all_dat_files:
            batch_dat_files = [f for f in all_dat_files if "batch" in f.name]
            if batch_dat_files:
                return max(batch_dat_files, key=lambda x: x.stat().st_mtime)

        return None

    def _parse_trf_dat(self, dat_file: Path) -> Dict[str, List[TRFResult]]:
        """Parse TRF dat output file"""
        results = defaultdict(list)
        current_read = None

        try:
            with open(dat_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    if line.startswith('Sequence:'):
                        parts = line.split(':', 1)
                        if len(parts) > 1:
                            current_read = parts[1].strip().split()[0]

                    elif line.startswith('Parameters:') or line.startswith('@'):
                        continue

                    elif current_read and line[0].isdigit():
                        parts = line.split()
                        if len(parts) >= 14:
                            try:
                                result = TRFResult(
                                    read_id=current_read,
                                    start=int(parts[0]),
                                    end=int(parts[1]),
                                    period=int(parts[2]),
                                    copy_number=float(parts[3]),
                                    consensus_size=int(parts[4]),
                                    percent_matches=float(parts[5]),
                                    percent_indels=float(parts[6]),
                                    score=int(float(parts[7])),
                                    repeat_unit=parts[13],
                                    repeat_sequence=parts[14] if len(parts) > 14 else ""
                                )
                                results[current_read].append(result)
                            except (ValueError, IndexError):
                                continue

        except Exception as e:
            logger.warning(f"Failed to parse TRF results: {e}")

        return dict(results)

    def _cleanup_batch_files(self, batch_fasta: Path):
        """Clean up batch temporary files"""
        try:
            if batch_fasta.exists():
                batch_fasta.unlink()

            fasta_basename = batch_fasta.name
            for pattern in [f"{fasta_basename}.*", f"{batch_fasta.stem}.*"]:
                for f in self.work_dir.glob(pattern):
                    try:
                        f.unlink()
                    except Exception:
                        pass
        except Exception:
            pass

    def _determine_position(self, trf_result: TRFResult, read_length: int) -> str:
        """Determine repeat sequence position in read"""
        start = trf_result.start
        end = trf_result.end
        dist_5prime = start
        dist_3prime = read_length - end
        threshold = min(500, read_length * 0.1)

        if dist_5prime <= threshold:
            return '5prime'
        elif dist_3prime <= threshold:
            return '3prime'
        else:
            return 'internal'


# ============================================================================
# ONT Motif Identifier (Core Algorithm)
# ============================================================================

class MotifIdentifier:
    """
    Telomere motif identifier - ONT reads algorithm
    Uses TRF discovery from reads + read terminus frequency validation
    """

    def __init__(self,
                 min_period: int = 6,
                 max_period: int = 12,
                 min_repeat_count: int = 10,
                 terminus_check_size: int = 300):
        """
        Parameters:
            min_period: Minimum repeat unit length
            max_period: Maximum repeat unit length
            min_repeat_count: Minimum consecutive repeat count (for TRF screening)
            terminus_check_size: Read terminus validation region size
        """
        self.min_period = min_period
        self.max_period = max_period
        self.min_repeat_count = min_repeat_count
        self.terminus_check_size = terminus_check_size

    def identify_from_tandem_reads(self, tandem_reads: List[TandemRepeatRead]) -> List[TelomereMotif]:
        """
        Identify telomere motifs from tandem reads
        Using ONT algorithm: TRF discovery + read terminus frequency validation

        v1.0.2 modification: Only sort and score by terminus_count,
        not using TRF count and high copy number

        Optimization strategies (ensuring accuracy):
        1. Limit candidate motif count - only validate top 50 by TRF occurrence
        2. Iterate through all reads for validation
        3. Early stop strategy - finish early when sufficient validation reached
        4. Simplified counting - use faster string matching
        """
        logger.info("ONT algorithm: TRF discovery + read terminus validation")

        if not tandem_reads:
            logger.info("  No tandem reads, skipping ONT algorithm")
            return []

        logger.info(f"  Input: {len(tandem_reads)} tandem reads")

        # 1. Collect candidate motifs from TRF results
        trf_candidates = self._collect_from_trf(tandem_reads)
        logger.info(f"  TRF discovered {len(trf_candidates)} candidate motifs")

        if not trf_candidates:
            return []

        # 2. Validate frequency at read termini
        validated = self._validate_in_reads_terminus(tandem_reads, trf_candidates)
        logger.info(f"  {len(validated)} motifs retained after read terminus validation")

        ont_motifs = []
        for motif, evidence in validated.items():
            if evidence['terminus_count'] >= 2:  # At least 2 reads terminus validation
                ont_motifs.append(TelomereMotif(
                    sequence=motif,
                    reverse_complement=reverse_complement(motif),
                    count=evidence['total_count'],
                    score=evidence['score'],
                    source='ont_validated',
                    priority=2,
                    algorithm='ONT',
                    supporting_evidence=evidence
                ))

        # Sort by score
        ont_motifs.sort(key=lambda x: x.score, reverse=True)

        if ont_motifs:
            best = ont_motifs[0]
            logger.info(f"  ✔ Best ONT validated motif: {best.sequence} "
                        f"(terminus_count={best.supporting_evidence['terminus_count']}, "
                        f"score={best.score:.0f})")

        return ont_motifs

    def identify_from_raw_reads_with_tandem(self, reads_file: str) -> Tuple[List[TelomereMotif], int]:
        """
        Identify telomere motifs from raw reads file, also return tandem reads count
        Includes TRF screening step
        """
        logger.info("Starting ONT telomere motif identification pipeline")

        # Use TRF to screen tandem reads
        trf_screener = TRFScreener(
            min_period=self.min_period,
            max_period=self.max_period,
            min_copy_number=self.min_repeat_count
        )

        tandem_reads = trf_screener.screen_reads(reads_file)
        tandem_reads_count = len(tandem_reads)

        # Identify motifs from tandem reads
        motifs = self.identify_from_tandem_reads(tandem_reads)
        return motifs, tandem_reads_count

    def identify_from_raw_reads(self, reads_file: str) -> List[TelomereMotif]:
        """
        Identify telomere motifs from raw reads file (backward compatible)
        """
        motifs, _ = self.identify_from_raw_reads_with_tandem(reads_file)
        return motifs

    def _collect_from_trf(self, tandem_reads: List[TandemRepeatRead]) -> Dict[str, Dict]:
        """Collect candidate motifs from TRF results"""
        motif_counts = defaultdict(lambda: {
            'count': 0,
            'copy_numbers': [],
            'positions': [],
            'read_ids': []
        })

        for tr in tandem_reads:
            for trf in tr.trf_results:
                if self.min_period <= trf.period <= self.max_period:
                    norm_motif = normalize_motif(trf.repeat_unit)
                    motif_counts[norm_motif]['count'] += 1
                    motif_counts[norm_motif]['copy_numbers'].append(trf.copy_number)
                    motif_counts[norm_motif]['positions'].append(tr.repeat_position)
                    motif_counts[norm_motif]['read_ids'].append(tr.read_id)

        return dict(motif_counts)

    def _validate_in_reads_terminus(self, tandem_reads: List[TandemRepeatRead],
                                    trf_candidates: Dict[str, Dict],
                                    max_candidates: int = 50) -> Dict[str, Dict]:
        """
        Validate motif frequency at read termini

        v1.0.2 modification: Only sort and score by terminus_count,
        not using TRF count and high copy number

        Optimization strategies (ensuring accuracy):
        1. Only validate top max_candidates (default 50) by TRF occurrence
        2. Iterate through all tandem reads (no sampling)
        3. Use precise counting method
        4. [Modified] Only use terminus_count for scoring
        """
        validated = {}

        # Sort by TRF occurrence count, take only top max_candidates for validation
        sorted_candidates = sorted(
            trf_candidates.items(),
            key=lambda x: x[1]['count'],
            reverse=True
        )[:max_candidates]

        actual_candidates = len(sorted_candidates)
        total_reads = len(tandem_reads)
        logger.info(f"  Optimization: Selecting top {actual_candidates} from {len(trf_candidates)} candidates by TRF count for validation")
        logger.info(f"  Iterating through all {total_reads} tandem reads")

        for idx, (motif, trf_evidence) in enumerate(sorted_candidates):
            # Count this motif's occurrence at read termini
            terminus_count = 0

            # Iterate through all tandem reads
            for tr in tandem_reads:
                seq = tr.sequence

                # Use precise counting method
                count_5, _, _ = count_motif_occurrences(
                    seq[:self.terminus_check_size], motif, max_mismatch=1
                )
                count_3, _, _ = count_motif_occurrences(
                    seq[-self.terminus_check_size:], motif, max_mismatch=1
                )

                if count_5 >= 3 or count_3 >= 3:
                    terminus_count += 1

            # [Modified] Only use terminus_count as score, not TRF and high copy scoring
            total_score = float(terminus_count)

            # Only keep motifs that pass validation
            if terminus_count >= 2:  # At least 2 reads terminus validation
                validated[motif] = {
                    'total_count': trf_evidence['count'],
                    'terminus_count': terminus_count,
                    'score': total_score,
                    'trf_evidence': trf_evidence
                }

            # Output progress every 10 candidates
            if (idx + 1) % 10 == 0 or (idx + 1) == actual_candidates:
                logger.info(f"  Validation progress: {idx + 1}/{actual_candidates} candidates completed, "
                            f"current motif: {motif}, terminus_count={terminus_count}")

        return validated


# ============================================================================
# Report Generator
# ============================================================================

class ReportGenerator:
    """Generate analysis reports"""

    def __init__(self, output_dir: Path):
        self.output_dir = output_dir

    def generate_all(self, motifs: List[TelomereMotif], total_reads: int,
                     tandem_reads_count: int):
        """Generate all reports"""
        logger.info("Generating analysis reports...")
        self._generate_json(motifs, total_reads, tandem_reads_count)
        self._generate_tsv(motifs)
        self._generate_html(motifs, total_reads, tandem_reads_count)
        logger.info(f"  ✔ Reports saved to {self.output_dir}")

    def _generate_json(self, motifs: List[TelomereMotif],
                       total_reads: int, tandem_reads_count: int):
        """Generate JSON format report"""
        json_file = self.output_dir / "motif_identification_results.json"

        data = {
            'version': VERSION,
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_reads_processed': total_reads,
                'tandem_reads_found': tandem_reads_count,
                'candidate_motifs_identified': len(motifs),
                'top_motif': motifs[0].sequence if motifs else None
            },
            'motifs': [
                {
                    'sequence': m.sequence,
                    'reverse_complement': m.reverse_complement,
                    'count': m.count,
                    'score': m.score,
                    'source': m.source,
                    'priority': m.priority,
                    'algorithm': m.algorithm,
                    'supporting_evidence': m.supporting_evidence
                }
                for m in motifs
            ]
        }

        with open(json_file, 'w') as f:
            json.dump(data, f, indent=2)

    def _generate_tsv(self, motifs: List[TelomereMotif]):
        """Generate TSV format list"""
        tsv_file = self.output_dir / "discovered_motifs.tsv"
        with open(tsv_file, 'w') as f:
            f.write("Rank\tMotif\tReverse_Complement\tScore\tTotal_Count\tTerminus_Count\tSource\tAlgorithm\n")
            for i, m in enumerate(motifs, 1):
                evidence = m.supporting_evidence
                terminus_count = evidence.get('terminus_count', 0)
                total_count = evidence.get('total_count', 0)
                f.write(f"{i}\t{m.sequence}\t{m.reverse_complement}\t"
                        f"{m.score:.6f}\t{total_count}\t{terminus_count}\t{m.source}\t{m.algorithm}\n")

    def _generate_html(self, motifs: List[TelomereMotif],
                       total_reads: int, tandem_reads_count: int):
        """Generate HTML report"""
        html_file = self.output_dir / "motif_identification_report.html"

        html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TelomereMotifIdentifier_ONT v{VERSION} Analysis Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 20px; background: #f5f7fa; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        h2 {{ color: #34495e; border-bottom: 2px solid #3498db; padding-bottom: 8px; margin-top: 30px; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-box {{ background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; }}
        .stat-number {{ font-size: 36px; font-weight: bold; color: #2980b9; }}
        .stat-label {{ font-size: 14px; color: #7f8c8d; margin-top: 8px; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }}
        th, td {{ border: 1px solid #ecf0f1; padding: 12px 15px; text-align: left; }}
        th {{ background: #3498db; color: white; font-weight: 600; }}
        tr:nth-child(even) {{ background-color: #f8f9fa; }}
        .info-box {{ background: #e8f6ff; border-left: 4px solid #3498db; padding: 15px; margin: 15px 0; border-radius: 0 8px 8px 0; }}
        .motif-highlight {{ background-color: #f1c40f; color: #2c3e50; padding: 1px 3px; border-radius: 3px; }}
        .motif-rc {{ background-color: #e74c3c; color: white; padding: 1px 3px; border-radius: 3px; }}
        .algorithm-tag {{ background-color: #27ae60; color: white; padding: 2px 8px; border-radius: 3px; font-size: 12px; }}
        footer {{ margin-top: 40px; padding: 20px; border-top: 2px solid #ddd; text-align: center; color: #7f8c8d; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧬 TelomereMotifIdentifier_ONT v{VERSION} Telomere Motif Identification Report</h1>
        <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p>Algorithm: <span class="algorithm-tag">ONT reads (TRF+terminus validation)</span></p>

        <h2>📊 Summary Statistics</h2>
        <div class="summary-grid">
            <div class="stat-box">
                <div class="stat-number">{total_reads:,}</div>
                <div class="stat-label">Total Reads</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{tandem_reads_count:,}</div>
                <div class="stat-label">Tandem Repeat Reads</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{len(motifs)}</div>
                <div class="stat-label">Identified Motifs</div>
            </div>
        </div>

        <div class="info-box">
            <strong>ONT Algorithm:</strong> TRF discovery from reads + read terminus frequency validation<br>
            <strong>Parameter Settings:</strong> Repeat unit length 6-12bp, minimum repeats 10 times (TRF screening)
        </div>

        <h2>🔍 Identified Telomere Motifs</h2>
        <table>
            <tr><th>Rank</th><th>Motif Sequence</th><th>Reverse Complement</th><th>Confidence</th><th>TRF Count</th><th>Terminus Validation</th><th>Source</th></tr>
'''

        for i, m in enumerate(motifs[:10], 1):
            evidence = m.supporting_evidence
            terminus_count = evidence.get('terminus_count', 0)
            total_count = evidence.get('total_count', 0)
            html_content += f'''
            <tr>
                <td>{i}</td>
                <td><code class="motif-highlight">{m.sequence}</code></td>
                <td><code class="motif-rc">{m.reverse_complement}</code></td>
                <td>{m.score:.4f}</td>
                <td>{total_count}</td>
                <td>{terminus_count}</td>
                <td>{m.source}</td>
            </tr>
'''

        html_content += '''
        </table>

        <footer>
            <p>Generated by TelomereMotifIdentifier_ONT v{VERSION} | {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            <p>ONT Algorithm: Uses TRF to discover potential motifs from ONT reads, then validates their frequency at read termini</p>
        </footer>
    </div>
</body>
</html>
'''

        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)


# ============================================================================
# Main Pipeline
# ============================================================================

class TelomereMotifIdentifierPipeline:
    """ONT telomere motif identification main pipeline"""

    def __init__(self,
                 reads_file: str,
                 output_dir: str,
                 min_period: int = 6,
                 max_period: int = 12,
                 min_repeat_count: int = 10,
                 terminus_check_size: int = 300,
                 skip_trf: bool = False):

        self.reads_file = os.path.abspath(reads_file)
        self.output_dir = Path(output_dir).absolute()
        self.min_period = min_period
        self.max_period = max_period
        self.min_repeat_count = min_repeat_count
        self.terminus_check_size = terminus_check_size
        self.skip_trf = skip_trf

        self.output_dir.mkdir(parents=True, exist_ok=True)

        log_file = self.output_dir / "motif_identification.log"
        file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
        file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logger.addHandler(file_handler)

    def run(self) -> bool:
        """Run ONT motif identification pipeline"""
        try:
            self._print_header()

            logger.info("Checking software dependencies")
            has_trf = check_dependencies()

            # Count total reads
            total_reads = self._count_total_reads()
            logger.info(f"Total Reads: {total_reads:,}")

            # Initialize motif identifier
            motif_identifier = MotifIdentifier(
                min_period=self.min_period,
                max_period=self.max_period,
                min_repeat_count=self.min_repeat_count,
                terminus_check_size=self.terminus_check_size
            )

            motifs = []
            tandem_reads_count = 0

            if self.skip_trf or not has_trf:
                logger.info("Skipping TRF screening step, reading tandem reads directly from input file")
                # Assume input file is already screened tandem reads, read and process directly
                tandem_reads = []
                for read_id, seq, qual in parse_fastq_streaming(self.reads_file):
                    tandem_reads.append(TandemRepeatRead(
                        read_id=read_id,
                        sequence=seq,
                        quality=qual,
                        trf_results=[],  # Empty list since we skipped TRF
                        best_repeat_unit="",  # Placeholder
                        best_copy_number=0,  # Placeholder
                        repeat_position="unknown"  # Placeholder
                    ))
                motifs = motif_identifier.identify_from_tandem_reads(tandem_reads)
                tandem_reads_count = len(tandem_reads)
                logger.info(f"Processed {len(tandem_reads)} reads from input file")
            else:
                logger.info("Using complete ONT identification pipeline (TRF + terminus validation)")
                motifs, tandem_reads_count = motif_identifier.identify_from_raw_reads_with_tandem(self.reads_file)

            if not motifs:
                logger.warning("No telomere motif candidates discovered")
                # Add default motif
                motifs.append(TelomereMotif(
                    sequence="TTAGGG",
                    reverse_complement="CCCTAA",
                    count=0,
                    score=0.0,
                    source='default',
                    priority=4,
                    algorithm='default',
                    supporting_evidence={'default': True}
                ))
                logger.info("Added default motif TTAGGG as backup")

            logger.info(f"Identified {len(motifs)} candidate motifs in total")
            for i, m in enumerate(motifs[:5], 1):
                evidence = m.supporting_evidence
                terminus_count = evidence.get('terminus_count', 0)
                logger.info(f"  {i}. {m.sequence} (TC: {terminus_count}, Score: {m.score:.0f})")

            # Generate reports
            reporter = ReportGenerator(self.output_dir)
            reporter.generate_all(motifs, total_reads, tandem_reads_count)

            # Save best motif to separate file
            if motifs:
                best_motif = motifs[0]
                ml = len(best_motif.sequence)
                concatenated_seq = best_motif.sequence + best_motif.sequence
                motif_file = self.output_dir / "best_motif.txt"
                with open(motif_file, 'w') as f:
                    for i in range(len(concatenated_seq) - ml + 1):
                        kmer = concatenated_seq[i:i + ml]
                        f.write(f"{kmer}\n")
                logger.info(f"Best motif saved to: {motif_file}")

            self._print_summary(motifs, total_reads, tandem_reads_count)
            return True

        except Exception as e:
            logger.error(f"Pipeline failed: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return False

    def _count_total_reads(self) -> int:
        """Count total reads"""
        count = 0
        for _ in parse_fastq_streaming(self.reads_file):
            count += 1
        return count

    def _print_header(self):
        """Print header"""
        logger.info(f"""
╔═══════════════════════════════════════════════════════════════════╗
║     TelomereMotifIdentifier_ONT v{VERSION}                         ║
║     ONT Reads Telomere Motif Identification Tool (TRF+Terminus Validation)   ║
╚═══════════════════════════════════════════════════════════════════╝
    """)
        logger.info(f"Reads file: {self.reads_file}")
        logger.info(f"Output directory: {self.output_dir}")
        logger.info(f"Parameters: repeat unit={self.min_period}-{self.max_period}bp, "
                    f"min TRF repeats={self.min_repeat_count}, "
                    f"terminus validation region={self.terminus_check_size}bp")
        if self.skip_trf:
            logger.info("Skip TRF screening: Yes")

    def _print_summary(self, motifs: List[TelomereMotif],
                       total_reads: int, tandem_reads_count: int):
        """Print final summary"""
        best_motif = motifs[0] if motifs else None
        best_motif_display = best_motif.sequence if best_motif and len(best_motif.sequence) <= 12 else (
            best_motif.sequence[:9] + "..." if best_motif else 'N/A')

        print(f"""
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                    Analysis Complete (v{VERSION})                             ║
    ╠═══════════════════════════════════════════════════════════════════╣
    ║  Total Reads:         {total_reads:>8,}                               ║
    ║  Tandem Repeat Reads:    {tandem_reads_count:>8,}                        ║
    ║  Identified Motifs:      {len(motifs):>8}                                ║
    ║  Best Motif:        {best_motif_display:>8}                         ║
    ╠═══════════════════════════════════════════════════════════════════╣
    ║  Output Directory: {str(self.output_dir):<48}║
    ╚═══════════════════════════════════════════════════════════════════╝
    """)


# ============================================================================
# Command Line Interface
# ============================================================================

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description=f"TelomereMotifIdentifier_ONT v{VERSION} - ONT Reads Telomere Motif Identification Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
Examples:
  # Basic usage
  python TelomereMotifIdentifier_ONT.py -r reads.fastq -o output/

  # Specify TRF parameters
  python TelomereMotifIdentifier_ONT.py -r reads.fastq -o output/ --min-period 6 --max-period 12

  # Skip TRF screening (if input is already tandem reads)
  python TelomereMotifIdentifier_ONT.py -r tandem_reads.fastq -o output/ --skip-trf

  # Use stricter parameters
  python TelomereMotifIdentifier_ONT.py -r reads.fastq -o output/ --min-repeat 15 --min-period 5

Algorithm Description:
  1. (Optional) Use TRF to screen reads containing tandem repeats (min_period - max_period bp, min_repeat times)
  2. Collect candidate motifs from TRF results (sorted by occurrence count)
  3. Validate candidate motif frequency at all tandem read termini
  4. Output candidate motifs sorted by validation results (score=terminus validation count)
        """
    )

    required = parser.add_argument_group('Required Arguments')
    required.add_argument('-r', '--reads', required=True,
                          help='ONT/PacBio long read data (FASTQ format, supports .gz compression)')
    required.add_argument('-o', '--output', required=True,
                          help='Output directory')

    optional = parser.add_argument_group('Optional Arguments')
    optional.add_argument('--min-period', type=int, default=6,
                          help='Minimum repeat unit length for TRF detection (default: 6)')
    optional.add_argument('--max-period', type=int, default=12,
                          help='Maximum repeat unit length for TRF detection (default: 12)')
    optional.add_argument('--min-repeat', type=int, default=10,
                          help='Minimum repeat count for TRF detection (default: 10)')
    optional.add_argument('--terminus-check-size', type=int, default=300,
                          help='Read terminus validation region size (default: 300)')
    optional.add_argument('--skip-trf', action='store_true',
                          help='Skip TRF screening step (if input file is already tandem reads)')
    optional.add_argument('-v', '--verbose', action='store_true',
                          help='Show detailed output information')

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    if not os.path.exists(args.reads):
        logger.error(f"Reads file does not exist: {args.reads}")
        sys.exit(1)

    pipeline = TelomereMotifIdentifierPipeline(
        reads_file=args.reads,
        output_dir=args.output,
        min_period=args.min_period,
        max_period=args.max_period,
        min_repeat_count=args.min_repeat,
        terminus_check_size=args.terminus_check_size,
        skip_trf=args.skip_trf
    )

    success = pipeline.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()