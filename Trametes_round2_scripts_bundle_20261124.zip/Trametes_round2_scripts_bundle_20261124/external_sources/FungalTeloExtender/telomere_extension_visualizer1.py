#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telomere Extension Visualizer v3.1
==================================
用于可视化基因组端粒延伸结果的脚本

更新：
- 染色体名称放在左边
- 5'端延伸的染色体右对齐
- 移除多余的小字标注

作者: Claude
日期: 2025-01-22
"""

import argparse
import re
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.patches import FancyBboxPatch, Rectangle
import numpy as np
import pandas as pd


def parse_fasta(fasta_file):
    """解析FASTA文件"""
    sequences = {}
    current_id = None
    current_seq = []
    
    with open(fasta_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if current_id is not None:
                    sequences[current_id] = ''.join(current_seq)
                current_id = line[1:].split()[0]
                current_seq = []
            else:
                current_seq.append(line.upper())
        
        if current_id is not None:
            sequences[current_id] = ''.join(current_seq)
    
    return sequences


def parse_extension_data(data_file):
    """解析端粒延伸统计数据"""
    df = pd.read_csv(data_file, sep='\t')
    return df


def reverse_complement(seq):
    """获取序列的反向互补"""
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(complement.get(base, base) for base in reversed(seq))


def calculate_motif_density(sequence, motifs, window_size=100, step=50):
    """计算序列中端粒motif的密度"""
    seq_len = len(sequence)
    if seq_len == 0:
        return [], []
    
    positions = []
    densities = []
    
    for start in range(0, seq_len - window_size + 1, step):
        end = start + window_size
        window_seq = sequence[start:end]
        
        count = 0
        for motif in motifs:
            count += len(re.findall(motif, window_seq, re.IGNORECASE))
            rc_motif = reverse_complement(motif)
            if rc_motif != motif:
                count += len(re.findall(rc_motif, window_seq, re.IGNORECASE))
        
        motif_len = len(motifs[0]) if motifs else 8
        density = (count * motif_len) / window_size
        
        positions.append((start + end) / 2)
        densities.append(min(density, 1.0))
    
    return positions, densities


def find_tandem_repeats(sequence, motif, min_repeats=2):
    """在序列中查找端粒motif的串联重复"""
    repeats = []
    motif_len = len(motif)
    
    pattern = f'({motif}){{2,}}'
    for match in re.finditer(pattern, sequence, re.IGNORECASE):
        start, end = match.span()
        repeat_count = (end - start) // motif_len
        if repeat_count >= min_repeats:
            repeats.append((start, end, repeat_count, motif))
    
    rc_motif = reverse_complement(motif)
    if rc_motif != motif:
        pattern = f'({rc_motif}){{2,}}'
        for match in re.finditer(pattern, sequence, re.IGNORECASE):
            start, end = match.span()
            repeat_count = (end - start) // motif_len
            if repeat_count >= min_repeats:
                repeats.append((start, end, repeat_count, rc_motif))
    
    return sorted(repeats, key=lambda x: -x[2])


def draw_heatmap_bar(ax, x_start, y_center, width, height, densities, 
                     cmap='Blues', edgecolor='#1a365d', linewidth=1.5):
    """绘制带蓝色热图填充的条形"""
    rect = FancyBboxPatch(
        (x_start, y_center - height/2),
        width, height,
        boxstyle="round,pad=0,rounding_size=0.008",
        facecolor='#f0f4f8',
        edgecolor=edgecolor,
        linewidth=linewidth,
        zorder=1
    )
    ax.add_patch(rect)
    
    if len(densities) > 0:
        colormap = plt.get_cmap(cmap)
        n_segments = len(densities)
        segment_width = width / n_segments
        
        for i, density in enumerate(densities):
            seg_x = x_start + i * segment_width
            color = colormap(0.2 + density * 0.8)
            
            seg_rect = Rectangle(
                (seg_x, y_center - height/2 + 0.002),
                segment_width,
                height - 0.004,
                facecolor=color,
                edgecolor='none',
                zorder=2
            )
            ax.add_patch(seg_rect)
    
    border = FancyBboxPatch(
        (x_start, y_center - height/2),
        width, height,
        boxstyle="round,pad=0,rounding_size=0.008",
        facecolor='none',
        edgecolor=edgecolor,
        linewidth=linewidth,
        zorder=3
    )
    ax.add_patch(border)


def draw_sequence_with_boxes(ax, sequence, motif, x_start, y_center, 
                              max_width=0.75, max_chars_per_line=80,
                              box_height=0.04, line_spacing=0.055):
    """绘制序列，每个motif用方框圈出"""
    motif_len = len(motif)
    seq_len = len(sequence)
    
    char_width = max_width / max_chars_per_line
    
    lines = []
    for i in range(0, seq_len, max_chars_per_line):
        lines.append(sequence[i:i+max_chars_per_line])
    
    base_colors = {
        'A': '#e74c3c',
        'T': '#3498db',
        'G': '#2ecc71',
        'C': '#f39c12',
    }
    
    motif_positions = set()
    for match in re.finditer(motif, sequence, re.IGNORECASE):
        for pos in range(match.start(), match.end()):
            motif_positions.add(pos)
    
    rc_motif = reverse_complement(motif)
    if rc_motif != motif:
        for match in re.finditer(rc_motif, sequence, re.IGNORECASE):
            for pos in range(match.start(), match.end()):
                motif_positions.add(pos)
    
    total_height = len(lines) * line_spacing
    start_y = y_center + total_height / 2 - line_spacing / 2
    
    for line_idx, line in enumerate(lines):
        line_y = start_y - line_idx * line_spacing
        line_start_pos = line_idx * max_chars_per_line
        
        i = 0
        while i < len(line):
            global_pos = line_start_pos + i
            
            if global_pos in motif_positions:
                motif_start = i
                while i < len(line) and (line_start_pos + i) in motif_positions:
                    i += 1
                motif_end = i
                
                box_x = x_start + motif_start * char_width
                
                num_bases = motif_end - motif_start
                num_complete_motifs = num_bases // motif_len
                remainder = num_bases % motif_len
                
                current_x = box_x
                for m in range(num_complete_motifs):
                    motif_box = FancyBboxPatch(
                        (current_x, line_y - box_height/2),
                        motif_len * char_width,
                        box_height,
                        boxstyle="round,pad=0.003,rounding_size=0.008",
                        facecolor='#e8f4f8',
                        edgecolor='#2980b9',
                        linewidth=1.5,
                        zorder=1
                    )
                    ax.add_patch(motif_box)
                    current_x += motif_len * char_width
                
                if remainder > 0:
                    partial_box = FancyBboxPatch(
                        (current_x, line_y - box_height/2),
                        remainder * char_width,
                        box_height,
                        boxstyle="round,pad=0.003,rounding_size=0.008",
                        facecolor='#fef9e7',
                        edgecolor='#f39c12',
                        linewidth=1,
                        linestyle='--',
                        zorder=1
                    )
                    ax.add_patch(partial_box)
            else:
                i += 1
        
        for i, base in enumerate(line):
            char_x = x_start + i * char_width + char_width / 2
            color = base_colors.get(base.upper(), '#333333')
            
            ax.text(char_x, line_y, base,
                    ha='center', va='center',
                    fontsize=7, fontfamily='monospace',
                    fontweight='bold', color=color,
                    zorder=2)
    
    return total_height


def plot_single_extension(ax, chrom_id, terminus, extension_length, motif, repeat_count,
                          before_seq, after_seq, view_length=20000):
    """绘制单个染色体延伸的对比图"""
    
    # 提取显示区域
    if terminus == '5prime':
        before_display = before_seq[:view_length] if len(before_seq) >= view_length else before_seq
        after_display = after_seq[:view_length + extension_length] if len(after_seq) >= view_length + extension_length else after_seq
        extension_region = after_seq[:extension_length] if len(after_seq) >= extension_length else after_seq
    else:
        before_display = before_seq[-view_length:] if len(before_seq) >= view_length else before_seq
        after_display = after_seq[-(view_length + extension_length):] if len(after_seq) >= view_length + extension_length else after_seq
        extension_region = after_seq[-extension_length:] if len(after_seq) >= extension_length else ''
    
    # 计算密度
    motifs = [motif, reverse_complement(motif)]
    before_pos, before_dens = calculate_motif_density(before_display, motifs, window_size=200, step=100)
    after_pos, after_dens = calculate_motif_density(after_display, motifs, window_size=200, step=100)
    
    # 绘图参数
    bar_height = 0.06
    y_before = 0.82
    y_after = 0.62
    max_width = 0.70
    left_margin = 0.18  # 左边留空给染色体名称
    right_margin = 0.90  # 右边界
    
    # 计算比例
    max_length = max(len(before_display), len(after_display))
    before_width = max_width * (len(before_display) / max_length)
    after_width = max_width * (len(after_display) / max_length)
    
    # 根据terminus决定对齐方式
    if terminus == '5prime':
        # 5'端延伸：右对齐
        before_x_start = right_margin - before_width
        after_x_start = right_margin - after_width
    else:
        # 3'端延伸：左对齐
        before_x_start = left_margin
        after_x_start = left_margin
    
    # ===== 绘制延伸前 =====
    draw_heatmap_bar(ax, before_x_start, y_before, before_width, bar_height, before_dens)
    # 染色体名称在左边
    ax.text(0.02, y_before, f'{chrom_id}\n(Before)', 
            ha='left', va='center', fontsize=10, fontweight='bold', color='#1a365d')
    # 长度标注
    if terminus == '5prime':
        ax.text(before_x_start - 0.01, y_before, f'{len(before_display):,} bp',
                ha='right', va='center', fontsize=9, color='#7f8c8d')
    else:
        ax.text(before_x_start + before_width + 0.01, y_before, f'{len(before_display):,} bp',
                ha='left', va='center', fontsize=9, color='#7f8c8d')
    
    # ===== 绘制延伸后 =====
    draw_heatmap_bar(ax, after_x_start, y_after, after_width, bar_height, after_dens)
    ax.text(0.02, y_after, f'{chrom_id}\n(After)', 
            ha='left', va='center', fontsize=10, fontweight='bold', color='#1a365d')
    if terminus == '5prime':
        ax.text(after_x_start - 0.01, y_after, f'{len(after_display):,} bp',
                ha='right', va='center', fontsize=9, color='#7f8c8d')
    else:
        ax.text(after_x_start + after_width + 0.01, y_after, f'{len(after_display):,} bp',
                ha='left', va='center', fontsize=9, color='#7f8c8d')
    
    # ===== 标注延伸区域 =====
    if extension_length > 0:
        ext_ratio = extension_length / len(after_display)
        
        if terminus == '5prime':
            # 5'端延伸在左边
            ext_x_start = after_x_start
            ext_x_end = after_x_start + after_width * ext_ratio
        else:
            # 3'端延伸在右边
            ext_x_start = after_x_start + after_width * (1 - ext_ratio)
            ext_x_end = after_x_start + after_width
        
        # 竖直标记线
        for x in [ext_x_start, ext_x_end]:
            ax.axvline(x=x, ymin=0.55, ymax=0.92, 
                       color='#27ae60', linewidth=2, linestyle='--', alpha=0.8)
        
        # 延伸区域标注箭头
        mid_x = (ext_x_start + ext_x_end) / 2
        ax.annotate('', xy=(ext_x_end, 0.55), xytext=(ext_x_start, 0.55),
                    arrowprops=dict(arrowstyle='<->', color='#27ae60', lw=2))
        ax.text(mid_x, 0.52, f'Extended: {extension_length:,} bp',
                ha='center', va='top', fontsize=10, color='#27ae60', fontweight='bold')
    
    # ===== 绘制串联重复序列 =====
    tandem_repeats = find_tandem_repeats(extension_region, motif)
    if tandem_repeats:
        rep_start, rep_end, rep_count, rep_motif = tandem_repeats[0]
        tandem_seq = extension_region[rep_start:rep_end]
        
        ax.text(0.02, 0.42, f'Tandem Repeat ({rep_motif} × {rep_count}):',
                ha='left', va='center', fontsize=10, fontweight='bold', color='#1a365d')
        
        display_seq = tandem_seq[:240] if len(tandem_seq) > 240 else tandem_seq
        seq_height = draw_sequence_with_boxes(ax, display_seq, rep_motif, 
                                               0.02, 0.28, 
                                               max_width=0.92, max_chars_per_line=100)
        
        if len(tandem_seq) > 240:
            ax.text(0.94, 0.10, f'... ({len(tandem_seq) - 240} more bases)',
                    ha='right', va='center', fontsize=8, color='#7f8c8d', style='italic')
    
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')


def create_visualization(before_fasta, after_fasta, extension_data, output_file,
                         view_length=20000, chromosomes=None):
    """创建完整的可视化图"""
    print("Reading FASTA files...")
    before_seqs = parse_fasta(before_fasta)
    after_seqs = parse_fasta(after_fasta)
    
    print("Reading extension data...")
    ext_df = parse_extension_data(extension_data)
    
    if chromosomes:
        ext_df = ext_df[ext_df['Chromosome'].isin(chromosomes)]
    
    n_chroms = len(ext_df)
    if n_chroms == 0:
        print("No chromosomes to display!")
        return
    
    print(f"Creating visualization for {n_chroms} chromosome extensions...")
    
    fig_height = max(6, 5 * n_chroms)
    fig, axes = plt.subplots(n_chroms, 1, figsize=(16, fig_height))
    
    if n_chroms == 1:
        axes = [axes]
    
    for idx, (_, row) in enumerate(ext_df.iterrows()):
        ax = axes[idx]
        chrom_id = row['Chromosome']
        terminus = row['Terminus']
        ext_length = int(row['Extension Length (bp)'])
        motif = row['Motif']
        repeat_count = int(row['Repeat Count'])
        
        before_seq = before_seqs.get(chrom_id, '')
        after_seq = after_seqs.get(chrom_id, '')
        
        if not before_seq or not after_seq:
            print(f"Warning: Sequence not found for {chrom_id}")
            ax.text(0.5, 0.5, f'Sequence not found for {chrom_id}',
                    ha='center', va='center', fontsize=12, color='red')
            ax.axis('off')
            continue
        
        plot_single_extension(ax, chrom_id, terminus, ext_length, motif, repeat_count,
                              before_seq, after_seq, view_length)
    
    # 添加颜色条
    cbar_ax = fig.add_axes([0.99, 0.15, 0.012, 0.7])
    norm = mcolors.Normalize(vmin=0, vmax=1)
    sm = plt.cm.ScalarMappable(cmap='Blues', norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax)
    cbar.set_label('Telomere Motif Density', fontsize=11, color='#1a365d')
    
    species = ext_df['Species'].iloc[0] if 'Species' in ext_df.columns else 'Unknown'
    fig.suptitle(f'Telomere Extension Visualization - {species}', 
                 fontsize=16, fontweight='bold', y=0.98, color='#1a365d')
    
    plt.subplots_adjust(left=0.02, right=0.90, top=0.94, bottom=0.03, hspace=0.3)
    
    plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"Visualization saved to: {output_file}")
    
    return fig


def create_summary_figure(before_fasta, after_fasta, extension_data, output_file,
                          view_length=20000):
    """创建汇总图"""
    print("Reading FASTA files...")
    before_seqs = parse_fasta(before_fasta)
    after_seqs = parse_fasta(after_fasta)
    
    print("Reading extension data...")
    ext_df = parse_extension_data(extension_data)
    
    n_chroms = len(ext_df)
    
    fig, ax = plt.subplots(figsize=(16, max(10, n_chroms * 0.8)))
    
    bar_height = 0.5 / (n_chroms + 1)
    y_spacing = 0.85 / (n_chroms + 1)
    
    # 绘图区域
    left_area_start = 0.20
    right_area_end = 0.88
    bar_max_width = 0.30
    
    for idx, (_, row) in enumerate(ext_df.iterrows()):
        chrom_id = row['Chromosome']
        terminus = row['Terminus']
        ext_length = int(row['Extension Length (bp)'])
        motif = row['Motif']
        repeat_count = int(row['Repeat Count'])
        
        before_seq = before_seqs.get(chrom_id, '')
        after_seq = after_seqs.get(chrom_id, '')
        
        if not before_seq or not after_seq:
            continue
        
        y_pos = 0.9 - (idx + 1) * y_spacing
        
        if terminus == '5prime':
            before_display = before_seq[:view_length]
            after_display = after_seq[:view_length + ext_length]
        else:
            before_display = before_seq[-view_length:]
            after_display = after_seq[-(view_length + ext_length):]
        
        motifs = [motif, reverse_complement(motif)]
        before_pos, before_dens = calculate_motif_density(before_display, motifs, 300, 150)
        after_pos, after_dens = calculate_motif_density(after_display, motifs, 300, 150)
        
        max_len = max(len(before_display), len(after_display))
        before_width = bar_max_width * (len(before_display) / max_len)
        after_width = bar_max_width * (len(after_display) / max_len)
        
        # Before 区域
        before_area_right = left_area_start + bar_max_width
        # After 区域  
        after_area_left = 0.55
        after_area_right = after_area_left + bar_max_width
        
        if terminus == '5prime':
            # 5'端：右对齐
            before_x = before_area_right - before_width
            after_x = after_area_right - after_width
        else:
            # 3'端：左对齐
            before_x = left_area_start
            after_x = after_area_left
        
        draw_heatmap_bar(ax, before_x, y_pos, before_width, bar_height, before_dens, linewidth=1)
        draw_heatmap_bar(ax, after_x, y_pos, after_width, bar_height, after_dens, linewidth=1)
        
        # 延伸区域标记
        if ext_length > 0:
            ext_ratio = ext_length / len(after_display)
            if terminus == '5prime':
                ext_start = after_x
                ext_end = after_x + after_width * ext_ratio
            else:
                ext_start = after_x + after_width * (1 - ext_ratio)
                ext_end = after_x + after_width
            
            highlight = Rectangle(
                (ext_start, y_pos - bar_height/2),
                ext_end - ext_start,
                bar_height,
                facecolor='none',
                edgecolor='#27ae60',
                linewidth=2,
                linestyle='-',
                zorder=4
            )
            ax.add_patch(highlight)
        
        # 染色体名称在最左边
        ax.text(0.02, y_pos, chrom_id, ha='left', va='center', 
                fontsize=9, fontweight='bold', color='#1a365d')
        # terminus标记
        ax.text(0.13, y_pos, f"({terminus[:2]})", ha='center', va='center',
                fontsize=8, color='#5d6d7e')
        # 延伸信息在最右边
        ax.text(0.92, y_pos, f'+{ext_length:,} bp\n{motif}×{repeat_count}',
                ha='left', va='center', fontsize=8, color='#27ae60', fontweight='bold')
    
    # 列标题
    ax.text(left_area_start + bar_max_width/2, 0.95, 'Before Extension', ha='center', va='center',
            fontsize=12, fontweight='bold', color='#1a365d')
    ax.text(0.55 + bar_max_width/2, 0.95, 'After Extension', ha='center', va='center',
            fontsize=12, fontweight='bold', color='#1a365d')
    
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    
    cbar_ax = fig.add_axes([0.99, 0.15, 0.012, 0.7])
    norm = mcolors.Normalize(vmin=0, vmax=1)
    sm = plt.cm.ScalarMappable(cmap='Blues', norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax)
    cbar.set_label('Telomere Motif Density', fontsize=10, color='#1a365d')
    
    legend_elements = [
        mpatches.Patch(facecolor='none', edgecolor='#27ae60', linewidth=2,
                       label='Extended Region')
    ]
    ax.legend(handles=legend_elements, loc='lower right', fontsize=10)
    
    species = ext_df['Species'].iloc[0] if 'Species' in ext_df.columns else 'Unknown'
    fig.suptitle(f'Telomere Extension Summary - {species}',
                 fontsize=16, fontweight='bold', color='#1a365d')
    
    plt.savefig(output_file, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"Summary figure saved to: {output_file}")
    
    return fig


def main():
    parser = argparse.ArgumentParser(
        description='Visualize telomere extension results',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Example usage:
  python telomere_extension_visualizer.py \\
      -b genome_before.fasta \\
      -a genome_after.fasta \\
      -d Figure7.txt \\
      -o telomere_extension.png
      
  python telomere_extension_visualizer.py \\
      -b genome_before.fasta \\
      -a genome_after.fasta \\
      -d Figure7.txt \\
      -o telomere_summary.png \\
      --summary
        '''
    )
    
    parser.add_argument('-b', '--before', required=True,
                        help='FASTA file of genome before extension')
    parser.add_argument('-a', '--after', required=True,
                        help='FASTA file of genome after extension')
    parser.add_argument('-d', '--data', required=True,
                        help='Extension statistics file (TSV format)')
    parser.add_argument('-o', '--output', required=True,
                        help='Output figure file (PNG/PDF/SVG)')
    parser.add_argument('-l', '--view-length', type=int, default=20000,
                        help='Length of original sequence to display (default: 20000)')
    parser.add_argument('-c', '--chromosomes', nargs='+', default=None,
                        help='Specific chromosomes to display')
    parser.add_argument('--summary', action='store_true',
                        help='Generate summary figure instead of individual plots')
    
    args = parser.parse_args()
    
    for f in [args.before, args.after, args.data]:
        if not Path(f).exists():
            print(f"Error: File not found: {f}")
            sys.exit(1)
    
    if args.summary:
        create_summary_figure(args.before, args.after, args.data, 
                              args.output, args.view_length)
    else:
        create_visualization(args.before, args.after, args.data,
                             args.output, args.view_length, args.chromosomes)


if __name__ == '__main__':
    main()
