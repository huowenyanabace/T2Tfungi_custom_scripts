#!/usr/bin/env python3
"""
Python script to call tidk explore command with various parameters.
==================================================
Author: FungalTeloExtender Team
Version: 1.0.0
License: MIT
"""

import subprocess
import argparse
import sys
import os
from pathlib import Path


def run_tidk_explore(fasta_file, length=None, minimum=None, maximum=None,
                     threshold=None, distance=None, verbose=False, log=False, output_file=None):
    """
    Run the tidk explore command with specified parameters.

    Args:
        fasta_file (str): Input fasta file
        length (int, optional): Length of substring
        minimum (int, optional): Minimum length of substring
        maximum (int, optional): Maximum length of substring
        threshold (int, optional): Threshold for repeat positions
        distance (float, optional): Distance from end of chromosome as proportion
        verbose (bool): Enable verbose output
        log (bool): Output log file
        output_file (str, optional): Output file path for results

    Returns:
        CompletedProcess: Result of the subprocess execution
    """
    # Build the command
    cmd = ["tidk", "explore"]

    # Add optional arguments if provided
    if length is not None:
        cmd.extend(["-l", str(length)])
    if minimum is not None:
        cmd.extend(["-m", str(minimum)])
    if maximum is not None:
        cmd.extend(["-x", str(maximum)])
    if threshold is not None:
        cmd.extend(["-t", str(threshold)])
    if distance is not None:
        cmd.extend(["--distance", str(distance)])
    if verbose:
        cmd.append("-v")
    if log:
        cmd.append("--log")

    # Add the FASTA file at the end
    cmd.append(fasta_file)

    print(f"Running command: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Save output to TSV file if specified
        if output_file:
            save_output_to_tsv(result.stdout, output_file)

        return result
    except subprocess.CalledProcessError as e:
        print(f"Error running tidk explore: {e}")
        print(f"Stderr: {e.stderr}")
        sys.exit(1)


def save_output_to_tsv(output_data, output_file):
    """
    Save the tidk explore output to a TSV file.

    Args:
        output_data (str): Raw output from tidk explore
        output_file (str): Path to the output TSV file
    """
    # Process the output and convert to TSV format
    lines = output_data.strip().split('\n')

    # Create a TSV file with the output
    with open(output_file, 'w') as f:
        # Write header row with the expected format
        f.write("canonical_repeat_unit\tcount\n")

        # Process each line of output
        for line in lines:
            if line.strip() and not line.startswith('#') and not line.startswith('Error') and not line.startswith('canonical_repeat_unit'):
                # Parse the line - assuming tidk explore outputs repeat unit and count
                # Format might be: <repeat_unit> <count> or similar
                fields = line.strip().split()  # Split by whitespace
                if len(fields) >= 2:
                    # Assuming first field is the repeat unit and second is the count
                    repeat_unit = fields[0]
                    count = fields[1]
                    f.write(f"{repeat_unit}\t{count}\n")

    print(f"Output saved to: {output_file}")


def main():
    parser = argparse.ArgumentParser(description="Run tidk explore command")
    parser.add_argument("fasta_file", help="Input FASTA file")
    parser.add_argument("-l", "--length", type=int, help="Length of substring")
    parser.add_argument("-m", "--minimum", type=int, help="Minimum length of substring [default: 5]")
    parser.add_argument("-x", "--maximum", type=int, help="Maximum length of substring [default: 12]")
    parser.add_argument("-t", "--threshold", type=int, help="Threshold for repeat positions [default: 100]")
    parser.add_argument("--distance", type=float, help="Distance from end of chromosome as proportion [default: 0.01]")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")
    parser.add_argument("--log", action="store_true", help="Output log file")
    parser.add_argument("--dry-run", action="store_true", help="Print command without executing")
    parser.add_argument("-o", "--output", help="Output TSV file (default: <fasta_name>_tidk_results.tsv)")

    args = parser.parse_args()

    if not os.path.isfile(args.fasta_file):
        print(f"Error: FASTA file {args.fasta_file} does not exist.")
        sys.exit(1)

    # Generate default output file name if not provided
    if not args.output:
        fasta_path = Path(args.fasta_file)
        args.output = fasta_path.stem + "_tidk_results.tsv"

    if args.dry_run:
        cmd = ["tidk", "explore"]

        if args.length is not None:
            cmd.extend(["-l", str(args.length)])
        if args.minimum is not None:
            cmd.extend(["-m", str(args.minimum)])
        if args.maximum is not None:
            cmd.extend(["-x", str(args.maximum)])
        if args.threshold is not None:
            cmd.extend(["-t", str(args.threshold)])
        if args.distance is not None:
            cmd.extend(["--distance", str(args.distance)])
        if args.verbose:
            cmd.append("-v")
        if args.log:
            cmd.append("--log")

        cmd.append(args.fasta_file)

        print(f"Dry run - Command that would be executed: {' '.join(cmd)}")
        print(f"Output will be saved to: {args.output}")
        return

    # Run the actual command
    result = run_tidk_explore(
        fasta_file=args.fasta_file,
        length=args.length,
        minimum=args.minimum,
        maximum=args.maximum,
        threshold=args.threshold,
        distance=args.distance,
        verbose=args.verbose,
        log=args.log,
        output_file=args.output
    )

    print("STDOUT:")
    print(result.stdout)
    if result.stderr:
        print("STDERR:")
        print(result.stderr)


if __name__ == "__main__":
    main()