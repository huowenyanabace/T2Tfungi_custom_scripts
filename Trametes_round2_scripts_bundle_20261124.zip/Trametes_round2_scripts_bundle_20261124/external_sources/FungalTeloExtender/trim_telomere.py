#!/usr/bin/env python3
"""
TelomereTrimmer - 修剪延伸基因组，确保端粒motif在染色体最末端

该脚本用于处理FungalTeloExtender等端粒延伸工具产生的基因组，
去除端粒区域之后的亚端粒序列或其他非端粒序列，
确保端粒重复序列位于染色体的真正末端。

Author: Bioinformatics Helper
Version: 1.0.0
License: MIT
"""

import sys
import re
import argparse
import logging
from pathlib import Path
from collections import OrderedDict
from typing import Tuple, Optional, Dict, List
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

VERSION = "1.0.0"


def reverse_complement(seq: str) -> str:
    """
    返回DNA序列的反向互补序列
    
    Args:
        seq: 输入的DNA序列
        
    Returns:
        反向互补序列
    """
    complement = {
        'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G',
        'a': 't', 't': 'a', 'g': 'c', 'c': 'g',
        'N': 'N', 'n': 'n'
    }
    return ''.join(complement.get(base, 'N') for base in reversed(seq))


def normalize_motif(motif: str) -> str:
    """
    标准化motif（转为大写）
    
    Args:
        motif: 输入的端粒motif
        
    Returns:
        标准化后的motif
    """
    return motif.upper().strip()


def find_all_motif_positions(seq: str, motif: str) -> List[Tuple[int, int, str]]:
    """
    找到序列中所有motif出现的位置（包括正向和反向互补）
    
    Args:
        seq: 目标序列
        motif: 端粒motif
        
    Returns:
        列表，每个元素为(start, end, direction)元组
    """
    positions = []
    seq_upper = seq.upper()
    motif_upper = motif.upper()
    rc_motif = reverse_complement(motif_upper)
    
    # 搜索正向motif
    for match in re.finditer(re.escape(motif_upper), seq_upper):
        positions.append((match.start(), match.end(), 'forward'))
    
    # 搜索反向互补motif
    for match in re.finditer(re.escape(rc_motif), seq_upper):
        positions.append((match.start(), match.end(), 'reverse'))
    
    return sorted(positions, key=lambda x: x[0])


def find_telomere_boundary_5prime(seq: str, motif: str, window: int = 10000, 
                                   min_repeats: int = 3) -> Optional[int]:
    """
    从5'端找到端粒区域的边界（第一个端粒重复的起始位置）
    
    Args:
        seq: 染色体序列
        motif: 端粒motif
        window: 搜索窗口大小
        min_repeats: 最小重复次数阈值
        
    Returns:
        端粒区域起始位置，如果没找到返回None
    """
    check_seq = seq[:window]
    positions = find_all_motif_positions(check_seq, motif)
    
    if len(positions) < min_repeats:
        return None
    
    # 找到连续端粒区域的起始
    # 策略：从第一个motif开始，检查是否有足够的连续重复
    first_pos = positions[0][0]
    
    return first_pos


def find_telomere_boundary_3prime(seq: str, motif: str, window: int = 10000,
                                   min_repeats: int = 3) -> Optional[int]:
    """
    从3'端找到端粒区域的边界（最后一个端粒重复的结束位置）
    
    Args:
        seq: 染色体序列
        motif: 端粒motif
        window: 搜索窗口大小
        min_repeats: 最小重复次数阈值
        
    Returns:
        端粒区域结束位置，如果没找到返回None
    """
    check_seq = seq[-window:]
    positions = find_all_motif_positions(check_seq, motif)
    
    if len(positions) < min_repeats:
        return None
    
    # 找到最后一个motif的结束位置
    last_end = positions[-1][1]
    
    # 转换为全序列坐标
    actual_end = len(seq) - window + last_end
    
    return actual_end


def count_telomere_repeats(seq: str, motif: str) -> int:
    """
    统计序列中端粒重复的数量
    
    Args:
        seq: 目标序列
        motif: 端粒motif
        
    Returns:
        端粒重复数量
    """
    positions = find_all_motif_positions(seq, motif)
    return len(positions)


def trim_chromosome(seq: str, motif: str, window: int = 10000,
                    min_repeats: int = 3, trim_5prime: bool = True,
                    trim_3prime: bool = True) -> Tuple[str, dict]:
    """
    修剪染色体，使端粒序列位于最末端
    
    Args:
        seq: 染色体序列
        motif: 端粒motif
        window: 搜索窗口大小
        min_repeats: 最小重复次数阈值
        trim_5prime: 是否修剪5'端
        trim_3prime: 是否修剪3'端
        
    Returns:
        (修剪后的序列, 统计信息字典)
    """
    original_len = len(seq)
    trimmed_5prime = 0
    trimmed_3prime = 0
    
    # 修剪5'端
    if trim_5prime:
        boundary_5 = find_telomere_boundary_5prime(seq, motif, window, min_repeats)
        if boundary_5 is not None and boundary_5 > 0:
            trimmed_5prime = boundary_5
            seq = seq[boundary_5:]
    
    # 修剪3'端
    if trim_3prime:
        boundary_3 = find_telomere_boundary_3prime(seq, motif, window, min_repeats)
        if boundary_3 is not None and boundary_3 < len(seq):
            trimmed_3prime = len(seq) - boundary_3
            seq = seq[:boundary_3]
    
    stats = {
        'original_length': original_len,
        'trimmed_length': len(seq),
        'trimmed_5prime': trimmed_5prime,
        'trimmed_3prime': trimmed_3prime,
        'total_trimmed': trimmed_5prime + trimmed_3prime,
        'telomere_count_5prime': count_telomere_repeats(seq[:min(1000, len(seq))], motif),
        'telomere_count_3prime': count_telomere_repeats(seq[-min(1000, len(seq)):], motif)
    }
    
    return seq, stats


def parse_trim_config(config_file: str) -> Dict[str, Dict[str, bool]]:
    """
    解析端粒修剪配置文件
    
    Args:
        config_file: 配置文件路径（格式：Chromosome\tTerminus）
        
    Returns:
        字典，键为染色体名，值为{'trim_5prime': bool, 'trim_3prime': bool}
    """
    config = {}
    
    with open(config_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
                
            parts = line.split('\t')
            if len(parts) < 2:
                continue
            
            chrom = parts[0].strip()
            terminus = parts[1].strip().lower()
            
            # 初始化染色体配置
            if chrom not in config:
                config[chrom] = {'trim_5prime': False, 'trim_3prime': False}
            
            # 设置修剪选项
            if terminus == '5prime':
                config[chrom]['trim_5prime'] = True
            elif terminus == '3prime':
                config[chrom]['trim_3prime'] = True
    
    return config


def parse_fasta(filepath: str) -> OrderedDict:
    """
    解析FASTA文件
    
    Args:
        filepath: FASTA文件路径
        
    Returns:
        OrderedDict，键为序列名，值为序列
    """
    sequences = OrderedDict()
    current_name = None
    current_seq = []
    
    # 支持gzip压缩文件
    import gzip
    
    open_func = gzip.open if filepath.endswith('.gz') else open
    mode = 'rt' if filepath.endswith('.gz') else 'r'
    
    with open_func(filepath, mode) as f:
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if current_name:
                    sequences[current_name] = ''.join(current_seq)
                current_name = line[1:].split()[0]
                current_seq = []
            else:
                current_seq.append(line)
        if current_name:
            sequences[current_name] = ''.join(current_seq)
    
    return sequences


def write_fasta(sequences: Dict[str, str], filepath: str, line_width: int = 80):
    """
    写入FASTA文件
    
    Args:
        sequences: 序列字典
        filepath: 输出文件路径
        line_width: 每行字符数
    """
    with open(filepath, 'w') as f:
        for name, seq in sequences.items():
            f.write(f">{name}\n")
            for i in range(0, len(seq), line_width):
                f.write(seq[i:i+line_width] + "\n")


def process_genome(input_fasta: str, output_fasta: str, motif: str,
                   window: int = 10000, min_repeats: int = 3,
                   trim_5prime: bool = True, trim_3prime: bool = True,
                   report_file: str = None, config_file: str = None) -> Dict:
    """
    处理整个基因组文件
    
    Args:
        input_fasta: 输入FASTA文件路径
        output_fasta: 输出FASTA文件路径
        motif: 端粒motif
        window: 搜索窗口大小
        min_repeats: 最小重复次数阈值
        trim_5prime: 是否修剪5'端（全局设置，可被配置文件覆盖）
        trim_3prime: 是否修剪3'端（全局设置，可被配置文件覆盖）
        report_file: 报告文件路径（可选）
        config_file: 配置文件路径（可选，指定每条染色体的修剪策略）
        
    Returns:
        处理统计信息
    """
    logger.info(f"读取输入文件: {input_fasta}")
    sequences = parse_fasta(input_fasta)
    logger.info(f"共读取 {len(sequences)} 条染色体/contig")
    
    # 读取配置文件（如果提供）
    trim_config = None
    if config_file:
        logger.info(f"读取配置文件: {config_file}")
        trim_config = parse_trim_config(config_file)
        logger.info(f"配置文件中指定了 {len(trim_config)} 条染色体的修剪策略")
    
    motif = normalize_motif(motif)
    rc_motif = reverse_complement(motif)
    logger.info(f"端粒motif: {motif} (反向互补: {rc_motif})")
    
    trimmed_sequences = OrderedDict()
    all_stats = []
    total_trimmed = 0
    chromosomes_modified = 0
    
    for name, seq in sequences.items():
        # 确定该染色体的修剪策略
        if trim_config and name in trim_config:
            # 使用配置文件中的设置
            do_trim_5prime = trim_config[name]['trim_5prime']
            do_trim_3prime = trim_config[name]['trim_3prime']
            logger.debug(f"  {name}: 使用配置文件设置 (5':{do_trim_5prime}, 3':{do_trim_3prime})")
        else:
            # 使用全局设置
            do_trim_5prime = trim_5prime
            do_trim_3prime = trim_3prime
        
        trimmed_seq, stats = trim_chromosome(
            seq, motif, window, min_repeats, do_trim_5prime, do_trim_3prime
        )
        trimmed_sequences[name] = trimmed_seq
        stats['chromosome'] = name
        all_stats.append(stats)
        
        if stats['total_trimmed'] > 0:
            chromosomes_modified += 1
            total_trimmed += stats['total_trimmed']
            logger.info(
                f"  {name}: {stats['original_length']:,} -> {stats['trimmed_length']:,} bp "
                f"(5'端去除 {stats['trimmed_5prime']:,} bp, "
                f"3'端去除 {stats['trimmed_3prime']:,} bp)"
            )
        else:
            logger.info(f"  {name}: 无需修剪 ({stats['original_length']:,} bp)")
    
    # 写入输出文件
    logger.info(f"写入输出文件: {output_fasta}")
    write_fasta(trimmed_sequences, output_fasta)
    
    # 生成报告
    if report_file:
        if config_file:
            # 使用配置文件时，生成两份报告
            # 1. 简化报告（原始报告文件名）
            write_report(report_file, all_stats, motif, input_fasta, output_fasta, 
                         config_mode=True)
            logger.info(f"简化报告已保存: {report_file}")
            
            # 2. 详细报告（添加_detailed后缀）
            detailed_report = report_file.replace('.tsv', '_detailed.tsv')
            if not detailed_report.endswith('_detailed.tsv'):
                # 如果没有.tsv扩展名，添加到文件名末尾
                detailed_report = report_file + '_detailed.tsv'
            
            write_report(detailed_report, all_stats, motif, input_fasta, output_fasta, 
                         config_mode=False)
            logger.info(f"详细报告已保存: {detailed_report}")
        else:
            # 不使用配置文件时，只生成详细报告
            write_report(report_file, all_stats, motif, input_fasta, output_fasta, 
                         config_mode=False)
            logger.info(f"报告已保存: {report_file}")
    
    # 汇总统计
    summary = {
        'total_chromosomes': len(sequences),
        'chromosomes_modified': chromosomes_modified,
        'total_trimmed_bp': total_trimmed,
        'original_genome_size': sum(s['original_length'] for s in all_stats),
        'trimmed_genome_size': sum(s['trimmed_length'] for s in all_stats),
        'details': all_stats
    }
    
    logger.info(f"\n{'='*60}")
    logger.info("处理完成!")
    logger.info(f"  修改的染色体: {chromosomes_modified}/{len(sequences)}")
    logger.info(f"  总共去除: {total_trimmed:,} bp")
    logger.info(f"  基因组大小: {summary['original_genome_size']:,} -> {summary['trimmed_genome_size']:,} bp")
    
    return summary


def write_report(report_file: str, stats: List[dict], motif: str,
                 input_file: str, output_file: str, config_mode: bool = False):
    """
    写入TSV格式的详细报告
    
    Args:
        report_file: 报告文件路径
        stats: 统计信息列表
        motif: 端粒motif
        input_file: 输入文件路径
        output_file: 输出文件路径
        config_mode: 是否使用配置文件模式（简化输出）
    """
    with open(report_file, 'w') as f:
        # 写入头部信息
        f.write(f"# TelomereTrimmer Report v{VERSION}\n")
        f.write(f"# Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"# Input: {input_file}\n")
        f.write(f"# Output: {output_file}\n")
        f.write(f"# Motif: {motif} (RC: {reverse_complement(motif)})\n")
        f.write("#\n")
        
        if config_mode:
            # 配置文件模式：简化输出
            f.write('\t'.join(['Chromosome', 'Terminus', 'Trimmed_Length_bp']) + '\n')
            
            for s in stats:
                # 如果5'端有修剪，输出一行
                if s['trimmed_5prime'] > 0:
                    f.write(f"{s['chromosome']}\t5prime\t{s['trimmed_5prime']}\n")
                
                # 如果3'端有修剪，输出一行
                if s['trimmed_3prime'] > 0:
                    f.write(f"{s['chromosome']}\t3prime\t{s['trimmed_3prime']}\n")
        else:
            # 标准模式：详细输出
            headers = [
                'Chromosome', 'Original_Length', 'Trimmed_Length',
                'Trimmed_5prime', 'Trimmed_3prime', 'Total_Trimmed',
                'Telomere_Count_5prime', 'Telomere_Count_3prime'
            ]
            f.write('\t'.join(headers) + '\n')
            
            # 写入数据
            for s in stats:
                row = [
                    s['chromosome'],
                    str(s['original_length']),
                    str(s['trimmed_length']),
                    str(s['trimmed_5prime']),
                    str(s['trimmed_3prime']),
                    str(s['total_trimmed']),
                    str(s['telomere_count_5prime']),
                    str(s['telomere_count_3prime'])
                ]
                f.write('\t'.join(row) + '\n')


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description=f"TelomereTrimmer v{VERSION} - 修剪延伸基因组，确保端粒motif在染色体最末端",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 基本用法
  python trim_telomere.py -i extended_genome.fasta -o trimmed_genome.fasta -m AACCCT
  
  # 使用配置文件，为每条染色体指定修剪策略
  python trim_telomere.py -i genome.fasta -o output.fasta -m AACCCT -c AN_trim.txt
  
  # 只修剪3'端（全局设置）
  python trim_telomere.py -i genome.fasta -o output.fasta -m TTAGGG --no-trim-5prime
  
  # 使用更大的搜索窗口
  python trim_telomere.py -i genome.fasta -o output.fasta -m AACCCT -w 20000
  
  # 生成详细报告
  python trim_telomere.py -i genome.fasta -o output.fasta -m AACCCT -r report.tsv

配置文件格式 (AN_trim.txt):
  Chromosome    Terminus
  NT_166518.1   3prime
  NT_166523.1   5prime
  NT_166525.1   3prime
  NT_166525.1   5prime

常见端粒motif:
  TTAGGG  - 大多数丝状真菌 (Neurospora, Magnaporthe等)
  AACCCT  - TTAGGG的反向互补
  TTAGGC  - 曲霉属 (Aspergillus)
  TCTGGGTG - 白色念珠菌 (Candida albicans)
        """
    )
    
    # 必需参数
    required = parser.add_argument_group('必需参数')
    required.add_argument('-i', '--input', required=True,
                          help='输入FASTA文件（延伸后的基因组）')
    required.add_argument('-o', '--output', required=True,
                          help='输出FASTA文件（修剪后的基因组）')
    required.add_argument('-m', '--motif', required=True,
                          help='端粒重复序列motif (如: AACCCT, TTAGGG)')
    
    # 可选参数
    optional = parser.add_argument_group('可选参数')
    optional.add_argument('-c', '--config', default=None,
                          help='配置文件，指定每条染色体的修剪策略 (格式: Chromosome\\tTerminus)')
    optional.add_argument('-w', '--window', type=int, default=10000,
                          help='末端搜索窗口大小 (默认: 10000)')
    optional.add_argument('-n', '--min-repeats', type=int, default=3,
                          help='判定为端粒区域的最小重复次数 (默认: 3)')
    optional.add_argument('--no-trim-5prime', action='store_true',
                          help='不修剪5\'端 (当未使用配置文件时的全局设置)')
    optional.add_argument('--no-trim-3prime', action='store_true',
                          help='不修剪3\'端 (当未使用配置文件时的全局设置)')
    optional.add_argument('-r', '--report', default=None,
                          help='输出详细报告文件 (TSV格式)')
    optional.add_argument('-v', '--verbose', action='store_true',
                          help='显示详细调试信息')
    optional.add_argument('--version', action='version',
                          version=f'TelomereTrimmer v{VERSION}')
    
    args = parser.parse_args()
    
    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # 检查输入文件
    if not Path(args.input).exists():
        logger.error(f"输入文件不存在: {args.input}")
        sys.exit(1)
    
    # 检查配置文件
    if args.config and not Path(args.config).exists():
        logger.error(f"配置文件不存在: {args.config}")
        sys.exit(1)
    
    # 处理基因组
    try:
        process_genome(
            input_fasta=args.input,
            output_fasta=args.output,
            motif=args.motif,
            window=args.window,
            min_repeats=args.min_repeats,
            trim_5prime=not args.no_trim_5prime,
            trim_3prime=not args.no_trim_3prime,
            report_file=args.report,
            config_file=args.config
        )
    except Exception as e:
        logger.error(f"处理失败: {str(e)}")
        if args.verbose:
            import traceback
            logger.error(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()
