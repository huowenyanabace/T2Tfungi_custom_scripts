"""
FungalTeloExtender v1.0.3 - Fungal Genome Telomere Extension Tool
==================================================
Author: FungalTeloExtender Team
Version: 1.0.3
License: MIT
"""

import os
import sys
import argparse
import logging
import gzip
import subprocess
import shutil
import re
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Set, Generator
from pathlib import Path
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from enum import Enum

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Constants
# ============================================================================

VERSION = "1.0.3"


# Motif identification algorithm types
class MotifIdentifyMethod(Enum):
    ONT_READS = "ONT"  # TRF + reads terminus validation (v3.15 algorithm)
    GENOME = "genome"  # Genome terminus scanning (v3.14 algorithm)
    TIDK_EXPLORE = "tidk_explore"  # tidk explore external tool (v1.0.3 new)


# Motif source priority
class MotifSource(Enum):
    USER_PROVIDED = 1  # User provided (highest priority)
    ALGORITHM = 2  # Algorithm discovered (ONT or genome)
    KNOWN_DATABASE = 3  # Known database match
    DEFAULT = 4  # Default value (fallback)


# Known fungal telomere motif database
KNOWN_FUNGAL_TELOMERES = {
    "TTAGGG": ["Neurospora crassa", "Magnaporthe oryzae", "Most filamentous fungi"],
    "TTAGGC": ["Aspergillus fumigatus", "Aspergillus niger", "Aspergillus nidulans"],
    "TCTGGGTG": ["Candida albicans"],
    "GGTGTACGGATGTCTAACTTCTT": ["Candida glabrata"],
    "TGTGGG": ["Saccharomyces cerevisiae"],
    "TGTGTGG": ["Saccharomyces cerevisiae variant"],
    "TTAGTCAGGG": ["Yarrowia lipolytica"],
    "GGGTTA": ["Various yeasts"],
    "GGGTAA": ["Some Candida species"],
    "TTTAGGG": ["Plant-type, some fungi"],
    "AACCCT": ["Many fungi (reverse of TTAGGG)"],
}

# TRF parameter defaults
TRF_DEFAULTS = {
    'match': 2,
    'mismatch': 7,
    'delta': 7,
    'pm': 80,
    'pi': 10,
    'minscore': 50,
    'maxperiod': 10,
}

# tidk explore parameter defaults (v1.0.3 new)
TIDK_EXPLORE_DEFAULTS = {
    'length': None,  # Fixed length (mutually exclusive with minimum/maximum)
    'minimum': 5,  # Minimum repeat unit length
    'maximum': 12,  # Maximum repeat unit length
    'threshold': 100,  # Repeat position threshold
    'distance': 0.01,  # Chromosome terminus distance ratio
}

# Optimization parameters
OPTIMIZATION_PARAMS = {
    'max_extension_length': 190000,  # Maximum extension length to avoid subtelomere
    'min_telomere_density': 0.15,  # Minimum telomere density
    'overlap_kmer_size': 21,  # Overlap detection kmer size
    'telomere_flank_exclude': 2000,  # Telomere flank region to exclude during overlap detection
}

# Terminus replacement parameters
REPLACEMENT_PARAMS = {
    'max_overhang': 30,  # Maximum overhang to trigger replacement
    'min_motif_count': 10,  # Minimum telomere repeat count for replacement
    'min_support_reads': 1,  # Minimum supporting reads for replacement
    'min_identity': 0.85,  # Minimum overlap identity for replacement
    'min_overlap': 500,  # Minimum overlap length for replacement
}


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class TRFResult:
    """TRF detected tandem repeat result"""
    read_id: str
    start: int
    end: int
    period: int
    copy_number: float
    consensus_size: int
    percent_matches: float
    percent_indels: float
    score: int
    repeat_unit: str
    repeat_sequence: str


@dataclass
class TandemRepeatRead:
    """Read containing tandem repeats"""
    read_id: str
    sequence: str
    quality: Optional[str]
    trf_results: List[TRFResult]
    best_repeat_unit: str
    best_copy_number: float
    repeat_position: str

    @property
    def read_length(self) -> int:
        return len(self.sequence)


@dataclass
class ChromosomeEnd:
    """Chromosome terminus information"""
    chrom_name: str
    end_type: str
    end_sequence: str
    full_length: int
    extract_length: int

    @property
    def end_id(self) -> str:
        return f"{self.chrom_name}_{self.end_type}"


@dataclass
class OverlapRead:
    """Read overlapping with chromosome terminus"""
    read_id: str
    sequence: str
    quality: Optional[str]
    chrom_end: str
    overlap_start: int
    overlap_end: int
    overlap_length: int
    identity: float
    strand: str
    overhang_length: int
    overhang_seq: str
    has_telomere: bool = False
    telomere_count: int = 0


@dataclass
class TelomereMotif:
    """Telomere motif"""
    sequence: str
    reverse_complement: str
    count: int
    score: float
    source: str
    priority: int = 4  # Priority (1=highest)
    algorithm: str = ""  # Algorithm used
    supporting_evidence: Dict = field(default_factory=dict)


@dataclass
class TidkExploreParams:
    """tidk explore parameter configuration (v1.0.3 new)"""
    length: Optional[int] = None  # Fixed length (mutually exclusive with minimum/maximum)
    minimum: Optional[int] = 5  # Minimum repeat unit length
    maximum: Optional[int] = 12  # Maximum repeat unit length
    threshold: Optional[int] = 100  # Repeat position threshold
    distance: Optional[float] = 0.01  # Chromosome terminus distance ratio
    verbose: bool = False  # Verbose output
    log: bool = False  # Output log file


@dataclass
class TelomereRead:
    """Read containing telomere (for extension)"""
    read_id: str
    sequence: str
    quality: Optional[str]
    chrom_end: str
    motif: str
    motif_count: int
    telomere_position: str
    telomere_start: int
    telomere_end: int
    overhang_length: int
    overhang_seq: str
    overlap_length: int
    identity: float
    extension_score: float


@dataclass
class PreContig:
    """Locally assembled pre_contig"""
    contig_id: str
    sequence: str
    chrom_end: str
    source_reads: List[str]
    telomere_end: str
    length: int
    coverage: float


@dataclass
class TelomereContig:
    """Contig containing telomere motif"""
    contig_id: str
    sequence: str
    chrom_end: str
    motif: str
    motif_count: int
    motif_position: str
    telomere_start: int
    telomere_end: int
    telomere_length: int
    polished: bool = False


@dataclass
class ExtensionResult:
    """Telomere extension result"""
    chrom_name: str
    end_type: str
    original_length: int
    extension_length: int
    final_length: int
    extension_seq: str
    telomere_motif: str
    telomere_repeat_count: int
    supporting_reads: int
    quality_score: float
    method: str
    polished: bool = False


# ============================================================================
# Utility Functions
# ============================================================================

def reverse_complement(seq: str) -> str:
    """Return reverse complement of DNA sequence"""
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G',
                  'a': 't', 't': 'a', 'g': 'c', 'c': 'g',
                  'N': 'N', 'n': 'n'}
    return ''.join(complement.get(base, 'N') for base in reversed(seq))


def normalize_motif(motif: str) -> str:
    """Normalize motif to canonical form"""
    motif = motif.upper()
    rotations = [motif[i:] + motif[:i] for i in range(len(motif))]
    rc = reverse_complement(motif)
    rc_rotations = [rc[i:] + rc[:i] for i in range(len(rc))]
    return min(rotations + rc_rotations)


def hamming_distance(s1: str, s2: str) -> int:
    """Calculate Hamming distance between two equal-length strings"""
    return sum(c1.upper() != c2.upper() for c1, c2 in zip(s1, s2))


def open_file(filepath: str, mode: str = 'r'):
    """Open file, automatically handle gzip compression"""
    if filepath.endswith('.gz'):
        return gzip.open(filepath, mode + 't', encoding='utf-8')
    return open(filepath, mode, encoding='utf-8')


def run_command(cmd: List[str], check: bool = True,
                capture_output: bool = True,
                timeout: int = None,
                cwd: str = None) -> subprocess.CompletedProcess:
    """Run shell command"""
    logger.debug(f"Running: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, check=check, capture_output=capture_output,
                                text=True, timeout=timeout, cwd=cwd)
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {' '.join(cmd)}")
        logger.error(f"Error: {e.stderr}")
        raise
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out: {' '.join(cmd)}")
        raise


def check_dependencies() -> Dict[str, bool]:
    """Check dependency software"""
    required = {
        'minimap2': 'For read alignment',
        'samtools': 'For BAM processing',
    }
    optional = {
        'trf': 'Tandem Repeats Finder for repeat detection',
        'flye': 'For local assembly',
        'racon': 'For long-read polishing',
        'bcftools': 'For short-read polishing',
        'medaka': 'For ONT-specific polishing',
        'tidk': 'For tidk explore motif identification (v1.0.3)',
    }

    status = {}
    missing_required = []

    for tool, desc in required.items():
        available = shutil.which(tool) is not None
        status[tool] = available
        if not available:
            missing_required.append(f"{tool} ({desc})")

    if missing_required:
        logger.error("Missing required software:")
        for tool in missing_required:
            logger.error(f"  - {tool}")
        sys.exit(1)

    logger.info("Required software: All ready ✓")

    available_optional = []
    for tool in optional:
        if shutil.which(tool):
            status[tool] = True
            available_optional.append(tool)
        else:
            status[tool] = False

    if available_optional:
        logger.info(f"Optional software: {', '.join(available_optional)}")

    return status


def count_motif_occurrences(sequence: str, motif: str, max_mismatch: int = 1) -> Tuple[int, int, int]:
    """
    Count motif occurrences and positions in sequence
    Returns: (count, start_pos, end_pos)

    Note: This function checks both the motif and its reverse complement,
    but returns results for whichever gives a better match.
    """
    seq = sequence.upper()
    motif_upper = motif.upper()
    rc_motif = reverse_complement(motif_upper)
    motif_len = len(motif)

    best_count = 0
    best_start = 0
    best_end = 0

    for search_motif in [motif_upper, rc_motif]:
        for start in range(min(len(seq) - motif_len * 3, 2000)):
            count = 0
            pos = start

            while pos + motif_len <= len(seq):
                window = seq[pos:pos + motif_len]
                if hamming_distance(search_motif, window) <= max_mismatch:
                    count += 1
                    pos += motif_len
                else:
                    if count >= 2:
                        next_pos = pos + motif_len
                        if next_pos + motif_len <= len(seq):
                            next_window = seq[next_pos:next_pos + motif_len]
                            if hamming_distance(search_motif, next_window) <= max_mismatch:
                                pos = next_pos
                                continue
                    break

            if count > best_count:
                best_count = count
                best_start = start
                best_end = pos

    return best_count, best_start, best_end


def identify_motif_strand(sequence: str, motif: str, max_mismatch: int = 1) -> Tuple[str, int, int, int]:
    """
    Identify which strand's motif appears in sequence
    Returns: (strand_type, count, start_pos, end_pos)
    strand_type: 'forward', 'reverse_complement', or 'none'
    """
    seq = sequence.upper()
    motif_upper = motif.upper()
    rc_motif = reverse_complement(motif_upper)
    motif_len = len(motif)

    # Check forward motif
    forward_count = 0
    forward_start = 0
    forward_end = 0

    for start in range(min(len(seq) - motif_len * 3, 2000)):
        count = 0
        pos = start

        while pos + motif_len <= len(seq):
            window = seq[pos:pos + motif_len]
            if hamming_distance(motif_upper, window) <= max_mismatch:
                count += 1
                pos += motif_len
            else:
                if count >= 2:
                    next_pos = pos + motif_len
                    if next_pos + motif_len <= len(seq):
                        next_window = seq[next_pos:next_pos + motif_len]
                        if hamming_distance(motif_upper, next_window) <= max_mismatch:
                            pos = next_pos
                            continue
                break

        if count > forward_count:
            forward_count = count
            forward_start = start
            forward_end = pos

    # Check reverse complement motif
    rc_count = 0
    rc_start = 0
    rc_end = 0

    for start in range(min(len(seq) - motif_len * 3, 2000)):
        count = 0
        pos = start

        while pos + motif_len <= len(seq):
            window = seq[pos:pos + motif_len]
            if hamming_distance(rc_motif, window) <= max_mismatch:
                count += 1
                pos += motif_len
            else:
                if count >= 2:
                    next_pos = pos + motif_len
                    if next_pos + motif_len <= len(seq):
                        next_window = seq[next_pos:next_pos + motif_len]
                        if hamming_distance(rc_motif, next_window) <= max_mismatch:
                            pos = next_pos
                            continue
                break

        if count > rc_count:
            rc_count = count
            rc_start = start
            rc_end = pos

    # Return the one with higher count
    if forward_count >= rc_count and forward_count > 0:
        return 'forward', forward_count, forward_start, forward_end
    elif rc_count > 0:
        return 'reverse_complement', rc_count, rc_start, rc_end
    else:
        return 'none', 0, 0, 0


def count_motif_simple(sequence: str, motif: str) -> int:
    """Simple count of motif occurrences, including reverse complement"""
    seq = sequence.upper()
    motif_upper = motif.upper()
    rc_motif = reverse_complement(motif_upper)
    return seq.count(motif_upper) + seq.count(rc_motif)


def calculate_telomere_density(sequence: str, motif: str) -> float:
    """Calculate telomere density"""
    if not sequence:
        return 0.0
    count = count_motif_simple(sequence, motif)
    return (count * len(motif)) / len(sequence)


def count_motif_occurrences_specific(sequence: str, motif: str, max_mismatch: int = 1) -> Tuple[int, int, int]:
    """
    Count occurrences and positions of specified direction motif in sequence
    Only checks specified motif direction, not reverse complement
    Returns: (count, start_pos, end_pos)
    """
    seq = sequence.upper()
    motif_upper = motif.upper()
    motif_len = len(motif)

    best_count = 0
    best_start = 0
    best_end = 0

    # Check different regions of sequence to avoid redundant counting
    seq_len = len(seq)

    if seq_len <= 4000:
        # For short sequences, check entire sequence directly
        for start in range(0, max(1, seq_len - motif_len * 3)):
            count = 0
            pos = start

            while pos + motif_len <= len(seq):
                window = seq[pos:pos + motif_len]
                if hamming_distance(motif_upper, window) <= max_mismatch:
                    count += 1
                    pos += motif_len
                else:
                    if count >= 2:
                        next_pos = pos + motif_len
                        if next_pos + motif_len <= len(seq):
                            next_window = seq[next_pos:next_pos + motif_len]
                            if hamming_distance(motif_upper, next_window) <= max_mismatch:
                                pos = next_pos
                                continue
                    break

            if count > best_count:
                best_count = count
                best_start = start
                best_end = pos
    else:
        # For long sequences, check first 2000bp and last 2000bp separately (avoid overlap)
        # Check first 2000bp
        for start in range(0, min(2000 - motif_len * 3, 2000)):
            count = 0
            pos = start

            while pos + motif_len <= len(seq):
                window = seq[pos:pos + motif_len]
                if hamming_distance(motif_upper, window) <= max_mismatch:
                    count += 1
                    pos += motif_len
                else:
                    if count >= 2:
                        next_pos = pos + motif_len
                        if next_pos + motif_len <= len(seq):
                            next_window = seq[next_pos:next_pos + motif_len]
                            if hamming_distance(motif_upper, next_window) <= max_mismatch:
                                pos = next_pos
                                continue
                    break

            if count > best_count:
                best_count = count
                best_start = start
                best_end = pos

        # Check last 2000bp
        start_pos = max(0, seq_len - 2000)
        for start in range(start_pos, seq_len - motif_len * 3):
            count = 0
            pos = start

            while pos + motif_len <= len(seq):
                window = seq[pos:pos + motif_len]
                if hamming_distance(motif_upper, window) <= max_mismatch:
                    count += 1
                    pos += motif_len
                else:
                    if count >= 2:
                        next_pos = pos + motif_len
                        if next_pos + motif_len <= len(seq):
                            next_window = seq[next_pos:next_pos + motif_len]
                            if hamming_distance(motif_upper, next_window) <= max_mismatch:
                                pos = next_pos
                                continue
                    break

            if count > best_count:
                best_count = count
                best_start = start
                best_end = pos

    return best_count, best_start, best_end


def calculate_telomere_density_detailed(sequence: str, motif: str) -> Tuple[float, str]:
    """
    Calculate telomere density and identify main motif strand
    Returns: (density, strand_type)
    """
    if not sequence:
        return 0.0, 'none'

    strand_type, count, _, _ = identify_motif_strand(sequence, motif)
    density = (count * len(motif)) / len(sequence)
    return density, strand_type


def is_low_complexity(kmer: str) -> bool:
    """Check if kmer is low complexity sequence"""
    base_counts = Counter(kmer.upper())
    max_freq = max(base_counts.values()) / len(kmer)

    if max_freq > 0.6:
        return True

    for period in [2, 3, 4, 5, 6]:
        if len(kmer) >= period * 2:
            unit = kmer[:period]
            repeated = unit * (len(kmer) // period + 1)
            if repeated[:len(kmer)] == kmer:
                return True

    return False


# ============================================================================
# File Parsers
# ============================================================================

def parse_fasta(filepath: str) -> Dict[str, str]:
    """Parse FASTA file"""
    logger.info(f"Parsing FASTA file: {filepath}")
    sequences = {}
    current_header = None
    current_seq = []

    with open_file(filepath) as f:
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if current_header:
                    sequences[current_header] = ''.join(current_seq)
                current_header = line[1:].split()[0]
                current_seq = []
            elif line:
                current_seq.append(line.upper())
        if current_header:
            sequences[current_header] = ''.join(current_seq)

    logger.info(f"Loaded {len(sequences)} sequences")
    return sequences


def parse_fastq_streaming(filepath: str) -> Generator[Tuple[str, str, str], None, None]:
    """Stream parse FASTQ file"""
    with open_file(filepath) as f:
        while True:
            header = f.readline().strip()
            if not header:
                break
            if not header.startswith('@'):
                continue
            seq = f.readline().strip().upper()
            f.readline()
            qual = f.readline().strip()
            read_id = header[1:].split()[0]
            yield read_id, seq, qual


def write_fasta(sequences: Dict[str, str], filepath: str, line_width: int = 80):
    """Write FASTA file"""
    with open(filepath, 'w') as f:
        for name, seq in sequences.items():
            f.write(f">{name}\n")
            for i in range(0, len(seq), line_width):
                f.write(seq[i:i + line_width] + "\n")


def write_fastq(reads: List[Tuple[str, str, str]], filepath: str):
    """Write FASTQ file"""
    with open(filepath, 'w') as f:
        for read_id, seq, qual in reads:
            if len(qual) != len(seq):
                qual = 'I' * len(seq)
            f.write(f"@{read_id}\n{seq}\n+\n{qual}\n")


# ============================================================================
# Step 1: TRF Tandem Repeat Screening (Optional)
# ============================================================================

class TRFScreener:
    """Screen reads containing tandem repeats using TRF"""

    def __init__(self,
                 min_period: int = 6,
                 max_period: int = 12,
                 min_copy_number: int = 10,
                 threads: int = 4,
                 work_dir: Path = None):
        self.min_period = min_period
        self.max_period = max_period
        self.min_copy_number = min_copy_number
        self.threads = threads
        self.work_dir = work_dir or Path(tempfile.mkdtemp())
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.has_trf = shutil.which('trf') is not None

    def screen_reads(self, reads_file: str,
                     batch_size: int = 1000) -> List[TandemRepeatRead]:
        """Screen reads containing tandem repeats"""
        if not self.has_trf:
            logger.info("Step 1: TRF not available, skipping tandem repeat screening")
            return []

        logger.info(f"Step 1: Screening tandem repeat reads using TRF")
        logger.info(f"  Parameters: repeat unit {self.min_period}-{self.max_period}bp, "
                    f"minimum repeats {self.min_copy_number}")

        tandem_reads = []
        batch_reads = []
        batch_num = 0
        total_processed = 0

        for read_id, seq, qual in parse_fastq_streaming(reads_file):
            batch_reads.append((read_id, seq, qual))
            total_processed += 1

            if len(batch_reads) >= batch_size:
                batch_num += 1
                results = self._process_batch(batch_reads, batch_num)
                tandem_reads.extend(results)
                batch_reads = []

                if batch_num % 10 == 0:
                    logger.info(f"  Processed {total_processed:,} reads, "
                                f"found {len(tandem_reads):,} tandem repeat reads")

        if batch_reads:
            batch_num += 1
            results = self._process_batch(batch_reads, batch_num)
            tandem_reads.extend(results)

        logger.info(f"  ✓ Complete: {total_processed:,} total reads, "
                    f"screened {len(tandem_reads):,} reads with tandem repeats")

        return tandem_reads

    def _process_batch(self, reads: List[Tuple[str, str, str]],
                       batch_num: int) -> List[TandemRepeatRead]:
        """Process a batch of reads"""
        batch_fasta = self.work_dir / f"batch_{batch_num}.fasta"

        read_dict = {}
        with open(batch_fasta, 'w') as f:
            for read_id, seq, qual in reads:
                f.write(f">{read_id}\n{seq}\n")
                read_dict[read_id] = (seq, qual)

        trf_results = self._run_trf(str(batch_fasta), batch_num)

        tandem_reads = []
        for read_id, results in trf_results.items():
            valid_results = [
                r for r in results
                if self.min_period <= r.period <= self.max_period
                   and r.copy_number >= self.min_copy_number
            ]

            if valid_results:
                seq, qual = read_dict[read_id]
                best = max(valid_results, key=lambda x: x.copy_number)
                position = self._determine_position(best, len(seq))

                tandem_reads.append(TandemRepeatRead(
                    read_id=read_id,
                    sequence=seq,
                    quality=qual,
                    trf_results=valid_results,
                    best_repeat_unit=best.repeat_unit,
                    best_copy_number=best.copy_number,
                    repeat_position=position
                ))

        self._cleanup_batch_files(batch_fasta)
        return tandem_reads

    def _run_trf(self, fasta_file: str, batch_num: int) -> Dict[str, List[TRFResult]]:
        """Run TRF and parse results"""
        trf_cmd = [
            'trf', fasta_file,
            str(TRF_DEFAULTS['match']),
            str(TRF_DEFAULTS['mismatch']),
            str(TRF_DEFAULTS['delta']),
            str(TRF_DEFAULTS['pm']),
            str(TRF_DEFAULTS['pi']),
            str(TRF_DEFAULTS['minscore']),
            str(self.max_period),
            '-d', '-h'
        ]

        try:
            subprocess.run(trf_cmd, capture_output=True, text=True,
                           timeout=300, cwd=str(self.work_dir))
        except subprocess.TimeoutExpired:
            logger.warning(f"TRF timed out (batch {batch_num})")
            return {}
        except Exception as e:
            logger.warning(f"TRF failed (batch {batch_num}): {e}")
            return {}

        dat_file = self._find_trf_output(fasta_file)
        if dat_file:
            return self._parse_trf_dat(dat_file)
        return {}

    def _find_trf_output(self, fasta_file: str) -> Optional[Path]:
        """Find TRF output dat file"""
        fasta_basename = Path(fasta_file).name
        expected_dat_name = (f"{fasta_basename}.{TRF_DEFAULTS['match']}."
                             f"{TRF_DEFAULTS['mismatch']}.{TRF_DEFAULTS['delta']}."
                             f"{TRF_DEFAULTS['pm']}.{TRF_DEFAULTS['pi']}."
                             f"{TRF_DEFAULTS['minscore']}.{self.max_period}.dat")

        possible_locations = [
            self.work_dir / expected_dat_name,
            Path(fasta_file).parent / expected_dat_name,
            Path.cwd() / expected_dat_name,
        ]

        for loc in possible_locations:
            if loc.exists():
                return loc

        search_dirs = [self.work_dir, Path(fasta_file).parent, Path.cwd()]
        for search_dir in search_dirs:
            dat_files = list(search_dir.glob(f"{fasta_basename}.*.dat"))
            if dat_files:
                return max(dat_files, key=lambda x: x.stat().st_mtime)

        all_dat_files = list(self.work_dir.glob("*.dat"))
        if all_dat_files:
            batch_dat_files = [f for f in all_dat_files if "batch" in f.name]
            if batch_dat_files:
                return max(batch_dat_files, key=lambda x: x.stat().st_mtime)

        return None

    def _parse_trf_dat(self, dat_file: Path) -> Dict[str, List[TRFResult]]:
        """Parse TRF dat output file"""
        results = defaultdict(list)
        current_read = None

        try:
            with open(dat_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    if line.startswith('Sequence:'):
                        parts = line.split(':', 1)
                        if len(parts) > 1:
                            current_read = parts[1].strip().split()[0]

                    elif line.startswith('Parameters:') or line.startswith('@'):
                        continue

                    elif current_read and line[0].isdigit():
                        parts = line.split()
                        if len(parts) >= 14:
                            try:
                                result = TRFResult(
                                    read_id=current_read,
                                    start=int(parts[0]),
                                    end=int(parts[1]),
                                    period=int(parts[2]),
                                    copy_number=float(parts[3]),
                                    consensus_size=int(parts[4]),
                                    percent_matches=float(parts[5]),
                                    percent_indels=float(parts[6]),
                                    score=int(float(parts[7])),
                                    repeat_unit=parts[13],
                                    repeat_sequence=parts[14] if len(parts) > 14 else ""
                                )
                                results[current_read].append(result)
                            except (ValueError, IndexError):
                                continue

        except Exception as e:
            logger.warning(f"Failed to parse TRF results: {e}")

        return dict(results)

    def _cleanup_batch_files(self, batch_fasta: Path):
        """Clean up batch temporary files"""
        try:
            if batch_fasta.exists():
                batch_fasta.unlink()

            fasta_basename = batch_fasta.name
            for pattern in [f"{fasta_basename}.*", f"{batch_fasta.stem}.*"]:
                for f in self.work_dir.glob(pattern):
                    try:
                        f.unlink()
                    except Exception:
                        pass
        except Exception:
            pass

    def _determine_position(self, trf_result: TRFResult, read_length: int) -> str:
        """Determine repeat sequence position in read"""
        start = trf_result.start
        end = trf_result.end
        dist_5prime = start
        dist_3prime = read_length - end
        threshold = min(500, read_length * 0.1)

        if dist_5prime <= threshold:
            return '5prime'
        elif dist_3prime <= threshold:
            return '3prime'
        else:
            return 'internal'


# ============================================================================
# tidk explore Runner (v1.0.3 new)
# ============================================================================

class TidkExploreRunner:
    """
    tidk explore command wrapper (v1.0.3 new)

    Used to call external tidk explore tool for telomere motif discovery
    """

    def __init__(self, work_dir: Path = None):
        """
        Initialize tidk explore runner

        Args:
            work_dir: Working directory for temporary files and output results
        """
        self.work_dir = work_dir or Path(tempfile.mkdtemp())
        self.work_dir = Path(self.work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def check_availability() -> bool:
        """Check if tidk is available"""
        return shutil.which('tidk') is not None

    def run_explore(self,
                    fasta_file: str,
                    params: 'TidkExploreParams' = None,
                    output_file: str = None) -> Tuple[bool, List[Dict]]:
        """
        Run tidk explore command

        Args:
            fasta_file: Input FASTA file path
            params: TidkExploreParams parameter object
            output_file: Output TSV file path (optional)

        Returns:
            Tuple[bool, List[Dict]]: (success, results list)
            Results list format: [{'canonical_repeat_unit': str, 'count': int}, ...]
        """
        if not self.check_availability():
            logger.warning("tidk not installed, cannot run tidk explore")
            return False, []

        if not os.path.isfile(fasta_file):
            logger.error(f"FASTA file does not exist: {fasta_file}")
            return False, []

        # Use default parameters
        if params is None:
            params = TidkExploreParams()

        # Build command
        cmd = ["tidk", "explore"]

        # Add parameters
        if params.length is not None:
            cmd.extend(["-l", str(params.length)])
        if params.minimum is not None:
            cmd.extend(["-m", str(params.minimum)])
        if params.maximum is not None:
            cmd.extend(["-x", str(params.maximum)])
        if params.threshold is not None:
            cmd.extend(["-t", str(params.threshold)])
        if params.distance is not None:
            cmd.extend(["--distance", str(params.distance)])
        if params.verbose:
            cmd.append("-v")
        if params.log:
            cmd.append("--log")

        # Add FASTA file
        cmd.append(fasta_file)

        # Ensure the working directory exists and create any required subdirectories
        self.work_dir.mkdir(parents=True, exist_ok=True)
        # Create motif subdirectory that might be expected by tidk
        motif_dir = self.work_dir / "motif"
        motif_dir.mkdir(exist_ok=True)

        logger.debug(f"Running tidk command: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=str(self.work_dir)
            )

            # Parse output
            results = self._parse_output(result.stdout)

            # Save results if output file specified
            if output_file and results:
                self._save_to_tsv(results, output_file)

            logger.info(f"tidk explore complete, found {len(results)} candidate motifs")
            return True, results

        except subprocess.CalledProcessError as e:
            logger.error(f"tidk explore execution failed: {e}")
            logger.error(f"Stderr: {e.stderr}")
            return False, []
        except Exception as e:
            logger.error(f"tidk explore execution error: {e}")
            return False, []

    def _parse_output(self, output_data: str) -> List[Dict]:
        """
        Parse tidk explore stdout output

        Args:
            output_data: tidk explore standard output

        Returns:
            List[Dict]: Parsed results list
        """
        results = []
        lines = output_data.strip().split('\n')

        for line in lines:
            line = line.strip()
            # Skip empty lines, comments, error messages and headers
            if not line or line.startswith('#') or line.startswith('Error'):
                continue
            if line.startswith('canonical_repeat_unit'):
                continue

            # Parse data line (format: repeat_unit<tab or space>count)
            fields = line.split()
            if len(fields) >= 2:
                try:
                    repeat_unit = fields[0]
                    count = int(fields[1])
                    results.append({
                        'canonical_repeat_unit': repeat_unit,
                        'count': count
                    })
                except (ValueError, IndexError) as e:
                    logger.debug(f"Skipping unparseable line: {line}, error: {e}")
                    continue

        # Sort by count descending
        results.sort(key=lambda x: x['count'], reverse=True)
        return results

    def _save_to_tsv(self, results: List[Dict], output_file: str):
        """
        Save results to TSV file

        Args:
            results: Results list
            output_file: Output file path
        """
        try:
            with open(output_file, 'w') as f:
                f.write("canonical_repeat_unit\tcount\n")
                for r in results:
                    f.write(f"{r['canonical_repeat_unit']}\t{r['count']}\n")
            logger.debug(f"tidk results saved: {output_file}")
        except Exception as e:
            logger.warning(f"Failed to save tidk results: {e}")


# ============================================================================
# Step 2: Telomere Motif Identification - Three Algorithm Support (v1.0.3 update)
# ============================================================================

class MotifIdentifier:
    """
    Telomere motif identifier - supports three algorithms (v1.0.3 update)

    Priority order:
        1. User provided motif (highest priority)
        2. Core algorithm (choose one of three):
           - ONT: TRF discovery from reads + reads terminus frequency validation
           - genome: Genome terminus tandem repeat scanning
           - tidk_explore: Call external tidk explore tool (v1.0.3 new)
        3. Known database scanning (fallback)
        4. Default motif TTAGGG (last resort)
    """

    def __init__(self,
                 min_period: int = 6,
                 max_period: int = 12,
                 min_repeat_count: int = 10,
                 end_region_size: int = 10000,
                 terminus_check_size: int = 300,
                 identify_method: MotifIdentifyMethod = MotifIdentifyMethod.ONT_READS,
                 tidk_params: TidkExploreParams = None,
                 work_dir: Path = None):
        """
        Parameters:
            min_period: Minimum repeat unit length
            max_period: Maximum repeat unit length
            min_repeat_count: Minimum consecutive repeat count
            end_region_size: Chromosome terminus scanning region size
            terminus_check_size: Reads terminus validation region size
            identify_method: Identification algorithm selection (ONT_READS, GENOME or TIDK_EXPLORE)
            tidk_params: tidk explore parameter configuration (v1.0.3 new)
            work_dir: Working directory (v1.0.3 new, for tidk temporary files)
        """
        self.min_period = min_period
        self.max_period = max_period
        self.min_repeat_count = min_repeat_count
        self.end_region_size = end_region_size
        self.terminus_check_size = terminus_check_size
        self.identify_method = identify_method
        self.tidk_params = tidk_params or TidkExploreParams()
        self.work_dir = Path(work_dir) if work_dir else Path(tempfile.mkdtemp())
        self.work_dir.mkdir(parents=True, exist_ok=True)

    def identify(self,
                 chromosomes: Dict[str, str],
                 tandem_reads: List[TandemRepeatRead] = None,
                 provided_motif: str = None,
                 reads_file: str = None,
                 genome_file: str = None) -> List[TelomereMotif]:
        """
        Identify telomere motif by priority

        Args:
            chromosomes: Chromosome sequence dictionary
            tandem_reads: TRF identified tandem repeat reads list
            provided_motif: User provided motif sequence
            reads_file: Reads file path
            genome_file: Genome file path (needed for tidk explore)

        Returns sorted motif list (by priority and confidence)
        """
        logger.info("Step 2: Telomere Motif Identification")
        logger.info(f"  Algorithm selection: {self.identify_method.value}")
        logger.info("  Priority: User specified > Core algorithm > Known database > Default")
        logger.info("=" * 60)

        final_motifs = []

        # ============================================
        # Priority 1: User provided motif (highest priority)
        # ============================================
        if provided_motif:
            logger.info(f"  [Priority 1] User provided motif: {provided_motif}")
            motif_upper = provided_motif.upper()

            # Validate user motif presence at genome termini
            validation_count = self._validate_in_genome_ends(chromosomes, motif_upper)
            logger.info(f"    → Genome terminus validation: detected {validation_count} occurrences")

            final_motifs.append(TelomereMotif(
                sequence=motif_upper,
                reverse_complement=reverse_complement(motif_upper),
                count=validation_count,
                score=1.0,
                source='user_provided',
                priority=1,
                algorithm='user',
                supporting_evidence={'user_provided': True, 'genome_validation': validation_count}
            ))

            logger.info(f"  ✓ Using user provided motif: {motif_upper}")
            return final_motifs

        # ============================================
        # Priority 2: Core algorithm
        # ============================================
        algorithm_motifs = []

        if self.identify_method == MotifIdentifyMethod.ONT_READS:
            # ONT algorithm: TRF discovery from reads + reads terminus frequency validation
            algorithm_motifs = self._identify_with_ont(tandem_reads)
        elif self.identify_method == MotifIdentifyMethod.TIDK_EXPLORE:
            # tidk explore algorithm: Call external tidk explore tool (v1.0.3 new)
            algorithm_motifs = self._identify_with_tidk_explore(genome_file, chromosomes)
        else:
            # Genome algorithm: Genome terminus tandem repeat scanning
            algorithm_motifs = self._identify_with_genome(chromosomes)

        # ============================================
        # Priority 3: Known database scanning (fallback)
        # ============================================
        logger.info(f"  [Priority 3] Known fungal telomere database scanning")
        database_motifs = self._scan_known_database(chromosomes)

        if database_motifs:
            logger.info(f"    → Database matched {len(database_motifs)} known motifs")
            for dm in database_motifs[:3]:
                species = dm.supporting_evidence.get('species', ['Unknown'])
                logger.info(f"      - {dm.sequence}: {dm.count} occurrences, species={species[0]}")

        # ============================================
        # Comprehensive sorting and selection
        # ============================================
        logger.info("  [Comprehensive evaluation] Sorting by priority and confidence...")

        # Merge all candidates (grouped by priority)
        all_candidates = []

        # Priority 2 results
        all_candidates.extend(algorithm_motifs)

        # Priority 3 results (avoid duplicates)
        alg_motif_set = {m.sequence for m in algorithm_motifs}
        for dm in database_motifs:
            norm_dm = normalize_motif(dm.sequence)
            if not any(normalize_motif(m) == norm_dm for m in alg_motif_set):
                all_candidates.append(dm)

        # Sort by priority, then by score
        all_candidates.sort(key=lambda x: (x.priority, -x.score))

        if all_candidates:
            final_motifs = all_candidates
            best = final_motifs[0]
            logger.info(f"  ✓ Selected best motif: {best.sequence} "
                        f"(priority={best.priority}, source={best.source}, score={best.score:.2f})")
        else:
            # ============================================
            # Priority 4: Default motif (last resort)
            # ============================================
            logger.info(f"  [Priority 4] Using default motif TTAGGG (last resort)")
            final_motifs = [TelomereMotif(
                sequence="TTAGGG",
                reverse_complement="CCCTAA",
                count=0,
                score=0.5,
                source='default',
                priority=4,
                algorithm='default',
                supporting_evidence={'default': True}
            )]

        # Output final results
        logger.info("=" * 60)
        logger.info(f"  ✓ Identified {len(final_motifs)} candidate motifs:")
        for i, m in enumerate(final_motifs[:5], 1):
            logger.info(f"    {i}. {m.sequence} (RC: {m.reverse_complement}) "
                        f"- priority={m.priority}, score={m.score:.4f}, source={m.source}")

        return final_motifs

    def _identify_with_ont(self, tandem_reads: List[TandemRepeatRead]) -> List[TelomereMotif]:
        """
        ONT algorithm: TRF discovery from reads + reads terminus frequency validation

        Optimization strategy:
        1. Limit candidate motif count - only validate top 50 with highest TRF occurrence
        2. Traverse all reads for validation
        3. Early stop strategy - stop early when sufficient validation is reached
        4. Simplified counting - use faster string matching
        """
        logger.info(f"  [Priority 2] ONT algorithm: TRF discovery + reads terminus validation")

        if not tandem_reads:
            logger.info("    → No tandem reads, skipping ONT algorithm")
            return []

        logger.info(f"    → Input: {len(tandem_reads)} tandem reads")

        # 2a: Collect candidate motifs from TRF results
        trf_candidates = self._collect_from_trf(tandem_reads)
        logger.info(f"    → TRF discovered {len(trf_candidates)} candidate motifs")

        if not trf_candidates:
            return []

        # 2b: Validate frequency at reads terminus
        validated = self._validate_in_reads_terminus(tandem_reads, trf_candidates)
        logger.info(f"    → {len(validated)} motifs retained after reads terminus validation")

        ont_motifs = []
        for motif, evidence in validated.items():
            if evidence['terminus_count'] >= 3:  # At least 3 reads terminus validation
                ont_motifs.append(TelomereMotif(
                    sequence=motif,
                    reverse_complement=reverse_complement(motif),
                    count=evidence['total_count'],
                    score=evidence['score'],
                    source='ont_validated',
                    priority=2,
                    algorithm='ONT',
                    supporting_evidence=evidence
                ))

        # Sort by score
        ont_motifs.sort(key=lambda x: x.score, reverse=True)

        if ont_motifs:
            best = ont_motifs[0]
            logger.info(f"    ✓ Best ONT validated motif: {best.sequence} "
                        f"(terminus_count={best.supporting_evidence['terminus_count']}, "
                        f"score={best.score:.0f})")

        return ont_motifs

    def _identify_with_genome(self, chromosomes: Dict[str, str]) -> List[TelomereMotif]:
        """
        Genome algorithm: Genome terminus tandem repeat scanning (consistent with tidk explorer core algorithm)

        Algorithm flow:
        1. Extract 5' and 3' terminus sequences of each chromosome
        2. For each possible repeat unit length k (min_period ~ max_period)
        3. Traverse each position in sequence, detect consecutive repeats
        4. Only keep motifs with consecutive repeats >= min_repeat_count
        5. Count total frequency of each motif at all chromosome termini
        6. Return candidate motif list sorted by frequency
        """
        logger.info(f"  [Priority 2] Genome algorithm: Genome terminus tandem repeat scanning (tidk explore style)")
        logger.info(f"    Parameters: repeat unit length={self.min_period}-{self.max_period}bp, "
                    f"minimum repeats={self.min_repeat_count}, "
                    f"terminus region={self.end_region_size}bp")

        # Scan tandem repeats from genome termini
        motif_stats = self._explore_genome_termini(chromosomes)

        if not motif_stats:
            logger.warning("    → Failed to discover telomere motif from genome")
            return []

        # Build and sort results
        genome_motifs = self._build_genome_motif_list(motif_stats)

        logger.info(f"    → Discovered {len(genome_motifs)} candidate motifs")
        for i, m in enumerate(genome_motifs[:3], 1):
            logger.info(f"      {i}. {m.sequence}: frequency={m.count}, score={m.score:.4f}")

        return genome_motifs

    def _identify_with_tidk_explore(self, genome_file: str, chromosomes: Dict[str, str]) -> List[TelomereMotif]:
        """
        tidk explore algorithm: Call external tidk explore tool (v1.0.3 new)

        Algorithm flow:
        1. Check if tidk is available, fall back to genome algorithm if not
        2. Call tidk explore command to process genome file
        3. Parse tidk output results (TSV format: canonical_repeat_unit, count)
        4. Convert results to TelomereMotif objects
        5. Validate discovered motifs at genome termini

        Args:
            genome_file: Genome FASTA file path
            chromosomes: Chromosome sequence dictionary (for validation and fallback)

        Returns:
            List[TelomereMotif]: Motif candidate list
        """
        logger.info(f"  [Priority 2] tidk explore algorithm: Call external tidk explore tool")

        # Check if tidk is available
        if not TidkExploreRunner.check_availability():
            logger.warning("    → tidk not installed, falling back to genome algorithm")
            return self._identify_with_genome(chromosomes)

        # Check genome file
        if not genome_file or not os.path.isfile(genome_file):
            logger.warning(f"    → Genome file not available: {genome_file}, falling back to genome algorithm")
            return self._identify_with_genome(chromosomes)

        # Display tidk parameters
        logger.info(f"    Parameters: minimum={self.tidk_params.minimum}, "
                    f"maximum={self.tidk_params.maximum}, "
                    f"threshold={self.tidk_params.threshold}, "
                    f"distance={self.tidk_params.distance}")

        # Create tidk runner and execute
        runner = TidkExploreRunner(work_dir=self.work_dir)

        # Set output file
        output_file = self.work_dir / "tidk_explore_results.tsv"

        success, results = runner.run_explore(
            fasta_file=genome_file,
            params=self.tidk_params,
            output_file=str(output_file)
        )

        if not success or not results:
            logger.warning("    → tidk explore execution failed or no results, falling back to genome algorithm")
            return self._identify_with_genome(chromosomes)

        # Convert results to TelomereMotif objects
        tidk_motifs = []
        max_count = results[0]['count'] if results else 1  # For score normalization

        for r in results[:10]:  # Only take top 10 candidates
            motif_seq = r['canonical_repeat_unit'].upper()
            count = r['count']

            # Validate this motif at genome termini
            validation_count = self._validate_in_genome_ends(chromosomes, motif_seq)

            tidk_motifs.append(TelomereMotif(
                sequence=motif_seq,
                reverse_complement=reverse_complement(motif_seq),
                count=count,
                score=count / max_count * 100,  # Normalize to 100 scale
                source='tidk_explore',
                priority=2,
                algorithm='tidk_explore',
                supporting_evidence={
                    'tidk_count': count,
                    'genome_validation': validation_count,
                    'tidk_params': {
                        'minimum': self.tidk_params.minimum,
                        'maximum': self.tidk_params.maximum,
                        'threshold': self.tidk_params.threshold,
                        'distance': self.tidk_params.distance
                    }
                }
            ))

        # Sort by score
        tidk_motifs.sort(key=lambda x: x.score, reverse=True)

        logger.info(f"    → Discovered {len(tidk_motifs)} candidate motifs")
        for i, m in enumerate(tidk_motifs[:3], 1):
            logger.info(f"      {i}. {m.sequence}: tidk_count={m.count}, "
                        f"genome_validation={m.supporting_evidence['genome_validation']}, "
                        f"score={m.score:.4f}")

        if tidk_motifs:
            best = tidk_motifs[0]
            logger.info(f"    ✓ Best tidk motif: {best.sequence} "
                        f"(count={best.count}, score={best.score:.2f})")

        return tidk_motifs

    def _collect_from_trf(self, tandem_reads: List[TandemRepeatRead]) -> Dict[str, Dict]:
        """Collect candidate motifs from TRF results"""
        motif_counts = defaultdict(lambda: {
            'count': 0,
            'copy_numbers': [],
            'positions': [],
            'read_ids': []
        })

        for tr in tandem_reads:
            for trf in tr.trf_results:
                if self.min_period <= trf.period <= self.max_period:
                    norm_motif = normalize_motif(trf.repeat_unit)
                    motif_counts[norm_motif]['count'] += 1
                    motif_counts[norm_motif]['copy_numbers'].append(trf.copy_number)
                    motif_counts[norm_motif]['positions'].append(tr.repeat_position)
                    motif_counts[norm_motif]['read_ids'].append(tr.read_id)

        return dict(motif_counts)

    def _validate_in_reads_terminus(self, tandem_reads: List[TandemRepeatRead],
                                    trf_candidates: Dict[str, Dict],
                                    max_candidates: int = 50) -> Dict[str, Dict]:
        """
        Validate motif frequency at reads terminus

        v1.0.2 modification: Only sort and score by terminus_count, not using TRF count and high copy number

        Optimization strategy (ensure accuracy):
        1. Only validate top max_candidates with highest TRF occurrence (default 50)
        2. Traverse all tandem reads (no sampling)
        3. Use exact counting method
        4. [Modified] Only sort and score by terminus_count
        """
        validated = {}

        # Sort by TRF occurrence count, only take top max_candidates for validation
        sorted_candidates = sorted(
            trf_candidates.items(),
            key=lambda x: x[1]['count'],
            reverse=True
        )[:max_candidates]

        actual_candidates = len(sorted_candidates)
        total_reads = len(tandem_reads)
        logger.info(
            f"    → Optimization: Selected top {actual_candidates} with highest TRF count from {len(trf_candidates)} candidates for validation")
        logger.info(f"    → Traversing all {total_reads} tandem reads")

        for idx, (motif, trf_evidence) in enumerate(sorted_candidates):
            # Count occurrences of this motif at reads terminus
            terminus_count = 0

            # Traverse all tandem reads
            for tr in tandem_reads:
                seq = tr.sequence

                # Use exact counting method
                count_5, _, _ = count_motif_occurrences(
                    seq[:self.terminus_check_size], motif, max_mismatch=1
                )
                count_3, _, _ = count_motif_occurrences(
                    seq[-self.terminus_check_size:], motif, max_mismatch=1
                )

                if count_5 >= 3 or count_3 >= 3:
                    terminus_count += 1

            # [Modified] Only use terminus_count as score, not using TRF and high copy scoring
            total_score = float(terminus_count)

            # Only keep validated motifs
            if terminus_count >= 2:  # At least 2 reads validated at terminus
                validated[motif] = {
                    'total_count': trf_evidence['count'],
                    'terminus_count': terminus_count,
                    'score': total_score,
                    'trf_evidence': trf_evidence
                }

            # Output progress every 10 candidates processed
            if (idx + 1) % 10 == 0 or (idx + 1) == actual_candidates:
                logger.info(f"    → Validation progress: {idx + 1}/{actual_candidates} candidates complete, "
                            f"current motif: {motif}, terminus_count={terminus_count}")

        return validated

    def _explore_genome_termini(self, chromosomes: Dict[str, str]) -> Dict[str, Dict]:
        """
        Scan tandem repeat sequences from genome termini (tidk explore core logic)
        """
        # Store statistics for each motif
        motif_stats = defaultdict(lambda: {
            'terminus_total_count': 0,  # Total repeat count at all termini
            'terminus_chrom_count': 0,  # Number of chromosome termini where it appears
            'terminus_at_edge': 0,  # Count at the very edge 100bp
            'max_tandem_length': 0  # Longest consecutive tandem length
        })

        for chrom_name, seq in chromosomes.items():
            seq_upper = seq.upper()

            # Scan 5' terminus
            end_5 = seq_upper[:self.end_region_size]
            self._scan_tandem_repeats(end_5, motif_stats, is_5prime=True)

            # Scan 3' terminus
            end_3 = seq_upper[-self.end_region_size:]
            self._scan_tandem_repeats(end_3, motif_stats, is_5prime=False)

        # Filter: Only keep motifs with total frequency >= min_repeat_count
        result = {}
        for motif, stats in motif_stats.items():
            if stats['terminus_total_count'] >= self.min_repeat_count:
                result[motif] = stats
                logger.debug(f"    Discovered: {motif}, total frequency={stats['terminus_total_count']}, "
                             f"chromosome count={stats['terminus_chrom_count']}")

        return result

    def _scan_tandem_repeats(self, sequence: str, motif_stats: Dict, is_5prime: bool):
        """
        Scan tandem repeat sequences in sequence (tidk explore core logic)
        """
        seq_len = len(sequence)
        found_in_this_region = set()

        # For each possible repeat unit length
        for k in range(self.min_period, self.max_period + 1):
            i = 0
            while i <= seq_len - k * self.min_repeat_count:
                unit = sequence[i:i + k]

                # Skip sequences containing N or low complexity
                if 'N' in unit or self._is_low_complexity_genome(unit):
                    i += 1
                    continue

                # Count consecutive repeats of unit starting from position i
                repeat_count = 1
                j = i + k
                while j + k <= seq_len and sequence[j:j + k] == unit:
                    repeat_count += 1
                    j += k

                # If repeat count is sufficient
                if repeat_count >= self.min_repeat_count:
                    # Normalize motif
                    norm_unit = normalize_motif(unit)

                    # Update statistics
                    motif_stats[norm_unit]['terminus_total_count'] += repeat_count

                    # Record longest tandem length
                    tandem_length = repeat_count * k
                    if tandem_length > motif_stats[norm_unit]['max_tandem_length']:
                        motif_stats[norm_unit]['max_tandem_length'] = tandem_length

                    found_in_this_region.add(norm_unit)

                    # Check if at the very edge 100bp
                    if is_5prime and i < 100:
                        motif_stats[norm_unit]['terminus_at_edge'] += 1
                    elif not is_5prime and i > seq_len - 100 - k * repeat_count:
                        motif_stats[norm_unit]['terminus_at_edge'] += 1

                    # Skip scanned tandem region to avoid redundant counting
                    i = j
                else:
                    i += 1

        # Update chromosome terminus count
        for motif in found_in_this_region:
            motif_stats[motif]['terminus_chrom_count'] += 1

    def _is_low_complexity_genome(self, unit: str) -> bool:
        """Detect if sequence is low complexity"""
        if len(unit) < 2:
            return True

        base_counts = Counter(unit)
        max_count = max(base_counts.values())
        if max_count / len(unit) > 0.8:
            return True

        if len(base_counts) == 1:
            return True

        return False

    def _build_genome_motif_list(self, motif_stats: Dict[str, Dict]) -> List[TelomereMotif]:
        """Build genome algorithm motif list"""
        # Sort by frequency
        sorted_motifs = sorted(
            motif_stats.items(),
            key=lambda x: x[1]['terminus_total_count'],
            reverse=True
        )

        if not sorted_motifs:
            return []

        # Calculate max frequency for normalization
        max_count = sorted_motifs[0][1]['terminus_total_count']

        result = []
        for motif, stats in sorted_motifs[:10]:
            count = stats['terminus_total_count']
            if count == 0:
                continue

            result.append(TelomereMotif(
                sequence=motif,
                reverse_complement=reverse_complement(motif),
                count=count,
                score=count / max_count * 100,  # Normalize to 100 scale
                source='genome_explore',
                priority=2,
                algorithm='genome',
                supporting_evidence={
                    'terminus_chrom_count': stats['terminus_chrom_count'],
                    'terminus_at_edge': stats['terminus_at_edge'],
                    'max_tandem_length': stats['max_tandem_length']
                }
            ))

        return result

    def _validate_in_genome_ends(self, chromosomes: Dict[str, str], motif: str) -> int:
        """Validate motif occurrence count at genome termini"""
        total_count = 0
        motif_upper = motif.upper()
        rc_motif = reverse_complement(motif_upper)

        for chrom_name, seq in chromosomes.items():
            # Check 5' terminus
            end_5 = seq[:self.end_region_size].upper()
            total_count += end_5.count(motif_upper) + end_5.count(rc_motif)

            # Check 3' terminus
            end_3 = seq[-self.end_region_size:].upper()
            total_count += end_3.count(motif_upper) + end_3.count(rc_motif)

        return total_count

    def _scan_known_database(self, chromosomes: Dict[str, str]) -> List[TelomereMotif]:
        """Scan known fungal telomere database"""
        motif_hits = []

        for known_motif, species in KNOWN_FUNGAL_TELOMERES.items():
            count = 0
            terminus_hits = 0

            for chrom_name, seq in chromosomes.items():
                # Check terminus regions
                end_5 = seq[:self.end_region_size].upper()
                end_3 = seq[-self.end_region_size:].upper()

                rc_motif = reverse_complement(known_motif)

                count += end_5.count(known_motif) + end_5.count(rc_motif)
                count += end_3.count(known_motif) + end_3.count(rc_motif)

                # Check very terminus (higher weight)
                terminus_5 = seq[:200].upper()
                terminus_3 = seq[-200:].upper()

                if known_motif in terminus_5 or rc_motif in terminus_5:
                    terminus_hits += 1
                if known_motif in terminus_3 or rc_motif in terminus_3:
                    terminus_hits += 1

            if count >= 5 or terminus_hits >= 1:
                # Calculate score
                score = count * 0.5 + terminus_hits * 20

                motif_hits.append(TelomereMotif(
                    sequence=known_motif,
                    reverse_complement=reverse_complement(known_motif),
                    count=count,
                    score=score,
                    source='known_database',
                    priority=3,
                    algorithm='database',
                    supporting_evidence={
                        'species': species,
                        'terminus_hits': terminus_hits
                    }
                ))

        # Sort by score
        motif_hits.sort(key=lambda x: x.score, reverse=True)
        return motif_hits


# ============================================================================
# Step 3: Chromosome Terminus Extraction
# ============================================================================

class ChromosomeEndExtractor:
    """Extract chromosome terminus sequences"""

    def __init__(self, extract_length: int = 100000):
        self.extract_length = extract_length

    def extract_ends(self, chromosomes: Dict[str, str]) -> List[ChromosomeEnd]:
        """Extract both terminus sequences of all chromosomes"""
        logger.info(f"Step 3: Extracting chromosome terminus sequences (length: {self.extract_length:,} bp)")

        ends = []
        for chrom_name, sequence in chromosomes.items():
            chrom_len = len(sequence)
            actual_length = min(self.extract_length, chrom_len // 2)

            ends.append(ChromosomeEnd(
                chrom_name=chrom_name,
                end_type='5prime',
                end_sequence=sequence[:actual_length],
                full_length=chrom_len,
                extract_length=actual_length
            ))

            ends.append(ChromosomeEnd(
                chrom_name=chrom_name,
                end_type='3prime',
                end_sequence=sequence[-actual_length:],
                full_length=chrom_len,
                extract_length=actual_length
            ))

        logger.info(f"  ✓ Extracted {len(ends)} chromosome termini")
        return ends

    def write_ends_fasta(self, ends: List[ChromosomeEnd], output_file: str):
        """Write terminus sequences to FASTA file"""
        sequences = {end.end_id: end.end_sequence for end in ends}
        write_fasta(sequences, output_file)


# ============================================================================
# Step 4: Find Overlapping Reads with Telomere
# ============================================================================

class TelomereReadFinder:
    """Find reads overlapping with chromosome termini containing telomere motif
    Scoring algorithm optimized: Now prioritizes reads with consecutive motifs at terminus
    """

    def __init__(self,
                 min_overlap: int = 500,
                 min_identity: float = 0.85,
                 min_telomere_repeats: int = 3,
                 threads: int = 4):
        self.min_overlap = min_overlap
        self.min_identity = min_identity
        self.min_telomere_repeats = min_telomere_repeats
        self.threads = threads

    def find_telomere_reads(self,
                            reads_file: str,
                            ends: List[ChromosomeEnd],
                            motif: str,
                            work_dir: Path) -> Dict[str, List[TelomereRead]]:
        """Find overlapping reads with telomere"""
        logger.info(f"Step 4: Finding overlapping reads with telomere")
        logger.info(f"  Parameters: min overlap {self.min_overlap}bp, min identity {self.min_identity * 100:.0f}%")
        logger.info(f"  Telomere motif: {motif}, min repeats {self.min_telomere_repeats}")

        # Create reverse complement motif
        rc_motif = reverse_complement(motif)
        logger.info(f"  Original motif: {motif}, reverse complement: {rc_motif}")

        work_dir.mkdir(parents=True, exist_ok=True)

        ends_fasta = work_dir / "chromosome_ends.fasta"
        end_extractor = ChromosomeEndExtractor()
        end_extractor.write_ends_fasta(ends, str(ends_fasta))

        end_dict = {end.end_id: end for end in ends}

        paf_file = work_dir / "overlaps.paf"
        self._run_minimap2(reads_file, str(ends_fasta), str(paf_file))

        telomere_reads = self._parse_and_filter(
            str(paf_file), end_dict, reads_file, motif, rc_motif
        )

        total_reads = sum(len(v) for v in telomere_reads.values())
        logger.info(f"  ✓ Found {total_reads:,} overlapping reads with telomere")

        for end_id in sorted(telomere_reads.keys()):
            reads = telomere_reads[end_id]
            if reads:
                best = reads[0]
                logger.info(f"    {end_id}: {len(reads)} reads, "
                            f"best: {best.motif_count} repeats, overhang={best.overhang_length}bp")

        return telomere_reads

    def _run_minimap2(self, reads_file: str, ref_file: str, output_paf: str):
        """Run minimap2"""
        cmd = [
            'minimap2',
            '-x', 'map-ont',
            '-t', str(self.threads),
            '-c',
            '--secondary=no',
            '-o', output_paf,
            ref_file,
            reads_file
        ]
        run_command(cmd)

    def _calculate_end_contiguous_motif_score(self, seq: str, motif: str, end_type: str, strand: str) -> float:
        """
        Calculate score for consecutive motifs at read terminus
        This function evaluates if read terminus has consecutive telomere motifs and returns corresponding score
        """
        seq_upper = seq.upper()
        motif_upper = motif.upper()
        rc_motif = reverse_complement(motif_upper)
        motif_len = len(motif)

        # Define terminus region size to check
        check_length = min(1000, len(seq))  # Check first/last 1000bp of read

        # Determine which terminus to check based on end type and strand direction
        if end_type == '5prime':
            # Check read's 5' terminus (front part)
            check_seq = seq_upper[:check_length]
        else:  # 3prime
            # Check read's 3' terminus (back part)
            check_seq = seq_upper[-check_length:]

        # Calculate consecutive motif score
        max_continuous_count = 0
        current_count = 0
        i = 0

        while i <= len(check_seq) - motif_len:
            window = check_seq[i:i + motif_len]
            if hamming_distance(motif_upper, window) <= 1 or hamming_distance(rc_motif, window) <= 1:
                current_count += 1
                max_continuous_count = max(max_continuous_count, current_count)
                i += motif_len  # Move by one motif length
            else:
                current_count = 0
                i += 1

        # Return score based on consecutive repeat count, give higher weight to continuity
        # 3 consecutive motifs get 1 point, 5 get 3 points, 10 get 8 points, more get higher
        if max_continuous_count >= 10:
            return max_continuous_count * 1.0  # High continuity motifs get high score
        elif max_continuous_count >= 5:
            return max_continuous_count * 0.8
        elif max_continuous_count >= 3:
            return max_continuous_count * 0.5
        elif max_continuous_count >= 2:
            return max_continuous_count * 0.2
        else:
            return 0.0  # No consecutive motifs

    def _parse_and_filter(self, paf_file: str, end_dict: Dict[str, ChromosomeEnd],
                          reads_file: str, original_motif: str, rc_motif: str) -> Dict[str, List[TelomereRead]]:
        """Parse PAF and filter reads with telomere"""
        read_dict = {}
        for read_id, seq, qual in parse_fastq_streaming(reads_file):
            read_dict[read_id] = (seq, qual)

        telomere_reads = defaultdict(list)

        with open(paf_file) as f:
            for line in f:
                fields = line.strip().split('\t')
                if len(fields) < 12:
                    continue

                read_id = fields[0]
                read_len = int(fields[1])
                read_start = int(fields[2])
                read_end = int(fields[3])
                strand = fields[4]
                target = fields[5]
                target_len = int(fields[6])
                target_start = int(fields[7])
                target_end = int(fields[8])
                matches = int(fields[9])
                block_len = int(fields[10])

                identity = matches / block_len if block_len > 0 else 0
                overlap_len = target_end - target_start

                if overlap_len < self.min_overlap or identity < self.min_identity:
                    continue

                if target not in end_dict or read_id not in read_dict:
                    continue

                seq, qual = read_dict[read_id]
                end_info = end_dict[target]

                # Determine motif direction to search based on terminus type
                if end_info.end_type == '5prime':
                    # 5prime terminus: Find reads with original motif
                    end_motif = original_motif
                else:  # 3prime
                    # 3prime terminus: Find reads with reverse complement motif
                    end_motif = rc_motif

                # Calculate overhang
                if end_info.end_type == '5prime':
                    if strand == '+':
                        overhang_length = read_start
                        overhang_seq = seq[:read_start] if read_start > 0 else ""
                    else:
                        overhang_length = read_len - read_end
                        overhang_seq = seq[read_end:] if read_end < read_len else ""
                else:
                    if strand == '+':
                        overhang_length = read_len - read_end
                        overhang_seq = seq[read_end:] if read_end < read_len else ""
                    else:
                        overhang_length = read_start
                        overhang_seq = seq[:read_start] if read_start > 0 else ""

                # Check for telomere motif
                if overhang_length > 20:
                    motif_count, tel_start, tel_end = count_motif_occurrences_specific(
                        overhang_seq, end_motif, max_mismatch=1
                    )
                else:
                    check_region = seq[:2000] if end_info.end_type == '5prime' else seq[-2000:]
                    motif_count, tel_start, tel_end = count_motif_occurrences_specific(
                        check_region, end_motif, max_mismatch=1
                    )

                # Calculate continuous motif score at ends
                end_contiguous_score = self._calculate_end_contiguous_motif_score(
                    seq, end_motif, end_info.end_type, strand
                )

                if motif_count >= self.min_telomere_repeats:
                    extension_score = (
                            motif_count * 10 +
                            min(overhang_length, 5000) / 100 +
                            identity * 20 +
                            overlap_len / 1000 +
                            end_contiguous_score * 15  # Highly prioritize terminus consecutive motifs
                    )

                    telomere_reads[target].append(TelomereRead(
                        read_id=read_id,
                        sequence=seq,
                        quality=qual,
                        chrom_end=target,
                        motif=end_motif,  # Use actual detected motif direction
                        motif_count=motif_count,
                        telomere_position=end_info.end_type,
                        telomere_start=tel_start,
                        telomere_end=tel_end,
                        overhang_length=overhang_length,
                        overhang_seq=overhang_seq,
                        overlap_length=overlap_len,
                        identity=identity,
                        extension_score=extension_score
                    ))

        for end_id in telomere_reads:
            telomere_reads[end_id].sort(key=lambda x: x.extension_score, reverse=True)

        return dict(telomere_reads)


# ============================================================================
# Step 5: Local Assembly or Direct Use of Best Read
# ============================================================================

class TelomereAssembler:
    """Assemble telomere reads or directly use best read"""

    def __init__(self,
                 threads: int = 4,
                 read_type: str = 'nano-raw',
                 max_reads_for_assembly: int = 50):
        self.threads = threads
        self.read_type = read_type
        self.max_reads_for_assembly = max_reads_for_assembly
        self.has_flye = shutil.which('flye') is not None

    def process(self,
                telomere_reads: Dict[str, List[TelomereRead]],
                work_dir: Path) -> Dict[str, Tuple[str, str, int, str]]:
        """
        Process telomere reads for each chromosome terminus
        Returns: {end_id: (extension_seq, motif, repeat_count, method)}
        """
        logger.info("Step 5: Processing telomere reads (assembly or direct use)")

        if not self.has_flye:
            logger.info("  Flye not available, will directly use best read for extension")

        work_dir.mkdir(parents=True, exist_ok=True)
        results = {}

        for end_id, reads in telomere_reads.items():
            if not reads:
                continue

            logger.info(f"  Processing {end_id} ({len(reads)} reads)...")

            best_read = reads[0]

            # Strategy 0: For cases where telomere sequence is at read terminus (especially 3' terminus)
            # If overhang is very short but read terminus is rich in telomere motif, directly use read terminus telomere region
            if best_read.overhang_length <= 50 and best_read.motif_count >= 8:
                # Check if read terminus is rich in telomere sequence
                telomere_region = self._extract_telomere_region_from_end(best_read)
                if telomere_region and len(telomere_region) >= 20:
                    count, _, _ = count_motif_occurrences_specific(telomere_region, best_read.motif)
                    if count >= 3:
                        results[end_id] = (
                            telomere_region,
                            best_read.motif,
                            count,
                            'telomere_end_region'
                        )
                        logger.info(
                            f"    ✓ Using read terminus telomere region: {len(telomere_region)}bp, {count} repeats")
                        continue

            # Strategy 1: If best read's overhang is good enough, use directly
            if best_read.overhang_length >= 100 and best_read.motif_count >= 5:
                extension_seq = best_read.overhang_seq
                if len(extension_seq) >= 50:
                    results[end_id] = (
                        extension_seq,
                        best_read.motif,
                        best_read.motif_count,
                        'direct_read'
                    )
                    logger.info(f"    ✓ Directly using best read: {len(extension_seq)}bp, "
                                f"{best_read.motif_count} repeats")
                    continue

            # Strategy 1.5: For reads with short overhang but rich in motifs
            if (best_read.overhang_length >= 20 and best_read.overhang_length < 100 and
                    best_read.motif_count >= 8):
                extension_seq = best_read.overhang_seq
                if len(extension_seq) >= 20:
                    results[end_id] = (
                        extension_seq,
                        best_read.motif,
                        best_read.motif_count,
                        'short_overhang_direct'
                    )
                    logger.info(f"    ✓ Using short overhang read: {len(extension_seq)}bp, "
                                f"{best_read.motif_count} repeats")
                    continue

            # Strategy 2: Try Flye assembly
            if self.has_flye and len(reads) >= 3:
                assembly_reads = reads[:self.max_reads_for_assembly]
                assembled = self._try_flye_assembly(assembly_reads, end_id, work_dir)

                if assembled:
                    ext_seq, motif, count = assembled
                    results[end_id] = (ext_seq, motif, count, 'assembly')
                    logger.info(f"    ✓ Flye assembly successful: {len(ext_seq)}bp, {count} repeats")
                    continue

            # Strategy 3: Fall back to directly using best read's entire telomere region
            extension_seq = self._extract_telomere_region(best_read)
            if extension_seq and len(extension_seq) >= 30:
                count, _, _ = count_motif_occurrences_specific(extension_seq, best_read.motif)
                if count >= 3:
                    results[end_id] = (
                        extension_seq,
                        best_read.motif,
                        count,
                        'direct_read'
                    )
                    logger.info(f"    ✓ Using telomere region: {len(extension_seq)}bp, {count} repeats")
                    continue

            logger.info(f"    ✗ Failed to extract valid extension sequence")

        logger.info(f"  ✓ Complete: Successfully processed {len(results)} chromosome termini")
        return results

    def _try_flye_assembly(self, reads: List[TelomereRead], end_id: str,
                           work_dir: Path) -> Optional[Tuple[str, str, int]]:
        """Try assembly using Flye"""
        assembly_dir = work_dir / f"assembly_{end_id}"
        assembly_dir.mkdir(parents=True, exist_ok=True)

        reads_file = assembly_dir / "reads.fastq"
        read_tuples = [(r.read_id, r.sequence, r.quality or 'I' * len(r.sequence))
                       for r in reads]
        write_fastq(read_tuples, str(reads_file))

        total_bases = sum(len(r.sequence) for r in reads)
        genome_size = max(5000, min(total_bases // 50, 100000))

        flye_output = assembly_dir / "flye_output"
        cmd = [
            'flye',
            f'--{self.read_type}', str(reads_file),
            '--out-dir', str(flye_output),
            '--threads', str(self.threads),
            '--genome-size', str(genome_size),
            '--min-overlap', '500',
            '--iterations', '1'
        ]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            if result.returncode != 0:
                return None
        except (subprocess.TimeoutExpired, Exception):
            return None

        assembly_fasta = flye_output / "assembly.fasta"
        if not assembly_fasta.exists():
            return None

        contigs = parse_fasta(str(assembly_fasta))
        if not contigs:
            return None

        best_read = reads[0]
        motif = best_read.motif

        for contig_name, contig_seq in sorted(contigs.items(),
                                              key=lambda x: len(x[1]), reverse=True):
            for check_seq in [contig_seq[:3000], contig_seq[-3000:]]:
                count, start, end = count_motif_occurrences_specific(check_seq, motif)
                if count >= 5:
                    if start < 500:
                        extension = check_seq[:end + 100]
                    else:
                        extension = check_seq[start - 100:]
                    return (extension, motif, count)

        return None

    def _extract_telomere_region(self, read: TelomereRead) -> Optional[str]:
        """Extract telomere region from read"""
        seq = read.sequence
        motif = read.motif

        # First check both read termini, prioritize 5' terminus
        for is_5prime in [True, False]:
            check_seq = seq[:3000] if is_5prime else seq[-3000:]
            count, start, end = count_motif_occurrences_specific(check_seq, motif)

            if count >= 3:
                if is_5prime:
                    # 5' terminus: Return from start to telomere end + extra 50bp
                    extract_end = min(len(seq), start + end + 50)
                    return seq[:extract_end]
                else:
                    # 3' terminus: Return from telomere start - 50bp to read end
                    offset = max(0, len(seq) - 3000)
                    actual_start = offset + start - 50
                    return seq[max(0, actual_start):]

        # If not found at both termini, check entire read for dense telomere region
        full_count, full_start, full_end = count_motif_occurrences_specific(seq, motif)
        if full_count >= 8:  # Sufficient repeats in entire read
            # Extract telomere dense region and surrounding sequence
            extract_start = max(0, full_start - 100)
            extract_end = min(len(seq), full_end + 100)
            return seq[extract_start:extract_end]

        return None

    def _extract_telomere_region_from_end(self, read: TelomereRead) -> Optional[str]:
        """
        Extract telomere region from read terminus (specifically for cases where telomere sequence is at read terminus)
        e.g., 3' terminus rich in telomere motif but overhang is very short
        """
        seq = read.sequence
        motif = read.motif

        # Check read's 3' terminus (last 3000bp)
        end_seq = seq[-3000:]
        count, start, end = count_motif_occurrences_specific(end_seq, motif)

        if count >= 3:
            # From detected telomere sequence start to read end
            seq_offset = len(seq) - len(end_seq)
            actual_start = seq_offset + start
            telomere_region = seq[actual_start:]

            # Ensure at least 20bp of telomere sequence
            if len(telomere_region) >= 20:
                return telomere_region

        # If not found at 3' terminus, check 5' terminus (first 3000bp)
        start_seq = seq[:3000]
        count, start, end = count_motif_occurrences_specific(start_seq, motif)

        if count >= 3:
            # From read start to detected telomere sequence end
            telomere_region = seq[:end]

            # Ensure at least 20bp of telomere sequence
            if len(telomere_region) >= 20:
                return telomere_region

        return None


# ============================================================================
# Step 6: WGS Polishing (Optional)
# ============================================================================

class SequencePolisher:
    """Polish using WGS data"""

    def __init__(self, threads: int = 4):
        self.threads = threads
        self.has_bcftools = shutil.which('bcftools') is not None
        self.has_racon = shutil.which('racon') is not None

    def polish(self, extensions: Dict[str, Tuple[str, str, int, str]],
               wgs_file: str, work_dir: Path) -> Dict[str, Tuple[str, str, int, str, bool]]:
        """Polish extension sequences"""
        if not wgs_file or not os.path.exists(wgs_file):
            return {k: (*v, False) for k, v in extensions.items()}

        if not self.has_bcftools:
            logger.info("  bcftools not available, skipping WGS polishing")
            return {k: (*v, False) for k, v in extensions.items()}

        logger.info("Step 6: Polishing using WGS data")
        work_dir.mkdir(parents=True, exist_ok=True)

        results = {}
        for end_id, (ext_seq, motif, count, method) in extensions.items():
            polished_seq = self._polish_with_wgs(ext_seq, wgs_file, work_dir, end_id)
            polished = polished_seq != ext_seq

            if polished:
                new_count, _, _ = count_motif_occurrences_specific(polished_seq, motif)
                results[end_id] = (polished_seq, motif, new_count, method, True)
                logger.info(f"    ✓ {end_id}: Polishing complete")
            else:
                results[end_id] = (ext_seq, motif, count, method, False)

        return results

    def _polish_with_wgs(self, sequence: str, wgs_file: str,
                         work_dir: Path, name: str) -> str:
        """Polish single sequence using WGS data"""
        try:
            ref_file = work_dir / f"{name}_ref.fasta"
            write_fasta({name: sequence}, str(ref_file))

            bam_file = work_dir / f"{name}.bam"
            sam_file = work_dir / f"{name}.sam"

            # Alignment
            sam_cmd = ['minimap2', '-ax', 'sr', '-t', str(self.threads),
                       str(ref_file), wgs_file]
            with open(sam_file, 'w') as f:
                subprocess.run(sam_cmd, stdout=f, stderr=subprocess.DEVNULL)

            # Sort
            subprocess.run(['samtools', 'sort', '-@', str(self.threads),
                            '-o', str(bam_file), str(sam_file)],
                           capture_output=True)
            subprocess.run(['samtools', 'index', str(bam_file)], capture_output=True)

            # Variant calling
            subprocess.run(['samtools', 'faidx', str(ref_file)], capture_output=True)

            vcf_file = work_dir / f"{name}.vcf.gz"
            subprocess.run(
                f"bcftools mpileup -f {ref_file} {bam_file} 2>/dev/null | "
                f"bcftools call -c -o {vcf_file} 2>/dev/null",
                shell=True
            )

            if vcf_file.exists():
                subprocess.run(['bcftools', 'index', str(vcf_file)], capture_output=True)

                consensus_file = work_dir / f"{name}_consensus.fasta"
                subprocess.run(
                    f"bcftools consensus -f {ref_file} {vcf_file} > {consensus_file} 2>/dev/null",
                    shell=True
                )

                if consensus_file.exists():
                    polished = parse_fasta(str(consensus_file))
                    if polished:
                        return list(polished.values())[0]

        except Exception as e:
            logger.debug(f"WGS polishing failed ({name}): {e}")

        return sequence


# ============================================================================
# Step 7: Integrate into Genome (with v3.2 optimization + v3.2.1 replacement feature)
# ============================================================================

class TelomereIntegrator:
    """Integrate telomere sequences into genome - v3.2.1 version"""

    def __init__(self,
                 min_overlap: int = 100,
                 enable_replacement: bool = False,
                 replacement_min_support: int = 1):
        self.min_overlap = min_overlap
        self.enable_replacement = enable_replacement
        self.replacement_min_support = replacement_min_support

        # v3.2 optimization parameters
        self.max_extension_length = OPTIMIZATION_PARAMS['max_extension_length']
        self.kmer_size = OPTIMIZATION_PARAMS['overlap_kmer_size']
        self.flank_exclude = OPTIMIZATION_PARAMS['telomere_flank_exclude']

    def integrate(self,
                  extensions: Dict[str, Tuple],
                  chromosomes: Dict[str, str],
                  chromosome_ends: List[ChromosomeEnd],
                  telomere_reads: Dict[str, List[TelomereRead]] = None) -> Tuple[Dict[str, str], List[ExtensionResult]]:
        """Integrate telomere sequences"""
        logger.info("Step 7: Integrating telomere sequences into genome")
        if self.enable_replacement:
            logger.info("  ★ Terminus replacement feature enabled")

        end_dict = {end.end_id: end for end in chromosome_ends}
        extended_genome = dict(chromosomes)
        results = []

        # v3.2.1: Collect replacement candidates
        replacement_candidates = {}
        if self.enable_replacement and telomere_reads:
            replacement_candidates = self._find_replacement_candidates(telomere_reads, end_dict)
            if replacement_candidates:
                logger.info(f"  Found {len(replacement_candidates)} replacement candidates")

        # Process existing extension results
        processed_ends = set()
        for end_id, ext_data in extensions.items():
            if len(ext_data) == 5:
                ext_seq, motif, repeat_count, method, polished = ext_data
            else:
                ext_seq, motif, repeat_count, method = ext_data
                polished = False

            if end_id not in end_dict:
                continue

            end_info = end_dict[end_id]
            chrom_name = end_info.chrom_name
            end_type = end_info.end_type

            # v3.2 optimization: Improved overlap detection
            clean_extension = self._remove_overlap_improved(ext_seq, end_info, motif)

            if not clean_extension or len(clean_extension) < 20:
                logger.info(f"  {end_id}: Skipped (no valid extension)")
                continue

            # v3.2 optimization: Validate and possibly recover telomere
            final_count, _, _ = count_motif_occurrences_specific(clean_extension, motif)

            is_valid, clean_extension, skip_reason = self._validate_extension(
                clean_extension, ext_seq, motif, final_count, repeat_count, end_type
            )

            if not is_valid:
                logger.info(f"  {end_id}: Skipped ({skip_reason})")
                continue

            # Recalculate final repeat count
            final_count, _, _ = count_motif_occurrences_specific(clean_extension, motif)

            # v3.2 optimization: Limit extension length to prevent subtelomere extension
            if len(clean_extension) > self.max_extension_length:
                clean_extension = self._trim_to_telomere(clean_extension, motif, end_type)
                final_count, _, _ = count_motif_occurrences_specific(clean_extension, motif)
                logger.info(f"  {end_id}: Trimmed to telomere region ({len(clean_extension)}bp)")

            # Integrate
            original_len = len(chromosomes[chrom_name])
            if end_type == '5prime':
                extended_genome[chrom_name] = clean_extension + extended_genome[chrom_name]
            else:
                extended_genome[chrom_name] = extended_genome[chrom_name] + clean_extension

            extension_len = len(clean_extension)
            processed_ends.add(end_id)

            results.append(ExtensionResult(
                chrom_name=chrom_name,
                end_type=end_type,
                original_length=original_len,
                extension_length=extension_len,
                final_length=original_len + extension_len,
                extension_seq=clean_extension,
                telomere_motif=motif,
                telomere_repeat_count=final_count,
                supporting_reads=1,
                quality_score=final_count / max(1, extension_len / len(motif)),
                method=method,
                polished=polished
            ))

            logger.info(f"  ✓ {end_id}: Extended {extension_len:,}bp, "
                        f"{final_count} repeats, method={method}")

        # v3.2.1: Process replacement candidates (termini that couldn't be extended before)
        if self.enable_replacement:
            for end_id, candidates in replacement_candidates.items():
                if end_id in processed_ends:
                    continue  # Already successfully extended, skip

                if end_id not in end_dict:
                    continue

                end_info = end_dict[end_id]
                chrom_name = end_info.chrom_name
                end_type = end_info.end_type

                # Execute replacement
                replacement_result = self._execute_replacement(
                    candidates, end_info, extended_genome[chrom_name]
                )

                if replacement_result:
                    new_seq, ext_len, motif, repeat_count = replacement_result
                    original_len = len(chromosomes[chrom_name])
                    extended_genome[chrom_name] = new_seq

                    results.append(ExtensionResult(
                        chrom_name=chrom_name,
                        end_type=end_type,
                        original_length=original_len,
                        extension_length=ext_len,
                        final_length=len(new_seq),
                        extension_seq="[replacement]",
                        telomere_motif=motif,
                        telomere_repeat_count=repeat_count,
                        supporting_reads=len(candidates),
                        quality_score=repeat_count * 0.1,
                        method='replacement',
                        polished=False
                    ))

                    logger.info(f"  ★ {end_id}: Terminus replacement successful, "
                                f"{repeat_count} repeats, {len(candidates)} reads support")

        logger.info(f"  ✓ Complete: Extended {len(results)} chromosome termini")
        return extended_genome, results

    def _find_replacement_candidates(self,
                                     telomere_reads: Dict[str, List[TelomereRead]],
                                     end_dict: Dict[str, ChromosomeEnd]) -> Dict[str, List[TelomereRead]]:
        """v3.2.1: Find reads meeting replacement criteria"""
        candidates = {}

        for end_id, reads in telomere_reads.items():
            if end_id not in end_dict:
                continue

            # Filter reads meeting replacement criteria
            valid_reads = [
                r for r in reads
                if (r.overhang_length <= REPLACEMENT_PARAMS['max_overhang'] and
                    r.motif_count >= REPLACEMENT_PARAMS['min_motif_count'] and
                    r.identity >= REPLACEMENT_PARAMS['min_identity'] and
                    r.overlap_length >= REPLACEMENT_PARAMS['min_overlap'])
            ]

            # Need sufficient supporting reads
            if len(valid_reads) >= self.replacement_min_support:
                candidates[end_id] = valid_reads

        return candidates

    def _execute_replacement(self,
                             candidates: List[TelomereRead],
                             end_info: ChromosomeEnd,
                             chrom_seq: str) -> Optional[Tuple[str, int, str, int]]:
        """v3.2.1: Execute terminus replacement"""
        if not candidates:
            return None

        # Select best read (one with most telomere repeats)
        best_read = max(candidates, key=lambda r: r.motif_count)
        motif = best_read.motif

        # Extract telomere region from read
        seq = best_read.sequence
        count, tel_start, tel_end = count_motif_occurrences_specific(seq, motif)

        if count < REPLACEMENT_PARAMS['min_motif_count']:
            return None

        # Extract telomere region (including some flanking sequence)
        if end_info.end_type == '5prime':
            # 5' terminus: Telomere should be at front of read
            telomere_region = seq[:min(tel_end + 200, len(seq))]

            # Calculate cut point on chromosome (based on overlap position)
            cut_point = best_read.overlap_length

            # New sequence = telomere region + remaining chromosome
            new_seq = telomere_region + chrom_seq[cut_point:]
            ext_len = len(telomere_region)

        else:
            # 3' terminus: Telomere should be at end of read
            telomere_region = seq[max(0, tel_start - 200):]

            # Calculate cut point on chromosome
            cut_point = len(chrom_seq) - best_read.overlap_length

            # New sequence = front part of chromosome + telomere region
            new_seq = chrom_seq[:cut_point] + telomere_region
            ext_len = len(telomere_region)

        # Validate telomere after replacement
        final_count = count_motif_simple(telomere_region, motif)
        if final_count < 5:
            return None

        return (new_seq, ext_len, motif, final_count)

    def _validate_extension(self, clean_extension: str, original_ext: str,
                            motif: str, final_count: int, original_count: int,
                            end_type: str) -> Tuple[bool, str, str]:
        """v3.2 optimization: Validate extension sequence"""
        motif_len = len(motif)

        def terminal_repeat_count(seq: str) -> int:
            if not seq:
                return 0
            window_size = min(1000, len(seq))
            terminal_seq = seq[:window_size] if end_type == '5prime' else seq[-window_size:]
            count, start, end = count_motif_occurrences_specific(terminal_seq, motif)
            if not count:
                return 0
            distance = start if end_type == '5prime' else window_size - end
            return count if distance <= 500 else 0

        # Condition 1: Accept only when repeats are present at the real chromosome terminus.
        if final_count >= 2 and terminal_repeat_count(clean_extension) >= 2:
            return True, clean_extension, ""

        # Condition 2: If overlap detection left subtelomeric sequence outside the motif,
        # recover the terminal telomere-bearing segment from the original extension.
        if original_count >= 5:
            raw_count, raw_start, raw_end = count_motif_occurrences_specific(original_ext, motif)
            if raw_count >= 3 and raw_end > raw_start:
                if end_type == '5prime':
                    recovered = original_ext[raw_start:min(len(original_ext), raw_end + 200)]
                else:
                    recovered = original_ext[max(0, raw_start - 200):raw_end]

                verify_count, _, _ = count_motif_occurrences_specific(recovered, motif)
                if verify_count >= 2 and terminal_repeat_count(recovered) >= 2:
                    return True, recovered, ""

        # Condition 3: Check telomere density, but still require terminal support.
        density = calculate_telomere_density(clean_extension, motif)
        if density >= 0.5 and final_count >= 1 and terminal_repeat_count(clean_extension) >= 1:
            return True, clean_extension, ""

        return False, "", f"Insufficient telomere repeats ({final_count})"

    def _remove_overlap_improved(self, extension: str, end_info: ChromosomeEnd,
                                 motif: str) -> str:
        """v3.2 optimization: Improved overlap detection, avoid damaging telomere sequence"""
        end_seq = end_info.end_sequence

        # Only use region far from telomere as reference
        if end_info.end_type == '5prime':
            check_region = end_seq[self.flank_exclude:min(20000, len(end_seq))]
        else:
            check_region = end_seq[max(0, len(end_seq) - 20000):max(0, len(end_seq) - self.flank_exclude)]

        if len(check_region) < self.kmer_size:
            check_region = end_seq

        # Build kmer set
        end_kmers = set()
        for i in range(len(check_region) - self.kmer_size + 1):
            kmer = check_region[i:i + self.kmer_size].upper()
            # Exclude low complexity kmers
            if not is_low_complexity(kmer):
                end_kmers.add(kmer)

        def find_overlap_start(seq: str) -> int:
            seq_upper = seq.upper()
            for i in range(len(seq) - self.kmer_size + 1):
                kmer = seq_upper[i:i + self.kmer_size]
                if kmer in end_kmers and not is_low_complexity(kmer):
                    return i
            return len(seq)

        def remove_overlap(seq: str, overlap_start: int) -> str:
            if end_info.end_type == '5prime':
                return seq[:overlap_start] if overlap_start > 0 else seq
            if overlap_start < len(seq) - self.min_overlap:
                return seq[overlap_start + self.min_overlap:]
            return seq

        def terminal_motif_score(seq: str) -> Tuple[int, int, float]:
            if not seq:
                return (0, -10**9, 0.0)

            window_size = min(1000, len(seq))
            if end_info.end_type == '5prime':
                terminal_seq = seq[:window_size]
                count, start, end = count_motif_occurrences_specific(terminal_seq, motif)
                distance = start if count else window_size
            else:
                terminal_seq = seq[-window_size:]
                count, start, end = count_motif_occurrences_specific(terminal_seq, motif)
                distance = (window_size - end) if count else window_size

            density = (count * len(motif)) / max(1, window_size)
            return (count, -distance, density)

        candidates = []
        for oriented_extension in (extension, reverse_complement(extension)):
            overlap_start = find_overlap_start(oriented_extension)
            clean_extension = remove_overlap(oriented_extension, overlap_start)
            motif_score = terminal_motif_score(clean_extension)
            overlap_found = overlap_start < len(oriented_extension)
            candidates.append((motif_score, overlap_found, -overlap_start, clean_extension))

        candidates.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
        return candidates[0][3]

    def _trim_to_telomere(self, extension: str, motif: str, end_type: str) -> str:
        """v3.2 optimization: Trim to telomere dense region in sequence"""
        count, start, end = count_motif_occurrences_specific(extension, motif)

        if count >= 3 and end > start:
            if end_type == '5prime':
                extract_start = max(0, start - 200)
                extract_end = min(len(extension), end + 500)
            else:
                extract_start = max(0, start - 500)
                extract_end = min(len(extension), end + 200)

            return extension[extract_start:extract_end]

        max_len = self.max_extension_length
        if end_type == '5prime':
            return extension[-max_len:] if len(extension) > max_len else extension
        else:
            return extension[:max_len] if len(extension) > max_len else extension


# ============================================================================
# Report Generator
# ============================================================================

class ReportGenerator:
    """Generate analysis reports"""

    def __init__(self, output_dir: Path):
        self.output_dir = output_dir

    def generate_all(self, results: List[ExtensionResult], motifs: List[TelomereMotif],
                     extended_genome: Dict[str, str], original_genome: Dict[str, str]):
        """Generate all reports"""
        logger.info("Generating analysis reports...")
        self._generate_json(results, motifs, extended_genome, original_genome)
        self._generate_bed(results, extended_genome)
        self._generate_gff(results, extended_genome)
        self._generate_html(results, motifs, original_genome, extended_genome)
        logger.info(f"  ✓ Reports saved to {self.output_dir}")

    def _generate_json(self, results: List[ExtensionResult], motifs: List[TelomereMotif],
                       extended_genome: Dict[str, str], original_genome: Dict[str, str]):
        """Generate JSON format report"""
        json_file = self.output_dir / "analysis_results.json"

        data = {
            'version': VERSION,
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'chromosomes': len(original_genome),
                'extended_ends': len(results),
                'original_size': sum(len(s) for s in original_genome.values()),
                'extended_size': sum(len(s) for s in extended_genome.values()),
                'total_extension': sum(r.extension_length for r in results)
            },
            'motifs': [
                {
                    'sequence': m.sequence,
                    'reverse_complement': m.reverse_complement,
                    'count': m.count,
                    'score': m.score,
                    'source': m.source,
                    'priority': m.priority,
                    'algorithm': m.algorithm
                }
                for m in motifs
            ],
            'extensions': [
                {
                    'chromosome': r.chrom_name,
                    'end': r.end_type,
                    'original_length': r.original_length,
                    'extension_length': r.extension_length,
                    'final_length': r.final_length,
                    'motif': r.telomere_motif,
                    'repeat_count': r.telomere_repeat_count,
                    'quality_score': r.quality_score,
                    'method': r.method,
                    'polished': r.polished
                }
                for r in results
            ]
        }

        with open(json_file, 'w') as f:
            json.dump(data, f, indent=2)

    def _generate_bed(self, results: List[ExtensionResult], genome: Dict[str, str]):
        """Generate BED format telomere annotation"""
        bed_file = self.output_dir / "telomeres.bed"

        with open(bed_file, 'w') as f:
            for r in results:
                chrom_len = len(genome.get(r.chrom_name, ""))
                if r.end_type == '5prime':
                    start = 0
                    end = r.extension_length
                else:
                    start = chrom_len - r.extension_length
                    end = chrom_len

                f.write(f"{r.chrom_name}\t{start}\t{end}\t"
                        f"telomere_{r.end_type}\t{r.telomere_repeat_count}\t+\n")

    def _generate_gff(self, results: List[ExtensionResult], genome: Dict[str, str]):
        """Generate GFF format telomere annotation"""
        gff_file = self.output_dir / "telomeres.gff3"

        with open(gff_file, 'w') as f:
            f.write("##gff-version 3\n")

            for i, r in enumerate(results, 1):
                chrom_len = len(genome.get(r.chrom_name, ""))
                if r.end_type == '5prime':
                    start = 1
                    end = r.extension_length
                else:
                    start = chrom_len - r.extension_length + 1
                    end = chrom_len

                f.write(f"{r.chrom_name}\tFungalTeloExtender\ttelomere\t{start}\t{end}\t"
                        f".\t+\t.\tID=telomere_{i};Name={r.chrom_name}_{r.end_type};"
                        f"motif={r.telomere_motif};repeat_count={r.telomere_repeat_count};"
                        f"method={r.method}\n")

    def _generate_html(self, results: List[ExtensionResult], motifs: List[TelomereMotif],
                       original_genome: Dict[str, str], extended_genome: Dict[str, str]):
        """Generate HTML report"""
        html_file = self.output_dir / "telomere_report.html"

        original_size = sum(len(s) for s in original_genome.values())
        extended_size = sum(len(s) for s in extended_genome.values())
        total_extension = sum(r.extension_length for r in results)
        growth_percent = (total_extension / original_size * 100) if original_size > 0 else 0

        method_counts = Counter(r.method for r in results)
        polished_count = sum(1 for r in results if r.polished)

        algorithm_used = motifs[0].algorithm if motifs else "N/A"

        html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FungalTeloExtender v{VERSION} Analysis Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 20px; background: #f5f7fa; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        h2 {{ color: #34495e; border-bottom: 2px solid #3498db; padding-bottom: 8px; margin-top: 30px; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
        .stat-box {{ background: white; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; }}
        .stat-number {{ font-size: 36px; font-weight: bold; color: #2980b9; }}
        .stat-label {{ font-size: 14px; color: #7f8c8d; margin-top: 8px; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }}
        th, td {{ border: 1px solid #ecf0f1; padding: 12px 15px; text-align: left; }}
        th {{ background: #3498db; color: white; font-weight: 600; }}
        tr:nth-child(even) {{ background-color: #f8f9fa; }}
        .info-box {{ background: #e8f6ff; border-left: 4px solid #3498db; padding: 15px; margin: 15px 0; border-radius: 0 8px 8px 0; }}
        .telomere-viz {{ font-family: 'Courier New', monospace; background: #2c3e50; color: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 8px; overflow-x: auto; font-size: 12px; }}
        .motif-highlight {{ background-color: #f1c40f; color: #2c3e50; padding: 1px 3px; border-radius: 3px; }}
        .motif-rc {{ background-color: #e74c3c; color: white; padding: 1px 3px; border-radius: 3px; }}
        .replacement {{ background-color: #9b59b6; color: white; padding: 2px 6px; border-radius: 3px; }}
        .algorithm-tag {{ background-color: #27ae60; color: white; padding: 2px 8px; border-radius: 3px; font-size: 12px; }}
        footer {{ margin-top: 40px; padding: 20px; border-top: 2px solid #ddd; text-align: center; color: #7f8c8d; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧬 FungalTeloExtender v{VERSION} Telomere Extension Analysis Report</h1>
        <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p>Motif identification algorithm: <span class="algorithm-tag">{algorithm_used}</span></p>

        <h2>📊 Summary Statistics</h2>
        <div class="summary-grid">
            <div class="stat-box">
                <div class="stat-number">{len(original_genome)}</div>
                <div class="stat-label">Chromosome Count</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{len(results)}</div>
                <div class="stat-label">Extended Termini</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{total_extension:,}</div>
                <div class="stat-label">Total Extension (bp)</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{growth_percent:.3f}%</div>
                <div class="stat-label">Genome Growth</div>
            </div>
        </div>

        <div class="info-box">
            <strong>Original genome size:</strong> {original_size:,} bp<br>
            <strong>Extended genome size:</strong> {extended_size:,} bp<br>
            <strong>Extension methods:</strong> Direct reads={method_counts.get('direct_read', 0)}, 
            Flye assembly={method_counts.get('assembly', 0)},
            <span class="replacement">Terminus replacement={method_counts.get('replacement', 0)}</span><br>
            <strong>WGS polished:</strong> {polished_count} sequences
        </div>

        <h2>🔍 Identified Telomere Motifs</h2>
        <table>
            <tr><th>Rank</th><th>Motif Sequence</th><th>Reverse Complement</th><th>Priority</th><th>Count</th><th>Confidence</th><th>Source</th><th>Algorithm</th></tr>
'''

        for i, m in enumerate(motifs[:5], 1):
            priority_names = {1: 'User specified', 2: 'Algorithm', 3: 'Database', 4: 'Default'}
            priority_display = priority_names.get(m.priority, str(m.priority))
            html_content += f'''
            <tr>
                <td>{i}</td>
                <td><code class="motif-highlight">{m.sequence}</code></td>
                <td><code class="motif-rc">{m.reverse_complement}</code></td>
                <td>{priority_display}</td>
                <td>{m.count}</td>
                <td>{m.score:.4f}</td>
                <td>{m.source}</td>
                <td><span class="algorithm-tag">{m.algorithm}</span></td>
            </tr>
'''

        html_content += '''
        </table>

        <h2>📈 Extension Results Details</h2>
        <table>
            <tr><th>Chromosome</th><th>Terminus</th><th>Extension Length</th><th>Motif</th><th>Repeat Count</th><th>Quality Score</th><th>Method</th><th>Polished</th></tr>
'''

        for r in sorted(results, key=lambda x: (x.chrom_name, x.end_type)):
            method_display = r.method
            if r.method == 'replacement':
                method_display = f'<span class="replacement">{r.method}</span>'

            html_content += f'''
            <tr>
                <td><strong>{r.chrom_name}</strong></td>
                <td>{r.end_type}</td>
                <td>{r.extension_length:,} bp</td>
                <td><code>{r.telomere_motif}</code></td>
                <td>{r.telomere_repeat_count}</td>
                <td>{r.quality_score:.4f}</td>
                <td>{method_display}</td>
                <td>{'✓' if r.polished else '-'}</td>
            </tr>
'''

        html_content += f'''
        </table>

        <footer>
            <p>Generated by FungalTeloExtender v{VERSION} | {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            <p>Motif identification priority: User specified > Core algorithm (ONT/genome/tidk) > Known database > Default</p>
        </footer>
    </div>
</body>
</html>
'''

        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)


# ============================================================================
# Main Pipeline
# ============================================================================

class FungalTeloExtenderPipeline:
    """Main pipeline controller v1.0.3"""

    def __init__(self,
                 genome_file: str,
                 reads_file: str,
                 output_dir: str,
                 motif: str = None,
                 wgs_file: str = None,
                 extract_length: int = 100000,
                 min_overlap: int = 500,
                 min_identity: float = 0.85,
                 min_period: int = 6,
                 max_period: int = 12,
                 min_repeat_count: int = 10,
                 min_telomere_repeats: int = 3,
                 threads: int = 4,
                 read_type: str = 'nano-raw',
                 skip_trf: bool = False,
                 enable_replacement: bool = False,
                 replacement_min_support: int = 1,
                 motif_identify_method: MotifIdentifyMethod = MotifIdentifyMethod.ONT_READS,
                 tidk_params: TidkExploreParams = None):

        self.genome_file = os.path.abspath(genome_file)
        self.reads_file = os.path.abspath(reads_file)
        self.output_dir = Path(output_dir).absolute()
        self.provided_motif = motif
        self.wgs_file = os.path.abspath(wgs_file) if wgs_file else None
        self.extract_length = extract_length
        self.min_overlap = min_overlap
        self.min_identity = min_identity
        self.min_period = min_period
        self.max_period = max_period
        self.min_repeat_count = min_repeat_count
        self.min_telomere_repeats = min_telomere_repeats
        self.threads = threads
        self.read_type = read_type
        self.skip_trf = skip_trf
        self.enable_replacement = enable_replacement
        self.replacement_min_support = replacement_min_support
        self.motif_identify_method = motif_identify_method
        self.tidk_params = tidk_params or TidkExploreParams()

        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.work_dir = self.output_dir / "work"
        self.work_dir.mkdir(exist_ok=True)

        log_file = self.output_dir / "pipeline.log"
        file_handler = logging.FileHandler(log_file, mode='w', encoding='utf-8')
        file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        logger.addHandler(file_handler)

    def run(self) -> bool:
        """Run complete pipeline"""
        try:
            self._print_header()

            logger.info("=" * 60)
            logger.info("Checking software dependencies")
            check_dependencies()

            # Load genome
            logger.info("\n" + "=" * 60)
            logger.info("Loading genome")
            chromosomes = parse_fasta(self.genome_file)
            total_len = sum(len(s) for s in chromosomes.values())
            logger.info(f"  {len(chromosomes)} chromosomes, total length {total_len:,} bp")

            # Step 1: TRF screening (when using ONT algorithm and not skipped)
            tandem_reads = []
            if self.motif_identify_method == MotifIdentifyMethod.ONT_READS and not self.skip_trf:
                logger.info("\n" + "=" * 60)
                trf_screener = TRFScreener(
                    min_period=self.min_period,
                    max_period=self.max_period,
                    min_copy_number=self.min_repeat_count,
                    threads=self.threads,
                    work_dir=self.work_dir / "trf"
                )
                tandem_reads = trf_screener.screen_reads(self.reads_file)
            elif self.motif_identify_method == MotifIdentifyMethod.GENOME:
                logger.info("\n" + "=" * 60)
                logger.info("Step 1: Skipping TRF screening (using genome algorithm)")
            elif self.motif_identify_method == MotifIdentifyMethod.TIDK_EXPLORE:
                logger.info("\n" + "=" * 60)
                logger.info("Step 1: Skipping TRF screening (using tidk explore algorithm)")

            # Step 2: Identify motif (three algorithm support v1.0.3)
            logger.info("\n" + "=" * 60)
            motif_identifier = MotifIdentifier(
                min_period=self.min_period,
                max_period=self.max_period,
                min_repeat_count=self.min_repeat_count,
                identify_method=self.motif_identify_method,
                tidk_params=self.tidk_params,
                work_dir=self.work_dir / "motif"
            )
            motifs = motif_identifier.identify(
                chromosomes,
                tandem_reads,
                self.provided_motif,
                self.reads_file,
                self.genome_file  # v1.0.3: Pass genome file path to tidk explore
            )
            primary_motif = motifs[0].sequence

            # Step 3: Extract chromosome termini
            logger.info("\n" + "=" * 60)
            end_extractor = ChromosomeEndExtractor(extract_length=self.extract_length)
            chromosome_ends = end_extractor.extract_ends(chromosomes)

            # Step 4: Find overlapping reads with telomere
            logger.info("\n" + "=" * 60)
            read_finder = TelomereReadFinder(
                min_overlap=self.min_overlap,
                min_identity=self.min_identity,
                min_telomere_repeats=self.min_telomere_repeats,
                threads=self.threads
            )
            telomere_reads = read_finder.find_telomere_reads(
                self.reads_file, chromosome_ends, primary_motif,
                self.work_dir / "overlaps"
            )

            # Step 5: Assembly or directly use reads
            logger.info("\n" + "=" * 60)
            assembler = TelomereAssembler(
                threads=self.threads,
                read_type=self.read_type
            )
            extensions = assembler.process(telomere_reads, self.work_dir / "assembly")

            # Step 6: WGS polishing (optional)
            if self.wgs_file:
                logger.info("\n" + "=" * 60)
                polisher = SequencePolisher(threads=self.threads)
                extensions = polisher.polish(extensions, self.wgs_file,
                                             self.work_dir / "polish")

            # Step 7: Integrate into genome
            logger.info("\n" + "=" * 60)
            integrator = TelomereIntegrator(
                enable_replacement=self.enable_replacement,
                replacement_min_support=self.replacement_min_support
            )
            extended_genome, results = integrator.integrate(
                extensions, chromosomes, chromosome_ends, telomere_reads
            )

            # Save results
            output_genome = self.output_dir / "extended_genome.fasta"
            write_fasta(extended_genome, str(output_genome))
            logger.info(f"\nExtended genome saved: {output_genome}")

            # Generate reports
            logger.info("\n" + "=" * 60)
            reporter = ReportGenerator(self.output_dir)
            reporter.generate_all(results, motifs, extended_genome, chromosomes)

            # Save other outputs
            self._save_motifs(motifs)
            self._save_telomere_reads(telomere_reads)
            if tandem_reads:
                self._save_tandem_reads(tandem_reads)

            self._print_summary(chromosomes, extended_genome, results, motifs)

            return True

        except Exception as e:
            logger.error(f"Pipeline failed: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return False

    def _print_header(self):
        """Print header"""
        algorithm_names = {
            MotifIdentifyMethod.ONT_READS: "ONT reads (TRF+validation)",
            MotifIdentifyMethod.GENOME: "Genome (built-in scanning)",
            MotifIdentifyMethod.TIDK_EXPLORE: "tidk explore (external tool)"
        }
        algorithm_name = algorithm_names.get(self.motif_identify_method, str(self.motif_identify_method.value))
        logger.info(f"""
╔══════════════════════════════════════════════════════════════════╗
║     FungalTeloExtender v{VERSION} Telomere Extension Tool                ║
║     Three algorithm support: ONT reads / Genome scan / tidk explore  ║
╚══════════════════════════════════════════════════════════════════╝
""")
        logger.info(f"Genome file: {self.genome_file}")
        logger.info(f"Reads file: {self.reads_file}")
        logger.info(f"Output directory: {self.output_dir}")
        logger.info(f"Motif identification algorithm: {algorithm_name}")
        if self.provided_motif:
            logger.info(f"Specified Motif: {self.provided_motif} (Priority 1 - highest)")
        if self.wgs_file:
            logger.info(f"WGS data: {self.wgs_file}")
        logger.info(f"Parameters: terminus extraction={self.extract_length}bp, min overlap={self.min_overlap}bp, "
                    f"min identity={self.min_identity * 100:.0f}%")
        if self.motif_identify_method == MotifIdentifyMethod.TIDK_EXPLORE:
            logger.info(f"tidk parameters: minimum={self.tidk_params.minimum}, maximum={self.tidk_params.maximum}, "
                        f"threshold={self.tidk_params.threshold}, distance={self.tidk_params.distance}")
        if self.enable_replacement:
            logger.info(f" Terminus replacement: Enabled (min support reads={self.replacement_min_support})")

    def _save_motifs(self, motifs: List[TelomereMotif]):
        """Save motif information"""
        motif_file = self.output_dir / "discovered_motifs.tsv"
        with open(motif_file, 'w') as f:
            f.write("Rank\tMotif\tReverse_Complement\tPriority\tCount\tScore\tSource\tAlgorithm\n")
            for i, m in enumerate(motifs, 1):
                f.write(f"{i}\t{m.sequence}\t{m.reverse_complement}\t"
                        f"{m.priority}\t{m.count}\t{m.score:.6f}\t{m.source}\t{m.algorithm}\n")

    def _save_telomere_reads(self, telomere_reads: Dict[str, List[TelomereRead]]):
        """Save telomere reads information"""
        tsv_file = self.output_dir / "telomere_reads.tsv"
        fasta_file = self.output_dir / "telomere_reads.fasta"

        with open(tsv_file, 'w') as f:
            f.write("Chrom_End\tRead_ID\tRead_Length\tMotif_Count\t"
                    "Overhang_Length\tOverlap_Length\tIdentity\tScore\n")
            for end_id, reads in telomere_reads.items():
                for r in reads[:20]:
                    f.write(f"{end_id}\t{r.read_id}\t{len(r.sequence)}\t"
                            f"{r.motif_count}\t{r.overhang_length}\t"
                            f"{r.overlap_length}\t{r.identity:.4f}\t"
                            f"{r.extension_score:.2f}\n")

        with open(fasta_file, 'w') as f:
            for end_id, reads in telomere_reads.items():
                for r in reads[:10]:
                    f.write(f">{r.read_id} end={end_id} motif_count={r.motif_count}\n")
                    for i in range(0, len(r.sequence), 80):
                        f.write(r.sequence[i:i + 80] + "\n")

    def _save_tandem_reads(self, tandem_reads: List[TandemRepeatRead]):
        """Save tandem reads information"""
        fasta_file = self.output_dir / "tandem_repeat_reads.fasta"
        with open(fasta_file, 'w') as f:
            for tr in tandem_reads:
                f.write(f">{tr.read_id} repeat_unit={tr.best_repeat_unit} "
                        f"copy_number={tr.best_copy_number:.1f} position={tr.repeat_position}\n")
                for i in range(0, len(tr.sequence), 80):
                    f.write(tr.sequence[i:i + 80] + "\n")

        tsv_file = self.output_dir / "tandem_repeat_reads.tsv"
        with open(tsv_file, 'w') as f:
            f.write("Read_ID\tRead_Length\tRepeat_Unit\tCopy_Number\tPosition\n")
            for tr in tandem_reads:
                f.write(f"{tr.read_id}\t{tr.read_length}\t{tr.best_repeat_unit}\t"
                        f"{tr.best_copy_number:.1f}\t{tr.repeat_position}\n")

    def _print_summary(self, original: Dict[str, str], extended: Dict[str, str],
                       results: List[ExtensionResult], motifs: List[TelomereMotif]):
        """Print final summary"""
        original_size = sum(len(s) for s in original.values())
        extended_size = sum(len(s) for s in extended.values())
        total_extension = sum(r.extension_length for r in results) if results else 0

        motif = motifs[0] if motifs else None
        motif_display = motif.sequence if motif and len(motif.sequence) <= 12 else (
            motif.sequence[:9] + "..." if motif else 'N/A')

        priority_names = {1: 'User specified', 2: 'Algorithm', 3: 'Database', 4: 'Default'}
        motif_source = priority_names.get(motif.priority, 'Unknown') if motif else 'N/A'
        algorithm = motif.algorithm if motif else 'N/A'

        method_counts = Counter(r.method for r in results)
        polished_count = sum(1 for r in results if r.polished)

        print(f"""
    ╔══════════════════════════════════════════════════════════════════╗
    ║                    Analysis Complete (v{VERSION})                        ║
    ╠══════════════════════════════════════════════════════════════════╣
    ║  Chromosome count:      {len(original):>6}                                      ║
    ║  Primary telomere motif:{motif_display:<12} ({motif_source}, {algorithm})       ║
    ║  Extended termini:      {len(results):>6}                                      ║
    ║  Total extension:     {total_extension:>10,} bp                              ║
    ║  Original genome:   {original_size:>14,} bp                            ║
    ║  Extended genome:   {extended_size:>14,} bp                            ║
    ╠══════════════════════════════════════════════════════════════════╣
    ║  Methods: reads={method_counts.get('direct_read', 0)}, assembly={method_counts.get('assembly', 0)}, replacement={method_counts.get('replacement', 0)}, polished={polished_count}║
    ║  Output directory: {str(self.output_dir):<55}║
    ╚══════════════════════════════════════════════════════════════════╝
    """)


# ============================================================================
# Command Line Interface
# ============================================================================

def main():
    """Main entry"""
    parser = argparse.ArgumentParser(
        description=f"FungalTeloExtender v{VERSION} - Fungal Genome Telomere Extension Tool (Three Algorithm Version)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
Examples:
  # Basic usage (default uses ONT reads algorithm)
  python FungalTeloExtender_v{VERSION}.py -g genome.fasta -r reads.fastq -o output/

  # Use ONT reads algorithm for motif identification (TRF + reads terminus validation)
  python FungalTeloExtender_v{VERSION}.py -g genome.fasta -r reads.fastq -o output/ --motif_identify_with_ONT

  # Use genome scanning algorithm for motif identification
  python FungalTeloExtender_v{VERSION}.py -g genome.fasta -r reads.fastq -o output/ --motif_identify_with_genome

  # Use tidk explore algorithm for motif identification (v1.0.3 new)
  python FungalTeloExtender_v{VERSION}.py -g genome.fasta -r reads.fastq -o output/ --use-tidk-explore

  # tidk explore + custom parameters
  python FungalTeloExtender_v{VERSION}.py -g genome.fasta -r reads.fastq -o output/ \\
      --use-tidk-explore --tidk-minimum 5 --tidk-maximum 12 --tidk-threshold 100

  # Specify known motif (Priority 1 - highest, skips discovery step)
  python FungalTeloExtender_v{VERSION}.py -g genome.fasta -r reads.fastq -o output/ -m AACCCT --skip-trf

v{VERSION} Motif identification priority:
  Priority 1: User provided motif (-m/--motif) - highest priority, used directly
  Priority 2: Core algorithm (choose one of three):
           --motif_identify_with_ONT: TRF discovery from reads + reads terminus frequency validation (default)
           --motif_identify_with_genome: Genome terminus tandem repeat scanning
           --use-tidk-explore: Call external tidk explore tool (v1.0.3 new)
  Priority 3: Known fungal telomere database scanning - fallback method
  Priority 4: Default motif TTAGGG - last resort to ensure pipeline doesn't fail
        """
    )

    required = parser.add_argument_group('Required arguments')
    required.add_argument('-g', '--genome', required=True,
                          help='Input genome file (FASTA format, supports .gz compression)')
    required.add_argument('-r', '--reads', required=True,
                          help='ONT/PacBio long read data (FASTQ format, supports .gz compression)')
    required.add_argument('-o', '--output', required=True,
                          help='Output directory')

    motif_group = parser.add_argument_group('Motif identification arguments')
    motif_group.add_argument('-m', '--motif',
                             help='Known telomere motif sequence (Priority 1 - highest, e.g., AACCCT)')
    motif_group.add_argument('--motif_identify_with_ONT', action='store_true',
                             help='Use ONT algorithm for motif identification: TRF discovery from reads + reads terminus frequency validation (default)')
    motif_group.add_argument('--motif_identify_with_genome', action='store_true',
                             help='Use Genome algorithm for motif identification: Genome terminus tandem repeat scanning')
    motif_group.add_argument('--use-tidk-explore', action='store_true',
                             help='Use tidk explore algorithm for motif identification: Call external tidk explore tool (v1.0.3 new)')

    # tidk explore argument group (v1.0.3 new)
    tidk_group = parser.add_argument_group(
        'tidk explore arguments (v1.0.3 new, only effective when using --use-tidk-explore)')
    tidk_group.add_argument('--tidk-length', type=int, default=None,
                            help='Fixed repeat unit length (mutually exclusive with --tidk-minimum/--tidk-maximum)')
    tidk_group.add_argument('--tidk-minimum', type=int, default=5,
                            help='Minimum repeat unit length (default: 5)')
    tidk_group.add_argument('--tidk-maximum', type=int, default=12,
                            help='Maximum repeat unit length (default: 12)')
    tidk_group.add_argument('--tidk-threshold', type=int, default=100,
                            help='Repeat position threshold (default: 100)')
    tidk_group.add_argument('--tidk-distance', type=float, default=0.01,
                            help='Chromosome terminus distance ratio (default: 0.01)')
    tidk_group.add_argument('--tidk-verbose', action='store_true',
                            help='tidk verbose output mode')
    tidk_group.add_argument('--tidk-log', action='store_true',
                            help='tidk output log file')

    optional = parser.add_argument_group('Optional arguments')
    optional.add_argument('--wgs',
                          help='WGS short read data for polishing (FASTQ format)')
    optional.add_argument('--extract-length', type=int, default=100000,
                          help='Chromosome terminus extraction length (default: 100000)')
    optional.add_argument('--min-overlap', type=int, default=300,
                          help='Minimum overlap length between reads and chromosome terminus (default: 300)')
    optional.add_argument('--min-identity', type=float, default=0.80,
                          help='Minimum alignment identity between reads and chromosome terminus (default: 0.80)')
    optional.add_argument('--min-period', type=int, default=6,
                          help='TRF minimum repeat unit length (default: 5)')
    optional.add_argument('--max-period', type=int, default=12,
                          help='TRF maximum repeat unit length (default: 10)')
    optional.add_argument('--min-repeat', type=int, default=10,
                          help='TRF minimum repeat count (default: 10)')
    optional.add_argument('--min-telomere-repeats', type=int, default=2,
                          help='Minimum telomere repeat count in reads (default: 2)')
    optional.add_argument('-t', '--threads', type=int, default=4,
                          help='Number of CPU threads to use (default: 4)')
    optional.add_argument('--read-type',
                          choices=['nano-raw', 'nano-hq', 'pacbio-raw', 'pacbio-hifi'],
                          default='nano-raw',
                          help='Read data type (default: nano-raw)')
    optional.add_argument('--skip-trf', action='store_true',
                          help='Skip TRF tandem repeat screening (recommended to use with -m)')

    replacement_group = parser.add_argument_group('Terminus replacement arguments')
    replacement_group.add_argument('--enable-replacement', action='store_true',
                                   help='Enable terminus replacement feature (for cases with minimal overhang but strong telomere signal)')
    replacement_group.add_argument('--replacement-min-support', type=int, default=3,
                                   help='Minimum supporting reads for terminus replacement (default: 3)')

    optional.add_argument('-v', '--verbose', action='store_true',
                          help='Show detailed debug information')

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    for f, name in [(args.genome, 'Genome'), (args.reads, 'Reads')]:
        if not os.path.exists(f):
            logger.error(f"{name} file does not exist: {f}")
            sys.exit(1)

    if args.wgs and not os.path.exists(args.wgs):
        logger.error(f"WGS file does not exist: {args.wgs}")
        sys.exit(1)

    if args.min_identity < 0 or args.min_identity > 1:
        logger.error("--min-identity must be between 0 and 1")
        sys.exit(1)

    if args.min_period > args.max_period:
        logger.error("--min-period cannot be greater than --max-period")
        sys.exit(1)

    # Determine motif identification algorithm (v1.0.3 update: support three algorithms)
    if args.use_tidk_explore:
        motif_method = MotifIdentifyMethod.TIDK_EXPLORE
        # Check if tidk is installed
        if not shutil.which('tidk'):
            logger.warning("tidk not installed, will fall back to genome algorithm at runtime")
    elif args.motif_identify_with_genome:
        motif_method = MotifIdentifyMethod.GENOME
    else:
        # Default uses ONT algorithm
        motif_method = MotifIdentifyMethod.ONT_READS

    # Build tidk parameters (v1.0.3 new)
    tidk_params = TidkExploreParams(
        length=args.tidk_length,
        minimum=args.tidk_minimum,
        maximum=args.tidk_maximum,
        threshold=args.tidk_threshold,
        distance=args.tidk_distance,
        verbose=args.tidk_verbose,
        log=args.tidk_log
    )

    pipeline = FungalTeloExtenderPipeline(
        genome_file=args.genome,
        reads_file=args.reads,
        output_dir=args.output,
        motif=args.motif,
        wgs_file=args.wgs,
        extract_length=args.extract_length,
        min_overlap=args.min_overlap,
        min_identity=args.min_identity,
        min_period=args.min_period,
        max_period=args.max_period,
        min_repeat_count=args.min_repeat,
        min_telomere_repeats=args.min_telomere_repeats,
        threads=args.threads,
        read_type=args.read_type,
        skip_trf=args.skip_trf,
        enable_replacement=args.enable_replacement,
        replacement_min_support=args.replacement_min_support,
        motif_identify_method=motif_method,
        tidk_params=tidk_params  # v1.0.3 new
    )

    success = pipeline.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()