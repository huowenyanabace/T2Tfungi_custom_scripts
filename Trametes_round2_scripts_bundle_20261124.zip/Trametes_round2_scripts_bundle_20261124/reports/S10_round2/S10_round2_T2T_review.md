# S10 round2：无人工调图的染色体调整、gap 闭合与端粒复核

## 审核结论

本轮直接调整 `reviewed.assembly`，未再进入人工 Juicebox 调图。两个物种均获得 14 条染色体、0 个内部 gap、0 个 N 的候选基因组，并依据调整后的最终染色体坐标重新生成 Hi-C 互作矩阵与图件。

| 物种 | 染色体数 | 总长（bp） | N50（bp） | 最短染色体（bp） | 最长染色体（bp） | N/gap | 端粒末端 | 最终 BUSCO（basidiomycota_odb10） |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| *Trametes warnieri* | 14 | 36,475,132 | 3,259,690 | 195,425 | 4,737,226 | 0 | 28/28 严格 | C:98.7% [S:98.6%, D:0.1%], F:0.1%, M:1.2% |
| *Trametes elegans* | 14 | 35,628,544 | 2,804,305 | 1,505,517 | 3,487,915 | 0 | 27/28 严格；1/28 放宽 | C:98.5% [S:97.5%, D:1.0%], F:0.2%, M:1.3% |

审核建议：*T. warnieri* 满足本项目的严格操作性 T2T 判据；*T. elegans* 满足 14 条染色体、无 gap 和 28 个末端均有端粒证据的操作性 T2T 判据，但 Chr11 5′ 端仅达到放宽端粒判据，应在报告中保留“低一档证据”的说明，不应写成 28/28 严格端粒。

## 1. `reviewed.assembly` 直接调整

主文件：

- `manual_review/hic/Trametes_elegans/round2/edited/Trametes_elegans.round2.reviewed.assembly`

调整后的文件由 19 个保留片段组成 14 个染色体组。主要决策如下：

- 去除冗余/单倍型候选 Te_ctg003、Te_ctg006、Te_ctg018。
- 用 Te_ctg002 替换 Te_ctg022，并将其与 Te_ctg005 的非冗余后缀连接。
- Te_ctg005 仅保留 13,767–644,053 bp；Te_ctg025 保留非冗余前缀，最终重叠合并时再裁去 18 bp。
- 原 ctg035–ctg036、ctg015–ctg028 缺乏连接证据，拆分为独立染色体候选。
- 原始 round1 文件完整保留；round2 使用独立目录和文件名，便于回溯。

片段来源与裁剪记录：

- `manual_review/hic/Trametes_elegans/round2/edited/Trametes_elegans.round2.selection_provenance.tsv`

## 2. *Trametes elegans* 内部 gap 闭合

所有 5 个连接均在最终无 gap FASTA 上重新用 `pass.ul` 全基因组比对审核；阈值为比对身份度至少 80%、MAPQ 至少 20，并要求读段跨越连接两侧各 2 kb。

| 染色体 | 编辑类型 | 插入/合并长度 | 最终严格跨连接读段数 | 平均身份度 |
|---|---|---:|---:|---:|
| Chr02 | 候选序列填充 | 23,762 bp | 122 | 0.88792 |
| Chr05 | 18 bp 重叠合并 | -18 bp | 219 | 0.92363 |
| Chr09 | 候选序列填充 | 8 bp | 303 | 0.91643 |
| Chr10 | 候选序列填充 | 1 bp | 251 | 0.92030 |
| Chr14 | 候选序列填充 | 12 bp | 230 | 0.93487 |

Chr14 的 Te_ctg005–Te_ctg002 连接在填充前还有 1,110 个 Hi-C 端点联系和 218 条严格 `pass.ul` 跨越读段；填充后重新审核得到 230 条跨越读段。因此，降低的是候选搜索时对 500N 占位长度与真实 gap 长度一致性的限制，不是最终证据标准。

完整证据：

- `manual_review/S10_round2/Trametes_elegans.round2.validated_gap_edits.tsv`
- `reports/S10_round2.Trametes_elegans.round2.junction_audit.tsv`

## 3. 端粒鉴定与延伸

FungalTeloExtender 的基因组算法在两个物种中均识别到端粒 motif `AACCCT`，反向互补为 `AGGGTT`。最终审核标准为：

- 严格：物理末端 500 bp 内至少 3 个连续近似重复；每个重复最多允许 1 个错配。
- 放宽：物理末端 1 kb 内至少 2 个连续近似重复。
- 所有候选延伸都先进行全基因组唯一定位，再把最终序列重新映射到原始长读段。

结果：

- *T. warnieri*：28/28 末端达到严格标准。最后补充的 Chr12 5′ 延伸为 6,596 bp，来自 `pass.ul` 唯一 MAPQ60 读段；最终重比对有 287 条跨延伸连接读段、263 条到达新末端的读段。
- *T. elegans*：27/28 末端达到严格标准；Chr11 5′ 在物理末端有 2 个连续 motif，达到放宽标准。该端补充 81 bp；严格 `pass.ul` 中未找到合格候选，故使用独立的 `pass.all` 辅助证据。候选共 133 条，主长度簇 31 条，代表读段 MAPQ60；最终重比对有 39 条严格跨连接 `pass.all` 读段。

注意：`pass.ul` 与 `pass.all` 始终分开使用，没有拼接或混合为一个读集。*T. elegans* Chr11 5′ 必须在论文和交付报告中标记为“放宽/辅助证据端”。

端粒逐末端审计：

- `reports/S10_round2.Trametes_warnieri.terminal_motif_audit.tsv`
- `reports/S10_round2.Trametes_elegans.terminal_motif_audit.tsv`

## 4. 最终 BUSCO

BUSCO 5.8.3、`basidiomycota_odb10`、离线数据库，输入为端粒延伸后的最终 FASTA，而不是延伸前中间文件。

- *T. warnieri*：C:98.7% [S:98.6%, D:0.1%], F:0.1%, M:1.2%, n:1764。
- *T. elegans*：C:98.5% [S:97.5%, D:1.0%], F:0.2%, M:1.3%, n:1764。

两者重复 BUSCO 均远低于 5%，其中 *T. elegans* 经 round2 去冗余后 D 从旧候选的 9.0% 降到最终 1.0%。

## 5. 最终 Hi-C 复核与可视化

原始 Juicer 有效互作对通过保留片段、方向和坐标区间映射到最终 T2T 候选坐标，再构建 50 kb Cooler 矩阵。

| 物种 | 原始互作对 | 保留互作对 | 保留比例 | 说明 |
|---|---:|---:|---:|---|
| *T. warnieri* | 44,552,054 | 44,551,770 | 99.9994% | 仅 284 对无法映射到最终坐标 |
| *T. elegans* | 43,084,966 | 36,571,898 | 84.8832% | 丢弃部分主要来自已删除的冗余/替代片段及裁剪区域 |

全基因组和逐染色体热图均显示连续的染色体内主对角线；未见需要再次人工调图的明显断裂。*T. elegans* 的重复区相关交叉信号仍可见，但不构成重新排序或翻转的充分证据。

图件目录：

- `figures/S10_round2/Trametes_warnieri/`
- `figures/S10_round2/Trametes_elegans/`

每个目录保留两套互补图件：

- 项目自定义最终图：`*_final_50000.genome.*`、`*.per_chromosome.*` 和 `*.diagnostic.*`。
- 与 S09 一致的 HiCExplorer 3.6 图：`*_chromosomes_50000.genome.pdf` 和 `*_chromosomes_50000.per_chromosome.pdf`；使用 50 kb 分辨率、ICE 校正、`coolwarm` 配色、600 dpi 和 `--clearMaskedBins`。对应的原始/校正 H5 与 diagnostic PNG 同目录保存。

HiCExplorer 同款图直接使用最终 T2T 坐标的 Cooler 矩阵重新计算，并非复制或修改 S09 PDF。*T. warnieri* Chr14 仅约 195 kb，在 50 kb 分辨率下只有 4 个 bin；HiCExplorer 会将过小的单染色体面板留空，这与 S09 行为一致，不代表该染色体无 Hi-C 数据。

## 6. 最终候选序列

- `work/S10_round2/final_candidates/Trametes_warnieri/Trametes_warnieri.round2.T2T_candidate.fasta`
- `work/S10_round2/final_candidates/Trametes_elegans/Trametes_elegans.round2.T2T_candidate.fasta`

SHA-256：

- *T. warnieri*：`cf698919c2b12fe35a4e9f8bde56f5a0739d16ebe3cfa43c6023641be2ca985b`
- *T. elegans*：`f48b45706e6dc55ce38ed43b3d564b5d71044b77035327d65d4c4a47b5ea792f`

## 7. 审核门

S10 round2 当前状态为 `needs_review`。在项目负责人明确审核通过前，不进入 S11。若批准，S11 将以以上两个最终 FASTA 作为唯一主组装输入，开展最终质量评价与后续基因组注释准备。
