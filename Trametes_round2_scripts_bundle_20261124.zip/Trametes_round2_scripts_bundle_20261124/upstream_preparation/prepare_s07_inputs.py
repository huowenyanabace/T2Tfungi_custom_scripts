#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path


def read_fasta(path):
    records = []
    name = None
    description = None
    sequence = []
    with path.open() as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line.startswith(">"):
                if name is not None:
                    records.append((name, description, "".join(sequence)))
                description = line[1:]
                name = description.split()[0]
                sequence = []
            elif line:
                if name is None:
                    raise ValueError(f"Sequence before FASTA header in {path}")
                sequence.append(line.strip())
    if name is not None:
        records.append((name, description, "".join(sequence)))
    if not records:
        raise ValueError(f"No FASTA records in {path}")
    return records


def write_fasta(path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as handle:
        for name, _description, sequence in records:
            handle.write(f">{name}\n")
            for start in range(0, len(sequence), 80):
                handle.write(sequence[start:start + 80] + "\n")


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sequence_digest(records):
    digest = hashlib.sha256()
    for _name, _description, sequence in records:
        digest.update(sequence.encode())
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description="Prepare reversible nuclear/mitochondrial S07 Hi-C inputs.")
    parser.add_argument("--warnieri", type=Path, required=True)
    parser.add_argument("--elegans", type=Path, required=True)
    parser.add_argument("--elegans-mito-id", default="Te_ctg019")
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    for path in (args.warnieri, args.elegans):
        if not path.is_file() or path.stat().st_size == 0:
            raise SystemExit(f"Missing or empty FASTA: {path}")

    warnieri = read_fasta(args.warnieri)
    elegans = read_fasta(args.elegans)
    if len(warnieri) != 14:
        raise SystemExit(f"Expected 14 Trametes warnieri contigs, found {len(warnieri)}")
    if len(elegans) != 38:
        raise SystemExit(f"Expected 38 Trametes elegans contigs, found {len(elegans)}")
    if sum(1 for record in elegans if record[0] == args.elegans_mito_id) != 1:
        raise SystemExit(f"Expected exactly one mitochondrial candidate {args.elegans_mito_id}")

    elegans_nuclear = [record for record in elegans if record[0] != args.elegans_mito_id]
    elegans_mito = [record for record in elegans if record[0] == args.elegans_mito_id]
    if args.dry_run:
        print("Validated S07 input split: 14 Trametes warnieri nuclear contigs; "
              "37 Trametes elegans nuclear contigs; 1 mitochondrial candidate")
        return

    warnieri_out = args.outdir / "Trametes_warnieri" / "Trametes_warnieri.nuclear.fasta"
    elegans_out = args.outdir / "Trametes_elegans" / "Trametes_elegans.nuclear.fasta"
    mito_out = args.outdir / "Trametes_elegans" / "Trametes_elegans.mitochondrial_candidate.fasta"
    write_fasta(warnieri_out, warnieri)
    write_fasta(elegans_out, elegans_nuclear)
    write_fasta(mito_out, elegans_mito)

    if read_fasta(warnieri_out) != [(n, n, s) for n, _d, s in warnieri]:
        raise SystemExit("Trametes warnieri output sequence verification failed")
    if [r[2] for r in read_fasta(elegans_out)] != [r[2] for r in elegans_nuclear]:
        raise SystemExit("Trametes elegans nuclear output sequence verification failed")
    if [r[2] for r in read_fasta(mito_out)] != [r[2] for r in elegans_mito]:
        raise SystemExit("Trametes elegans mitochondrial output sequence verification failed")

    manifest = {
        "stage": "S07",
        "purge_performed": False,
        "contigs_deleted": 0,
        "source_assemblies": {
            "Trametes warnieri": str(args.warnieri.resolve()),
            "Trametes elegans": str(args.elegans.resolve()),
        },
        "outputs": {
            "Trametes warnieri nuclear": {
                "path": str(warnieri_out.resolve()),
                "contigs": len(warnieri),
                "total_bp": sum(len(r[2]) for r in warnieri),
                "fasta_sha256": sha256_file(warnieri_out),
                "sequence_sha256": sequence_digest(warnieri),
            },
            "Trametes elegans nuclear": {
                "path": str(elegans_out.resolve()),
                "contigs": len(elegans_nuclear),
                "total_bp": sum(len(r[2]) for r in elegans_nuclear),
                "fasta_sha256": sha256_file(elegans_out),
                "sequence_sha256": sequence_digest(elegans_nuclear),
            },
            "Trametes elegans mitochondrial candidate": {
                "path": str(mito_out.resolve()),
                "contig_id": args.elegans_mito_id,
                "contigs": 1,
                "total_bp": len(elegans_mito[0][2]),
                "fasta_sha256": sha256_file(mito_out),
                "sequence_sha256": sequence_digest(elegans_mito),
            },
        },
        "reconstruction_check": {
            "source_contigs": len(elegans),
            "split_contigs": len(elegans_nuclear) + len(elegans_mito),
            "source_bp": sum(len(r[2]) for r in elegans),
            "split_bp": sum(len(r[2]) for r in elegans_nuclear + elegans_mito),
            "exact_partition": [r[0] for r in elegans] == [r[0] for r in elegans_nuclear] + [r[0] for r in elegans_mito],
            "source_sequence_sha256": sequence_digest(elegans),
            "partition_sequence_sha256_order_independent": hashlib.sha256(
                "".join(sorted(r[2] for r in elegans_nuclear + elegans_mito)).encode()
            ).hexdigest(),
            "source_sequence_sha256_order_independent": hashlib.sha256(
                "".join(sorted(r[2] for r in elegans)).encode()
            ).hexdigest(),
        },
    }
    manifest["reconstruction_check"]["exact_partition"] = (
        manifest["reconstruction_check"]["source_contigs"] == manifest["reconstruction_check"]["split_contigs"]
        and manifest["reconstruction_check"]["source_bp"] == manifest["reconstruction_check"]["split_bp"]
        and manifest["reconstruction_check"]["partition_sequence_sha256_order_independent"]
        == manifest["reconstruction_check"]["source_sequence_sha256_order_independent"]
    )
    manifest_path = args.outdir / "S07_input_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")

    table = args.outdir / "S07_input_partition.tsv"
    with table.open("w") as handle:
        handle.write("species\tcontig\tlength_bp\tpartition\taction\n")
        for name, _description, sequence in warnieri:
            handle.write(f"Trametes warnieri\t{name}\t{len(sequence)}\tnuclear\tretain_for_HiC\n")
        for name, _description, sequence in elegans:
            partition = "mitochondrial_candidate" if name == args.elegans_mito_id else "nuclear"
            action = "retain_separately" if partition == "mitochondrial_candidate" else "retain_for_HiC"
            handle.write(f"Trametes elegans\t{name}\t{len(sequence)}\t{partition}\t{action}\n")


if __name__ == "__main__":
    main()
