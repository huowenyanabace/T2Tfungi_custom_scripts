#!/usr/bin/env python3
import argparse
import csv
import hashlib
import json
from pathlib import Path


MOTIFS = ("TTAGGG", "AACCCT", "AAACCCT")


def reverse_complement(seq):
    return seq.translate(str.maketrans("ACGT", "TGCA"))[::-1]


def read_fasta(path):
    records = []
    name = None
    chunks = []
    with path.open() as handle:
        for raw in handle:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    records.append((name, "".join(chunks).upper()))
                name = line[1:].split()[0]
                chunks = []
            else:
                chunks.append(line)
    if name is not None:
        records.append((name, "".join(chunks).upper()))
    if not records or len({name for name, _ in records}) != len(records):
        raise ValueError(f"Invalid or duplicate-ID FASTA: {path}")
    if any(not seq for _, seq in records):
        raise ValueError(f"Empty FASTA record: {path}")
    return records


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--species", required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--end-region", type=int, default=10000)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    source = Path(args.input).resolve()
    records = read_fasta(source)
    if args.dry_run:
        print(f"Validated {len(records)} FASTA records for {args.species}")
        return

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    stem = args.species.replace(" ", "_")
    fasta_out = outdir / f"{stem}.hic_input.fasta"
    map_out = outdir / f"{stem}.name_map.tsv"
    contig_out = outdir / f"{stem}.contigs.tsv"
    telomere_out = outdir / f"{stem}.telomere_candidate_scan.tsv"
    manifest_out = outdir / f"{stem}.prepare_manifest.json"

    mapping = []
    with fasta_out.open("w") as fasta_handle:
        for index, (old_id, seq) in enumerate(records, 1):
            new_id = f"{args.prefix}_ctg{index:03d}"
            mapping.append((old_id, new_id, seq))
            fasta_handle.write(f">{new_id}\n")
            for offset in range(0, len(seq), 80):
                fasta_handle.write(seq[offset:offset + 80] + "\n")

    with map_out.open("w", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["species", "original_id", "hic_input_id", "original_order", "length_bp"])
        for index, (old_id, new_id, seq) in enumerate(mapping, 1):
            writer.writerow([args.species, old_id, new_id, index, len(seq)])

    with contig_out.open("w", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["species", "contig", "length_bp", "gc_percent", "ambiguous_bases", "dpnii_sites"])
        for _, new_id, seq in mapping:
            gc = 100 * (seq.count("G") + seq.count("C")) / len(seq)
            ambiguous = sum(base not in "ACGT" for base in seq)
            writer.writerow([args.species, new_id, len(seq), f"{gc:.5f}", ambiguous, seq.count("GATC")])

    with telomere_out.open("w", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow([
            "species", "contig", "end", "region_bp", "motif", "reverse_complement",
            "motif_count", "reverse_complement_count"
        ])
        for _, new_id, seq in mapping:
            ends = (("left", seq[:args.end_region]), ("right", seq[-args.end_region:]))
            for end, region in ends:
                for motif in MOTIFS:
                    rc = reverse_complement(motif)
                    writer.writerow([
                        args.species, new_id, end, len(region), motif, rc,
                        region.count(motif), region.count(rc)
                    ])

    source_total = sum(len(seq) for _, seq in records)
    output_records = read_fasta(fasta_out)
    output_total = sum(len(seq) for _, seq in output_records)
    if source_total != output_total or [seq for _, seq in records] != [seq for _, seq in output_records]:
        raise RuntimeError("Sequence content changed during FASTA normalization")
    manifest = {
        "species": args.species,
        "source_fasta": str(source),
        "source_sha256": digest(source),
        "output_fasta": str(fasta_out.resolve()),
        "output_sha256": digest(fasta_out),
        "contigs": len(records),
        "total_bp": source_total,
        "sequence_content_preserved": True,
        "naming_prefix": args.prefix,
        "restriction_enzyme": "DpnII",
        "restriction_site": "GATC",
        "telomere_scan_status": "candidate motifs only; final motif remains subject to review"
    }
    manifest_out.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
